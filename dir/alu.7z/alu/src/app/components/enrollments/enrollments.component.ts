import { Component, Input, OnInit, ViewEncapsulation, Output, EventEmitter } from '@angular/core';

import { OLEService } from '../../services/ole.service';
import { PlanService } from '../../services/plan.service';
import { CookieService } from '../../services/cookie.service';
import { StorageService } from '../../services/storage.service';
import { UtilityService } from '../../services/utility.service';
import { UserinfoService } from '../../services/userinfo.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { OLE } from '../../models/OLE';
import { Plan } from '../../models/Plan';
import { County } from '../../models/County';
import { AppData } from '../../models/AppData';
import { ProfilePage } from '../../models/ProfilePage';
import { AppConstants } from '../../constants/app-constants';
import { PlanEnrollment } from '../../models/PlanEnrollment';
import { UserProfile } from '../../models/UserProfile';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-enrollments,[app-enrollments]',
  templateUrl: './enrollments.component.html',
  encapsulation : ViewEncapsulation.None
})
export class EnrollmentsComponent implements OnInit {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;

  @Output() initiateEnrollmentDataBuild = new EventEmitter();

  idx = -1;
  continueEnrollmentText = AppConstants.continueEnrollment;
  submittedEnrollmentText = AppConstants.submitted;
  showRemovePopup = false;
  selectedEnrollment: PlanEnrollment;

  pendingStatus = AppConstants.pending;
  approvedStatus = AppConstants.approved;
  withdrawnStatus = AppConstants.withdrawn;
  deniedStatus = AppConstants.denied;

  constructor(
    private readonly oleService: OLEService,
    private readonly planService: PlanService,
    private readonly cookieService: CookieService,
    private readonly storageService: StorageService,
    private readonly userinfoService: UserinfoService,
    private readonly utilityService: UtilityService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void {
    const deepLinkParams = this.storageService.getItem_SS(AppConstants.deeplinkParams);

    if (deepLinkParams && this.appData.profileDetails && this.appData.profileDetails.enrollmentsDetails && this.appData.profileDetails.enrollmentsDetails.enrollments) {
      const deeplinkPlanId = JSON.parse(deepLinkParams).planId ? JSON.parse(deepLinkParams).planId : null;
      const enrollment = deeplinkPlanId ? this.appData.profileDetails.enrollmentsDetails.enrollments.find( p => p.planId === deeplinkPlanId ) : null;

      // tslint:disable-next-line:no-unused-expression
      enrollment && this.continueEnrollment(enrollment);
    }
  }

  getPlanDataFromEnrollment(enrollment: PlanEnrollment): Plan {
    const plan = new Plan();
    plan.county = new County();

    if (enrollment && enrollment.county) {
      plan.planId = enrollment.planId;
      plan.planName = enrollment.planName;
      plan.planType = enrollment.planType;
      plan.planYear = enrollment.planYear;
      plan.zipCode = enrollment.zipCode;
      plan.county.fipsCountyCode = enrollment.county.fipsCountyCode;
      plan.county.fipsCountyName = enrollment.county.fipsCountyName;
      plan.county.fipsStateCode = enrollment.county.fipsStateCode;
      plan.county.stateCode = enrollment.county.stateCode;
      plan.county.cmsCountyCodes = enrollment.county.cmsCountyCodes;
    }

    return plan;
  }

  continueEnrollment(enrollment: PlanEnrollment, event?: Event) {
    try {
      this.dlClickEvent(enrollment, event, 'Continue Enrollment');

      if (enrollment?.county) {
        const plan = this.getPlanDataFromEnrollment(enrollment);

        this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Continue Enrollment', { plan_name: plan?.planName }, TrackingConstants.eventType.ACTION);

        let olePlan =  this.appData && this.appData.planSearchResultsList && this.appData.planSearchResultsList.length > 0 ?
        this.appData.planSearchResultsList.find(p => enrollment.planId === p.planId && p.compositePlanId && enrollment.planYear === p.compositePlanId.planYear) : null;

        if (olePlan) {
          this.openOLEPage(enrollment, plan, olePlan);

        } else {
          this.planService.searchPlansByType(enrollment.planType, plan).subscribe((searchPlanResponse: any) => {
            if (searchPlanResponse?.data?.plans?.length > 0) {
              olePlan = searchPlanResponse.data.plans.find(p => enrollment.planId === p.planId && p.compositePlanId && enrollment.planYear === p.compositePlanId.planYear);
              if (olePlan) {
                this.openOLEPage(enrollment, plan, olePlan);
              } else {
                console.log('No plan matched in response');
              }
            } else {
              console.log('No plan found in response');
            }
          });
        }
      }

    } catch (e) {
      console.log('Some error occurred while going to OLE for continuing enrollment');
    }
  }

  openOLEPage(enrollment: PlanEnrollment, plan: Plan, olePlan: any) {
    const oleObj: OLE = new OLE();

    this.cookieService.deleteCookie(AppConstants.oleCookieName);

    if (enrollment.formData && JSON.parse(enrollment.formData)) {
      this.oleService.setOLEFormData(enrollment);
    }

    olePlan.monthlyPremiumFormatted = this.utilityService.getMonthlyPremiumValue(olePlan, this.appData);

    const oleCookieString = this.oleService.setOleObj(plan, olePlan, oleObj, this.appData);
    this.cookieService.setCookie(AppConstants.oleCookieName, oleCookieString);

    location.href = oleObj.url;
  }

  goToPlanDetail(enrollment: PlanEnrollment, event?: any) {
    try {
      if (event) {
        const selectedOption = { action: 'Open Plan Details Page', planId: enrollment.planId, status: enrollment.status };
        this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.ENROLLMENTS);
      }
      if (enrollment && enrollment.county && enrollment.county.fipsCountyCode) {
        this.setProvidersDataInBrowserStorage();
        this.openPlanDetailsPage(enrollment);
      }

    } catch (e) {
      console.log('Some error occurred while going to plan details page.');
    }
  }

  openPlanDetailsPage(enrollment: PlanEnrollment) {
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Open Plan Detail Page', { plan_name: enrollment?.planName }, TrackingConstants.eventType.ACTION);

    const params = `?contract_number=${enrollment.planId.substring(0, 5)}&pbp_number=${enrollment.planId.substring(5, 8)}` +
                    `&segment_ID=${enrollment.planId.substring(8)}&county_code=${enrollment.county.fipsCountyCode}` +
                    `&year=${enrollment.planYear}&profile=true&product=${enrollment.planType === 'MAPD' ? 'ma' : enrollment.planType.toLowerCase()}`;

    this.storageService.setItem_SS(AppConstants.geotrackingZip, enrollment.zipCode);
    this.storageService.setItem_SS(AppConstants.vppZipcode, enrollment.zipCode);
    this.storageService.setItem_LS(AppConstants.dcActiveYear, '' + enrollment.planYear);

    this.utilityService.disableDCEFlags();
    this.utilityService.goToVppPage(params);
  }

  setProvidersDataInBrowserStorage() {
    try {
      if (this.isProviderDataExists()) {
        const providerDataString = this.storageService.getItem_LS(AppConstants.providerKey, false);
        const zipcode =
          (this.appData.profileDetails.providersDetails && this.appData.profileDetails.providersDetails.zipCode) ? this.appData.profileDetails.providersDetails.zipCode :
          (this.appData.profileDetails.plansDetails && this.appData.profileDetails.plansDetails.zipCode) ? this.appData.profileDetails.plansDetails.zipCode :
          (providerDataString && JSON.parse(providerDataString)) ? JSON.parse(providerDataString).Zipcode : null;

        const products = this.appData.planSearchResultsList.filter( val => val.mapsPlanType !== 'PDP').map(val => {
          const count =  this.appData.profileDetails.providersDetails.providerIdList
            .reduce((accumulator, list) => accumulator += list.plansList.indexOf(val.planId) > -1 ? 1 : 0, 0);
          return {ClientProdCode: val.planId, ProviderCount: count.toString()};
        });

        const providerCookieobj = {
          ZipCode: zipcode,
          TotalProviders: (this.appData.profileDetails.providersDetails.providerIdList.length).toString(),
          providerIdList: this.appData.profileDetails.providersDetails.providerIdList,
          Products: products
        };

        this.storageService.setItem_LS(AppConstants.providerKey, JSON.stringify(providerCookieobj), false);

      } else {
        this.storageService.removeItem_LS(AppConstants.providerKey, false);
      }

    } catch (e) {
      console.log('Some error occurred while setting providers data in browser storage.');
    }
  }

  isProviderDataExists(): boolean {
    return this.appData?.profileDetails?.providersDetails?.providerIdList?.length > 0;
  }

  closeRemovePopup() {
    this.showRemovePopup = false;

    const removeBtnElement = document.getElementById('enrollRemove-' + this.selectedEnrollment?.planId + '-' + this.selectedEnrollment?.planYear);
    if (removeBtnElement) {
      removeBtnElement.focus();
    }
  }

  openEnrollmentRemovalPopup(enrollment: any, idx: number, event?: any) {
    if (event) {
      const selectedOption = { planId: enrollment?.planId, status: enrollment?.status };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.ENROLLMENTS);
    }
    this.idx = idx;
    this.selectedEnrollment = enrollment;
    this.showRemovePopup = true;
  }

  deleteEnrollment() {
    this.appData?.profileDetails?.enrollmentsDetails?.enrollments?.splice(this.idx, 1);
    this.closeRemovePopup();
    const uuid = this.cookieService.getUuidFromCookie();

    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Delete Enrollment', { plan_name: this.selectedEnrollment?.planName }, TrackingConstants.eventType.ACTION);

    this.userinfoService.deleteProfileData(uuid, 'enrollments', this.selectedEnrollment?.planYear, this.selectedEnrollment?.planId).subscribe((response: any) => {
      console.log('Enrollment deleted successfully.');

      this.userinfoService.getProfileData(uuid, 'enrollments', '').subscribe((data: UserProfile) => {
        this.appData.profileDetails.enrollmentsDetails = data?.enrollmentsDetails;

        this.rebuildEnrollmentData();

      }, (error1) => console.log(error1));

    }, (error) => {
      console.log(error);
      this.reInsertEnrollmentOnFailure(this.idx, this.selectedEnrollment);
    });
  }

  rebuildEnrollmentData(): void {
    this.idx = -1;
    this.selectedEnrollment = null;
    this.initiateEnrollmentDataBuild.emit();
  }

  reInsertEnrollmentOnFailure(index: number, enrollment: PlanEnrollment): void {
    this.appData?.profileDetails?.enrollmentsDetails?.enrollments?.splice(index, 0, enrollment);
  }

  savedEnrollments() {
    return this.appData?.profileDetails?.enrollmentsDetails?.enrollments?.filter(e => !e.isSubmitted)
      ?.sort((e1, e2) => {
        const date1 = new Date(e1?.lastSaved?.split(' ')[1]);
        const date2 = new Date(e2?.lastSaved?.split(' ')[1]);
        return this.utilityService.isValidDate(date1) && this.utilityService.isValidDate(date2) ? date2?.getTime() - date1?.getTime() : -1;
      });
  }

  submittedEnrollments() {
    return this.appData?.profileDetails?.enrollmentsDetails?.enrollments?.filter(e => e.isSubmitted)
      ?.sort((e1, e2) => {
        const date1 = new Date(e1?.lastSaved);
        const date2 = new Date(e2?.lastSaved);
        return this.utilityService.isValidDate(date1) && this.utilityService.isValidDate(date2) ? date2?.getTime() - date1?.getTime() : -1;
      });
  }

  dlClickEvent(enrollment: PlanEnrollment, event?: any, action?: string): void {
    if (event) {
      const eventType = action ? DL_EVENT_TYPE.BUTTON_CLICK : DL_EVENT_TYPE.LINK_CLICK;
      const selectedOption = action
        ? { action, planId: enrollment.planId, status: enrollment.status }
        : { planId: enrollment.planId, status: enrollment.status};

      this.dataLayerService.setDLClickEvent(event, eventType, selectedOption, DL_CONTAINER.ENROLLMENTS);
    }
  }

}
