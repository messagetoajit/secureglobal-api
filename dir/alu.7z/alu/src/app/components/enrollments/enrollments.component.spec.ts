import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { EnrollmentsComponent } from './enrollments.component';
import { AppData } from '../../models/AppData';
import { PlanEnrollment } from '../../models/PlanEnrollment';

describe('EnrollmentsComponent', () => {
  let component: EnrollmentsComponent;
  let fixture: ComponentFixture<EnrollmentsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ EnrollmentsComponent ],
      providers: [ CurrencyPipe ]
    }).compileComponents();

    fixture = TestBed.createComponent(EnrollmentsComponent);
    component = fixture.componentInstance;

    component.profilePage = {};
    component.appData = new AppData();
    const submittedEnroll = new PlanEnrollment();
    submittedEnroll.isSubmitted = true;
  });

  function getNewEnrollment(submitted: boolean = false): PlanEnrollment {
    const enrollment = new PlanEnrollment();
    enrollment.planId = '1234';
    enrollment.planName = 'testPlan';
    enrollment.status = 'testStatus';
    enrollment.lastSaved = 'sometimeback';
    enrollment.planYear = '2222';
    enrollment.zipCode = '12345';
    enrollment.monthlyPremium = '100';
    enrollment.isSubmitted = submitted;
    return enrollment;
  }

  it('should create', () => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should populate header', () => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    component.profilePage.YourEnrollment = 'TestYourEnrollment';
    fixture.detectChanges();
    const headerEle = fixture.nativeElement.querySelector('h2');
    expect(headerEle.innerText).toEqual('TestYourEnrollment (1)');
  });

  it('should populate content', () => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    component.profilePage.Enrollmentcontent = 'TestEnrollmentcontent';
    fixture.detectChanges();
    const contentEle = fixture.nativeElement.querySelector('p');
    expect(contentEle.innerText).toEqual('TestEnrollmentcontent');
  });

  it('should populate saved erollment header', () => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    component.profilePage.SavedEnrollmentsSectionHeading = 'TestSavedEnrollmentsSectionHeading';
    fixture.detectChanges();
    const headerEle = fixture.nativeElement.querySelector('h3');
    expect(headerEle.innerText).toEqual('TestSavedEnrollmentsSectionHeading');
  });

  it('should populate saved erollment cards', () => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    component.profilePage.Enrollmentcontent = 'TestEnrollmentcontent';
    fixture.detectChanges();
    const cardEles = fixture.nativeElement.querySelectorAll('.enrollment-card');
    expect(cardEles.length).toEqual(1);
  });

  it('should show saved erollment card remove button', fakeAsync (() => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    spyOn(component, 'openEnrollmentRemovalPopup').and.callThrough();
    fixture.detectChanges();
    const removeBtn = fixture.nativeElement.querySelector('#enrollRemove-1234-2222');
    expect(removeBtn).toBeTruthy();
    removeBtn.click();
    tick();
    fixture.detectChanges();
    expect(component.openEnrollmentRemovalPopup).toHaveBeenCalled();
  }));

  it('should show saved erollment card header', fakeAsync (() => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    spyOn(component, 'goToPlanDetail').and.callThrough();
    fixture.detectChanges();

    const headerStatusEle = fixture.nativeElement.querySelector('#enrollStatus-saved-0');
    expect(headerStatusEle.innerText).toEqual('testStatus (sometimeback)');

    const headerEle = fixture.nativeElement.querySelector('#enrollName-saved-0');
    expect(headerEle.innerText).toEqual('testPlan');
    headerEle.click();
    tick();
    fixture.detectChanges();
    expect(component.goToPlanDetail).toHaveBeenCalled();
  }));

  it('should show saved erollment card continue enrollemnt button', fakeAsync (() => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    spyOn(component, 'continueEnrollment').and.callThrough();
    fixture.detectChanges();
    const continueEnrollBtn = fixture.nativeElement.querySelectorAll('.enrollment-card__header button')[1];
    expect(continueEnrollBtn).toBeTruthy();
    continueEnrollBtn.click();
    tick();
    fixture.detectChanges();
    expect(component.continueEnrollment).toHaveBeenCalled();
  }));

  it('should populate erollment details', () => {
    component.appData.profileDetails.enrollmentsDetails = { enrollments: [getNewEnrollment()] };
    component.profilePage.StatusHeaderText = 'testStatusHeaderText';
    component.profilePage.ZipCodeHeaderText = 'testZipCodeHeaderText';
    component.profilePage.PlanYearHeaderText = 'testPlanYearHeaderText';
    component.profilePage.MonthlyPremiumHeaderText = 'testMonthlyPremiumHeaderText';
    fixture.detectChanges();
    const detailsEle = fixture.nativeElement.querySelectorAll('.enrollment-card>div')[1];
    expect(detailsEle).toBeTruthy();
    const detailSpanEle = detailsEle.querySelectorAll('span');
    expect(detailSpanEle.length).toEqual(8);
    expect(detailSpanEle[0].innerText).toEqual('testStatusHeaderText');
    expect(detailSpanEle[1].innerText).toEqual('testStatus');
    expect(detailSpanEle[2].innerText).toEqual('testZipCodeHeaderText');
    expect(detailSpanEle[3].innerText).toEqual('12345');
    expect(detailSpanEle[4].innerText).toEqual('testPlanYearHeaderText');
    expect(detailSpanEle[5].innerText).toEqual('2222');
    expect(detailSpanEle[6].innerText).toEqual('testMonthlyPremiumHeaderText');
    expect(detailSpanEle[7].innerText).toEqual('100');
  });

});
