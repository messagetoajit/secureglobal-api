import { Component, OnInit, ViewEncapsulation, Input, AfterViewInit } from '@angular/core';

import { DataLayerService } from '../../services/datalayer.service';

import { ProfilePage } from '../../models/ProfilePage';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-dashboard-footer,[app-dashboard-footer]',
  templateUrl: './dashboard-footer.component.html',
  encapsulation: ViewEncapsulation.None
})
export class DashboardFooterComponent implements OnInit, AfterViewInit {

  @Input() profilePage: ProfilePage;
  @Input() tollFreeNumber: string;

  constructor(private readonly dataLayerService: DataLayerService) { }

  ngOnInit(): void { }

  ngAfterViewInit() {
    this.setDLIDsToLinks();
  }

  setDLIDsToLinks() {
    try {
      const anchorElements: any = document.querySelectorAll('p.tfnContainer a');
      const buttonElements: any = document.querySelectorAll('p.tfnContainer button');

      anchorElements.forEach((element, index) => {
        element.setAttribute('dlassetid', 'vp_tfn_lnk_' + index);
        element.addEventListener('click', (evt) => this.dlClickEvent(evt, DL_EVENT_TYPE.LINK_CLICK));
      });

      buttonElements.forEach((element, index) => {
        element.setAttribute('dlassetid', 'vp_tfn_btn_' + index);
        element.addEventListener('click', (evt) => this.dlClickEvent(evt, DL_EVENT_TYPE.BUTTON_CLICK));
      });

    } catch (error) {
      console.log('Some error occurred in DashboardFooterComponent: setDLIDsToLinks()', error);
    }
  }

  dlClickEvent(event: Event, eventType: any) {
    this.dataLayerService.setDLClickEvent(event, eventType, undefined, DL_CONTAINER.TFN_SECTION);
  }

}
