import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardFooterComponent } from './dashboard-footer.component';

describe('DashboardFooterComponent', () => {
  let component: DashboardFooterComponent;
  let fixture: ComponentFixture<DashboardFooterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DashboardFooterComponent ]
    }).compileComponents();
    fixture = TestBed.createComponent(DashboardFooterComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should populate header', () => {
    component.profilePage = { NeedHelp: 'testNeedHelp'};
    fixture.detectChanges();
    const headeerEle = fixture.nativeElement.querySelector('h4');
    expect(headeerEle.innerText).toEqual('testNeedHelp');
  });

  it('should populate content', () => {
    component.profilePage = { CallUsAtText: 'TestCallUsAtText', TimingsMsg: 'TestTimingsMsg', CallUsAtTimingsText: 'TestCallUsAtTimingsText'};
    component.tollFreeNumber = '1234567890';
    fixture.detectChanges();
    const contentEles = fixture.nativeElement.querySelectorAll('p');
    expect(contentEles.length).toEqual(2);
    expect(contentEles[0].innerText).toContain('TestCallUsAtText');
    expect(contentEles[0].innerText).toContain('TestCallUsAtTimingsText');
    expect(contentEles[0].querySelector('a').innerText).toEqual('1234567890');
    expect(contentEles[1].innerText).toContain('TestTimingsMsg');
  });


});
