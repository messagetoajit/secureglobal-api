import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';

import { DrugsComponent } from './drugs.component';
import { StorageService } from '../../services/storage.service';
import { AppData } from '../../models/AppData';
import { UserProfile } from '../../models/UserProfile';
import { DrugsAndPharmacy } from '../../models/DrugsAndPharmacy';
import { Drug } from '../../models/Drug';

describe('DrugsComponent', () => {
  let component: DrugsComponent;
  let fixture: ComponentFixture<DrugsComponent>;
  let drugsAndPharmacyService: DrugsAndPharmacyService;
  let storageService: StorageService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ DrugsComponent ],
      providers: [DrugsAndPharmacyService, StorageService, CurrencyPipe]
    }).compileComponents();

    fixture = TestBed.createComponent(DrugsComponent);
    component = fixture.componentInstance;
    drugsAndPharmacyService = TestBed.inject(DrugsAndPharmacyService);
    storageService = TestBed.inject(StorageService);
  });

  it('should create', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('display header1 if drug data doesnot exist', () => {
    component.profilePage = { drugsText: 'testDrug', PharmacyText: 'testPharmacy'};
    spyOn(drugsAndPharmacyService, 'isDrugsDataExists').and.returnValue(false);
    fixture.detectChanges();
    const headerEle = fixture.nativeElement.querySelector('#saved-drugs');
    expect(headerEle.innerText).toEqual('(0)');
  });

  it('display header2 if drug data exist', () => {
    component.profilePage = { drugsText: 'testDrug', PharmacyText: 'testPharmacy'};
    component.appData = getAppData();
    spyOn(drugsAndPharmacyService, 'isDrugsDataExists').and.returnValue(true);
    fixture.detectChanges();
    const headerEle = fixture.nativeElement.querySelector('#saved-drugs');
    expect(headerEle.innerText).toEqual('(1)');
    const editLink = fixture.nativeElement.querySelector('.drugs-container a');
    expect(editLink).toBeTruthy();
  });

  it('Add Drug', fakeAsync(() => {
    component.profilePage = { Add: 'Add'}
    spyOn(component, 'visitAddDrugPage').and.callThrough();
    spyOn(drugsAndPharmacyService, 'launchDCE');
    fixture.detectChanges();
    var addDrugLink = fixture.nativeElement.querySelector('a');
    expect(addDrugLink).toBeTruthy();
    expect(addDrugLink.innerText).toEqual('Add');
    addDrugLink.click();
    tick();
    expect(component.visitAddDrugPage).toHaveBeenCalled();
  }))

  it('Edit Drug', fakeAsync(() => {
    component.profilePage = { Edit: 'Edit'};
    component.appData = getAppData();
    spyOn(component, 'launchDCE').and.callThrough();
    spyOn(drugsAndPharmacyService, 'launchDCE');
    fixture.detectChanges();
    var editDrugBtn = fixture.nativeElement.querySelectorAll('button')[1];
    expect(editDrugBtn).toBeTruthy();
    expect(editDrugBtn.innerText).toEqual('Edit');
    editDrugBtn.click();
    tick();
    expect(component.launchDCE).toHaveBeenCalled();
  }))

  it('Remove Drug', fakeAsync(() => {
    component.profilePage = { Remove: 'Remove'};
    component.appData = getAppData();
    spyOn(component, 'showPopup');
    component.removeItemModalCloseBtn = fixture;
    fixture.detectChanges();
    var removeDrugBtn = fixture.nativeElement.querySelectorAll('button')[2];
    expect(removeDrugBtn).toBeTruthy();
    expect(removeDrugBtn.innerText).toEqual('Remove');
    removeDrugBtn.click();
  }));

  it('Remove Drug from popup', fakeAsync(() => {
    component.profilePage = { YesRemove: 'Remove'};
    component.showRemoveDrugPopup = true;
    component.selectedDrug = new Drug();
    component.appData = getAppData();
    spyOn(component, 'deleteDrug');
    component.removeItemModalCloseBtn = fixture;
    fixture.detectChanges();
    var removeDrugBtn = fixture.nativeElement.querySelectorAll('button')[4];
    expect(removeDrugBtn).toBeTruthy();
    expect(removeDrugBtn.innerText).toEqual('Remove');
    removeDrugBtn.click();
  }));


  function getAppData() {
    const appData = new AppData();
    appData.profileDetails = new UserProfile();
    appData.profileDetails.drugsAndPharmacyDetails = new DrugsAndPharmacy();
    const drug = new Drug();
    appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails = [drug];
    return appData;
  }

});
