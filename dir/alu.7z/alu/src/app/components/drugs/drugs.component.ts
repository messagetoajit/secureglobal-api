import { Component, ViewEncapsulation, Input, ViewChild, ElementRef, Output, EventEmitter, HostListener } from '@angular/core';

import { CookieService } from '../../services/cookie.service';
import { UserinfoService } from '../../services/userinfo.service';
import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { Drug } from '../../models/Drug';
import { AppData } from '../../models/AppData';
import { ProfilePage } from '../../models/ProfilePage';
import { UserProfile } from '../../models/UserProfile';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-drugs,[app-drugs]',
  templateUrl: './drugs.component.html',
  encapsulation : ViewEncapsulation.None
})
export class DrugsComponent {

  @ViewChild('removeItemModalCloseBtn') removeItemModalCloseBtn: ElementRef;
  @ViewChild('backBtn') backBtn: ElementRef;
  @ViewChild('removeDrug') removeDrug: ElementRef;

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;

  @Output() initiateDrugsAndPharmacyDataBuild = new EventEmitter();

  showRemoveDrugPopup = false;
  selectedIndex: number;
  selectedDrug: Drug;

  constructor(
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly userinfoService: UserinfoService,
    private readonly cookieService: CookieService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  isDrugsDataExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData);
  }

  isPharmacyExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData)
      && this.appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj?.pharmacyName;
  }

  visitAddDrugPage(event?: any): void {
    if (event) {
      const selectedOption = { action: 'Navigate to DCE' };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption, DL_CONTAINER.SAVED_DRUG);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'DCE - Build Your Drug List', {}, TrackingConstants.eventType.ACTION);

    this.drugsAndPharmacyService.launchDCE();
  }

  showPopup(index: number, drug: Drug, event?: any) {
    if (event) {
      this.dataLayerService.setDLModalDataEvent(('vp_dc_del_' + index), ('Remove ' + drug?.drugName), event, DL_CONTAINER.SAVED_DRUG);
    }
    this.selectedIndex = index;
    this.selectedDrug = drug;
    this.showRemoveDrugPopup = true;

    setTimeout(() => {
      this.removeItemModalCloseBtn.nativeElement.focus();
    }, 100);
  }

  closePopup(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, undefined, DL_CONTAINER.SAVED_DRUG);
    }
    this.showRemoveDrugPopup = false;
    this.selectedIndex = -1;
    this.selectedDrug = undefined;
    this.removeDrug?.nativeElement?.focus();
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.code === 'Escape') {
      this.showRemoveDrugPopup = false;
    }
  }

  deleteDrug(event?: any) {
    if (event) {
      const selectedOption = { drugId: this.selectedDrug?.nationalDrugCode };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_DRUG);
    }
    const deletedDrugName = this.selectedDrug?.drugName;
    this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.splice(this.selectedIndex, 1);

    const uuid = this.cookieService.getUuidFromCookie();

    this.userinfoService.updateProfileData(uuid, 'drugs', this.getUpdatedDrugsData()).subscribe((response: any) => {
      console.log('Drug deleted successfully.');

      this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Drug Deleted', { drug_name: deletedDrugName }, TrackingConstants.eventType.ACTION);

      this.drugsAndPharmacyService.deleteDrugsFromBrowserStorage(this.selectedDrug);
      this.closePopup();

      this.userinfoService.getProfileData(uuid, 'drugs', '').subscribe((data: UserProfile) => {
        this.appData.profileDetails.drugsAndPharmacyDetails = data.drugsAndPharmacyDetails;
        this.initiateDrugsAndPharmacyDataBuild.emit();

      }, (error1) => console.log(error1));

    }, (error) => {
      console.log(error);
      this.reInsertDrugOnFailure(this.selectedIndex, this.selectedDrug);
      this.closePopup();
    });
  }

  backBtn_keydown(event: any){
    if (!event.shiftKey && event.code === 'Tab'){
      this.removeItemModalCloseBtn?.nativeElement?.focus();
      event.preventDefault();
    }
  }

  close_btn(event: any){
    if (event.shiftKey && event.code === 'Tab'){
      this.backBtn?.nativeElement?.focus();
      event.preventDefault();
    }
  }

  getUpdatedDrugsData(): any {
    return {
      drugsAndPharmacyDetails: this.appData.profileDetails.drugsAndPharmacyDetails
    };
  }

  reInsertDrugOnFailure(index: number, drug: Drug): void {
    this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.splice(index, 0, drug);
  }

  launchDCE(event?: any): void {
    if (event) {
      const selectedOption = { action: 'Navigate to DCE' };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_DRUG);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Drug Edit - Launch DCE', {}, TrackingConstants.eventType.ACTION);

    this.drugsAndPharmacyService.launchDCE();
  }

}
