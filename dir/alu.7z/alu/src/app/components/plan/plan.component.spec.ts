import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { PlanComponent } from './plan.component';
import { Plan } from '../../models/Plan';
import { AppData } from '../../models/AppData';

describe('PlanComponent', () => {
  let component: PlanComponent;
  let fixture: ComponentFixture<PlanComponent>;
  const enrollBtnSelector = '.enrollBtn';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ PlanComponent ],
      providers: [ CurrencyPipe ]
    }).compileComponents();

    fixture = TestBed.createComponent(PlanComponent);
    component = fixture.componentInstance;
    component.profilePage = {};
    component.appData = getAppData();
    component.plan = getPlan();
  });

  function getAppData() {
    const appData = new AppData();
    appData.dceSystemDateTime = new Date(2020, 10, 1);
    return appData;
  }

  function getPlan() {
    const plan = new Plan();
    plan.planId = 'H12345';
    plan.planType = 'PDP';
    plan.planYear = '2020';
    return plan;
  }

  it('should create', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('should display delete icon button', () => {
    component.profilePage = { deletePlanIcon: 'delete.png'};
    spyOn(component, 'deletePlan').and.callThrough();
    fixture.detectChanges();
    const removeBtn = fixture.nativeElement.querySelector('.remove-button');
    expect(removeBtn).toBeTruthy();
    expect(removeBtn.querySelector('img').getAttribute('src')).toEqual('delete.png');
    removeBtn.click();
    fixture.detectChanges();
    expect(component.deletePlan).toHaveBeenCalled();
  });

  it('should show plan name in header', () => {
    component.profilePage = {};
    component.plan.planName = 'test plan';
    spyOn(component, 'goToPlanDetail').and.callThrough();
    fixture.detectChanges();
    const header = fixture.nativeElement.querySelector('h3.plan-name');
    expect(header.innerText).toEqual('test plan');
    header.click();
    fixture.detectChanges();
    expect(component.goToPlanDetail).toHaveBeenCalled();
  });

  it('should not display enrollment button', () => {
    component.appData.dceSystemDateTime = new Date(2020, 11, 1);
    fixture.detectChanges();
    const enrollBtn = fixture.nativeElement.querySelector(enrollBtnSelector);
    expect(enrollBtn).toBeFalsy();
  });

  it('should not display enrollment button', () => {
    component.profilePage = { excludedAcquiredPlans: 'H12345' };
    fixture.detectChanges();
    const enrollBtn = fixture.nativeElement.querySelector(enrollBtnSelector);
    expect(enrollBtn).toBeFalsy();
  });

  it('should display enrollment button', () => {
    component.profilePage = { enrollInPlanText: 'Enroll In'};
    spyOn(component, 'enrollPlan').and.callThrough();
    fixture.detectChanges();
    const enrollBtn = fixture.nativeElement.querySelector(enrollBtnSelector);
    expect(enrollBtn).toBeTruthy();
    expect(enrollBtn.innerText).toEqual('Enroll In');
    enrollBtn.click();
    expect(component.enrollPlan).toHaveBeenCalled();
  });

  it('should display continue enrollment button', () => {
    component.plan.enrollmentStatus = 'Continue Enrollment';
    spyOn(component, 'enrollPlan').and.callThrough();
    fixture.detectChanges();
    const enrollBtn = fixture.nativeElement.querySelector(enrollBtnSelector);
    expect(enrollBtn).toBeTruthy();
    expect(enrollBtn.innerText).toEqual('Continue Enrollment');
    enrollBtn.click();
    expect(component.enrollPlan).toHaveBeenCalled();
  });

  it('should display submitted enrollment button', () => {
    component.plan.enrollmentStatus = 'Submitted';
    fixture.detectChanges();
    const enrollBtn = fixture.nativeElement.querySelector(enrollBtnSelector);
    expect(enrollBtn).toBeTruthy();
    expect(enrollBtn.innerText).toEqual('Submitted');
    expect(enrollBtn.getAttribute('disabled')).toEqual('');
  });

});
