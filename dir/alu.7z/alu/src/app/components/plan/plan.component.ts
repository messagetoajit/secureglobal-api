import { Component, Input, Output, EventEmitter, ViewEncapsulation, OnInit, OnChanges, SimpleChanges, ViewChild, ElementRef } from '@angular/core';

import { OLEService } from '../../services/ole.service';
import { PlanService } from '../../services/plan.service';
import { CookieService } from '../../services/cookie.service';
import { UtilityService } from '../../services/utility.service';
import { TooltipService } from '../../services/tooltip.service';
import { StorageService } from '../../services/storage.service';
import { ProviderService } from '../../services/provider.service';
import { DateUtilityService } from '../../services/date-utility.service';
import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { OLE } from '../../models/OLE';
import { Plan } from '../../models/Plan';
import { AppData } from '../../models/AppData';
import { ProfilePage } from '../../models/ProfilePage';
import { AppConstants } from '../../constants/app-constants';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-plan,[app-plan]',
  templateUrl: './plan.component.html',
  encapsulation : ViewEncapsulation.None
})
export class PlanComponent implements OnInit, OnChanges {
  @ViewChild('viewDrugs') viewDrugs?: ElementRef;
  @ViewChild('viewDoctors') viewDoctors?: ElementRef;

  @Input() appData: AppData;
  @Input() plan: Plan;
  @Input() index: number;
  @Input() profilePage: ProfilePage;
  @Input() isProfileDataImported: boolean;
  @Input() showImportTip: boolean;
  @Input() isCSRLogin: boolean;

  @Output() initiatePlanDelete = new EventEmitter();
  @Output() initiateProvidersDataBuild = new EventEmitter();
  @Output() importShopperData = new EventEmitter();

  showPlanDetails = true;
  continueEnrollmentText = AppConstants.continueEnrollment;
  submittedEnrollmentText = AppConstants.submitted;
  defaultCostValue = AppConstants.defaultCostValue;
  drug = AppConstants.drug;
  doctor = AppConstants.doctor;
  uniqueKey: string;
  showDrugDoctorPopup = false;
  selectedDrugDoctorPlan: Plan;
  drugDoctorPopupType: string;
  showAddDrugDoctorPopup = false;
  excludedBenefits = [AppConstants.monthlyPremium, AppConstants.prescriptionDrusTier1, AppConstants.estimatedAnnualDrugCost];
  pdpExcludedBenefits = [AppConstants.monthlyPremium, AppConstants.estimatedAnnualDrugCost];

  constructor(
    private readonly oleService: OLEService,
    private readonly utilityService: UtilityService,
    private readonly cookieService: CookieService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly providerService: ProviderService,
    private readonly tooltipService: TooltipService,
    private readonly dateUtilService: DateUtilityService,
    private readonly storageService: StorageService,
    private readonly planService: PlanService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit() {
    this.initiatetooltip();
    this.uniqueKey = this.plan?.planType?.toLowerCase() + '-' + (this.index + 1);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.isProfileDataImported && changes.isProfileDataImported.currentValue === true) {
      this.showPlanDetails = false;
    }
  }

  planBenefits() {
    if (this.plan?.benefits?.length > 0) {
      if (this.plan.planType === 'PDP') {
        return this.plan.benefits.filter(b => !(this.pdpExcludedBenefits.some(eb => b.label.indexOf(eb) > -1)));
      } else {
        return this.plan.benefits.filter(b => !(this.excludedBenefits.some(eb => b.label.indexOf(eb) > -1)));
      }
    }
    return [];
  }

  get planDescriptionHTML() {
    return this.utilityService.getSanitizedHTML(this.plan?.planDescriptionHTML);
  }

  get planBenefitListHTML() {
    return this.utilityService.getSanitizedHTML(this.plan?.planBenefitListHTML);
  }

  deletePlan(event?: any) {
    if (event) {
      const selectedOption = { action: 'Delete Saved Plan', planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Delete Plan', { plan_name: this.plan?.planName }, TrackingConstants.eventType.ACTION);

    this.initiatePlanDelete.emit({
      index: this.index,
      plan: this.plan
    });
  }

  onKeydown(event): void {
    console.log('event-key' + event.key);

    if (event.key === 'Enter') {
      this.initiatePlanDelete.emit({
        index: this.index,
        plan: this.plan
      });
    }
  }

  goToPlanDetail(event?: any) {
    if (event) {
      const selectedOption = { action: 'Navigate To Plan Details', planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Goto to Plan Detail page', { plan_name: this.plan?.planName }, TrackingConstants.eventType.ACTION);

    const params = `?contract_number=${this.plan.planId.substring(0, 5)}&pbp_number=${this.plan.planId.substring(5, 8)}` +
                   `&segment_ID=${this.plan.planId.substring(8)}&county_code=${this.plan.county.fipsCountyCode}` +
                   `&year=${this.plan.planYear}&profile=true&product=${this.plan.planType === 'MAPD' ? 'ma' : this.plan.planType.toLowerCase()}`;
    const zipCode = this.appData.profileDetails.plansDetails.zipCode;

    this.storageService.setItem_SS(AppConstants.geotrackingZip, zipCode);
    this.storageService.setItem_SS(AppConstants.vppZipcode, zipCode);
    this.storageService.setItem_LS(AppConstants.dcActiveYear, '' + this.plan.planYear);

    this.utilityService.disableDCEFlags();
    this.utilityService.goToVppPage(params);
  }

  enrollPlan(event?: any) {
    if (event) {
      const selectedOption = { action: 'Enroll Plan', planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Enroll Plan', { plan_name: this.plan?.planName }, TrackingConstants.eventType.ACTION);

    const oleObj: OLE = new OLE();
    let oleCookieString: string;

    this.cookieService.deleteCookie(AppConstants.oleCookieName);

    const olePlan = this.appData.planSearchResultsList.find(p => this.plan.planId === p.planId);

    if (olePlan) {
      if (this.plan.enrollmentStatus && this.plan.enrollmentStatus === AppConstants.continueEnrollment) {
        const enrollment = this.appData.profileDetails.enrollmentsDetails.enrollments.find(e => e.planId === this.plan.planId && e.planYear === this.plan.planYear);

        if (enrollment && enrollment.formData && JSON.parse(enrollment.formData)) {
          this.oleService.setOLEFormData(enrollment);
        }
      }

      olePlan.monthlyPremiumFormatted = this.utilityService.getMonthlyPremiumValue(olePlan, this.appData);
      oleCookieString = this.oleService.setOleObj(this.plan, olePlan, oleObj, this.appData);
      this.cookieService.setCookie(AppConstants.oleCookieName, oleCookieString);
      location.href = oleObj.url;
    }
  }

  togglePlanDetails(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.showPlanDetails = !this.showPlanDetails;
  }

  initiatetooltip() {
    setTimeout(() => {
      this.tooltipService.svgiconfunction();
      this.tooltipService.tooltipmessageservice();
    }, 100);
  }

  isDrugsAndPharmacyDataExists() {
    return this.isDrugDataExists()
      && this.appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj?.pharmacyNumber;
  }

  isDrugDataExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData);
  }

  isProviderDataExists() {
    return this.providerService.isProviderDataExists(this.appData);
  }

  isDrugOrProviderDataExists() {
    return this.isDrugDataExists() || this.isProviderDataExists();
  }

  get xOfxDrugsCoveredString() {
    const totalDrugs = this.drugsAndPharmacyService.isDrugsDataExists(this.appData) ? this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length : 0;
    const coveredDrugs = this.plan?.coveredDrugsCount ? this.plan.coveredDrugsCount : 0;

    return coveredDrugs + ' of ' + totalDrugs;
  }

  get xOfxProvidersCoveredString() {
    const totalProviders = this.providerService.isProviderDataExists(this.appData) ? this.appData.profileDetails.providersDetails.providerIdList.length : 0;
    const coveredProviders = totalProviders > 0 ? this.providerService.getCoveredProvidersCount(this.plan, this.appData.profileDetails.providersDetails.providerIdList) : 0;

    return coveredProviders + ' of ' + totalProviders;
  }

  showEnrollmentButton() {
    const dceSystemYear = this.appData.dceSystemDateTime.getFullYear();
    const planYear = Number(this.plan.planYear);

    return ((planYear === dceSystemYear && this.dateUtilService.isBetween_Jan01_Nov30(this.appData.dceSystemDateTime))
      || (planYear === (dceSystemYear + 1) && this.dateUtilService.isBetween_Oct15_Dec31(this.appData.dceSystemDateTime)))
      && !this.isExcludedAcquiredPlan();
  }

  isExcludedAcquiredPlan() {
    return this.profilePage?.excludedAcquiredPlans?.indexOf(this.plan.planId) > -1;
  }

  viewDrugDoctorDetailsPopup(plan: Plan, type: string, event?: any) {
    if (event) {
      const selectedOption = { planId: plan?.planId, popup: type };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.showDrugDoctorPopup = true;
    this.selectedDrugDoctorPlan = plan;
    this.drugDoctorPopupType = type;
    this.utilityService.setBodyScroll(false);
  }

  closeDrugDoctorPopup(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planType: this.plan?.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    const popupType = this.drugDoctorPopupType;
    this.showDrugDoctorPopup = false;
    this.selectedDrugDoctorPlan = undefined;
    this.drugDoctorPopupType = undefined;
    this.utilityService.setBodyScroll(true);

    if (popupType === AppConstants.drug) {
      this.viewDrugs?.nativeElement?.focus();
    } else if (popupType === AppConstants.doctor) {
      this.viewDoctors?.nativeElement?.focus();
    }
  }

  isDrugEligiblePlan() {
    return this.plan.planType !== 'MA'
      && !(this.appData.planBenefitsContent?.piedmontPlanYear?.indexOf(this.plan.planYear) > -1
      && this.appData.planBenefitsContent?.piedmontContentSuppressionList?.indexOf(this.plan.planId) > -1
    );
  }

  isProviderEligiblePlan() {
    return this.planService.isAddDoctorEligibleForPlan(this.plan);
  }

  addOrEditDrugs(event?: any) {
    if (event) {
      const selectedOption = { action: 'Navigate to DCE', planId: this.plan?.planId, planType: this.plan?.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Add or Edit Drug', { plan_name: this.plan?.planName }, TrackingConstants.eventType.ACTION);

    this.drugsAndPharmacyService.launchDCEWithPlanInfo(this.plan, this.appData);
  }

  searchProviders(event?: any) {
    let selectedOption: any;
    if (event) {
      selectedOption = { planId: this.plan?.planId, planType: this.plan?.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    selectedOption = { planId: this.plan?.planId, planType: this.plan?.planType };
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Search Providers', selectedOption, TrackingConstants.eventType.ACTION);

    const anyProviderEligibleFederalPlan = this.planService.getAnyProviderEligibleFederalPlan(this.appData);

    if (anyProviderEligibleFederalPlan) {
      this.providerService.searchProvider(this.appData, anyProviderEligibleFederalPlan);

      this.providerService.getRallyProviderSearchNotification().subscribe((msg: any) => {
        console.log('Rally Provider Search Completed.');

        if (msg?.providerSearchComplete) {
          console.log('Going to rebuild providers data ...');
          this.initiateProvidersDataBuild.emit();
        }
      });
    }
  }

  openShopperDataImportPopup(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planType: this.plan?.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.importShopperData.emit();
  }

  closeTip(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planType: this.plan?.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.showImportTip = false;
  }

}
