import { Component, Input, ViewChild, ElementRef, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-data-import-loader',
  templateUrl: './data-import-loader.component.html',
  styleUrls: ['./data-import-loader.component.scss']
})
export class DataImportLoaderComponent implements OnChanges {

  @ViewChild('importLoader') importLoader?: ElementRef;

  @Input() showLoader?: boolean;

  constructor() { }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.showLoader && changes.showLoader.currentValue === true) {
      setTimeout(() => { this.importLoader?.nativeElement?.focus(); }, 100);
    }
  }

}
