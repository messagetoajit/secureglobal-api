import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DataImportLoaderComponent } from './data-import-loader.component';
import { SimpleChange } from '@angular/core';


describe('DataImportLoaderComponent', () => {
  let component: DataImportLoaderComponent;
  let fixture: ComponentFixture<DataImportLoaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DataImportLoaderComponent, DataImportLoaderComponent ],
    });
    fixture = TestBed.createComponent(DataImportLoaderComponent);
    component = fixture.componentInstance;
  });

  it('should create with hidden loader', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
    expect(fixture.nativeElement.querySelector('#data-import-loader')).toBeFalsy();
  });

  it('show loader', () => {
    component.showLoader = true;
    component.ngOnChanges({showLoader: new SimpleChange(false, true, true)});
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('#data-import-loader')).toBeTruthy();
  });

});
