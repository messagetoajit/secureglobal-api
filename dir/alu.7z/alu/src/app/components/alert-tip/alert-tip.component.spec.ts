import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { AlertTipComponent } from './alert-tip.component';
import { ProfilePage } from 'src/app/models/ProfilePage';

describe('AlertTipComponent', () => {
  let component: AlertTipComponent;
  let fixture: ComponentFixture<AlertTipComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ AlertTipComponent ]
    }).compileComponents();

    fixture = TestBed.createComponent(AlertTipComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    component.profilePage = new ProfilePage({});
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('show short tip', () => {
    component.showShort = true;
    component.profilePage = { tipContent: 'testContent'};
    fixture.detectChanges();
    const contentEle = fixture.nativeElement.querySelector('.alert__content p');
    expect(contentEle).toBeFalsy();
  });

  it('show long tip', () => {
    component.showShort = false;
    component.profilePage = { tipContent: 'testContent'};
    fixture.detectChanges();
    const contentEle = fixture.nativeElement.querySelector('.alert__content p');
    expect(contentEle).toBeTruthy();
    expect(contentEle.innerText).toEqual('testContent');
  });

  it('show long tip signIn button', () => {
    component.showShort = false;
    component.profilePage = { saveyouritems: 'testSave'};
    fixture.detectChanges();
    const loginBtn = fixture.nativeElement.querySelector('.long-btn-panel button');
    expect(loginBtn).toBeTruthy();
    expect(loginBtn.querySelector('span').innerText).toEqual('testSave');
  });

  it('register should called after register button click', fakeAsync (() => {
    component.showShort = false;
    component.profilePage = { saveyouritems: 'testSave'};
    fixture.detectChanges();
    spyOn(component, 'saveYourItems').and.callThrough();
    const signInBtn = fixture.nativeElement.querySelector('.long-btn-panel button');
    signInBtn.click();
    tick(); // simulates the passage of time until all pending asynchronous activities finish
    fixture.detectChanges();
    expect(component.saveYourItems).toHaveBeenCalled();
  }));

  it('show long tip dismiss link', () => {
    component.showShort = false;
    component.profilePage = { dismiss: 'testDismiss'};
    fixture.detectChanges();
    const dismissLink = fixture.nativeElement.querySelector('.long-btn-panel a');
    expect(dismissLink).toBeTruthy();
    expect(dismissLink.innerText).toEqual('testDismiss');
  });

  it('dismiss should called after dismiss link click', fakeAsync (() => {
    component.showShort = false;
    component.profilePage = { saveyouritems: 'testDismiss'};
    fixture.detectChanges();
    spyOn(component, 'dismiss').and.callThrough();
    const dismissLink = fixture.nativeElement.querySelector('.long-btn-panel a');
    dismissLink.click();
    tick();
    fixture.detectChanges();
    expect(component.dismiss).toHaveBeenCalled();
  }));

  it('show long tip close button', () => {
    component.showShort = false;
    component.profilePage = { dismiss: 'testDismiss'};
    fixture.detectChanges();
    const closeBtn = fixture.nativeElement.querySelector('.long-close-btn');
    expect(closeBtn).toBeTruthy();
  });

  it('dismiss should called after close button click', fakeAsync (() => {
    component.showShort = false;
    component.profilePage = { saveyouritems: 'testDismiss'};
    fixture.detectChanges();
    spyOn(component, 'dismiss').and.callThrough();
    const closeBtn = fixture.nativeElement.querySelector('.long-close-btn img');
    closeBtn.click();
    tick();
    fixture.detectChanges();
    expect(component.dismiss).toHaveBeenCalled();
  }));

});
