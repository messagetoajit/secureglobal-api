import { Component, Input, OnInit, ViewEncapsulation, EventEmitter, Output } from '@angular/core';

import { UtilityService } from '../../services/utility.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { ProfilePage } from '../../models/ProfilePage';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-alert-tip,[app-alert-tip]',
  templateUrl: './alert-tip.component.html',
  encapsulation : ViewEncapsulation.None
})
export class AlertTipComponent implements OnInit {

  @Input() showShort: boolean;
  @Input() profilePage: ProfilePage;
  @Output() closeAlertTip = new EventEmitter();

  constructor(
    private readonly utilityService: UtilityService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void { }

  saveYourItems(event?: any) {
    if (event) {
      const selectedOption = { action: 'Save your items'};
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Save your items', {}, TrackingConstants.eventType.ACTION);

    this.utilityService.navigateToURL(this.profilePage.saveYourItemsLink);
  }

  dismiss(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.closeAlertTip.emit();
  }

}
