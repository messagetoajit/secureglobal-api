import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { RemoveEnrollPopupComponent } from './remove-enroll-popup.component';

describe('RemoveEnrollPopupComponent - [UNIT TEST CASES]', () => {
  let component: RemoveEnrollPopupComponent;
  let fixture: ComponentFixture<RemoveEnrollPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RemoveEnrollPopupComponent]
    });

    fixture = TestBed.createComponent(RemoveEnrollPopupComponent);
    component = fixture.componentInstance;
  });

  it('Should create remove enroll popup', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('Should call closePopUp on close button click', fakeAsync(() => {
    component.profilePage = {};
    fixture.detectChanges();
    spyOn(component, 'closePopup').and.callThrough();
    const comp = fixture.nativeElement.querySelector('.uhc-link-button');
    comp.click();
    tick();
    fixture.detectChanges();
    expect(component.closePopup).toHaveBeenCalled();
  }));

  it('Should call removeEnrollement on remove button click', fakeAsync(() => {
    component.profilePage = { RemoveEmrollmentButton: 'remove'};
    fixture.detectChanges();
    spyOn(component, 'removeEnrollment').and.callThrough();
    const comp = fixture.nativeElement.querySelectorAll('button')[1];
    expect(comp.innerText).toEqual('remove');
    comp.click();
    tick();
    fixture.detectChanges();
    expect(component.removeEnrollment).toHaveBeenCalled();
  }));

  it('Should call closePopUp on back button click', fakeAsync(() => {
    component.profilePage = {};
    fixture.detectChanges();
    spyOn(component, 'closePopup').and.callThrough();
    const comp = fixture.nativeElement.querySelectorAll('button')[2];
    comp.click();
    tick();
    fixture.detectChanges();
    expect(component.closePopup).toHaveBeenCalled();
  }));

});
