import { Component, Input, ViewEncapsulation, Output, EventEmitter, HostListener, ViewChild, ElementRef, AfterViewInit } from '@angular/core';

import { DataLayerService } from '../../services/datalayer.service';

import { AppData } from '../../models/AppData';
import { PlanEnrollment } from '../../models/PlanEnrollment';
import { ProfilePage } from '../../models/ProfilePage';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-remove-enroll-popup,[app-remove-enroll-popup]',
  templateUrl: './remove-enroll-popup.component.html',
  encapsulation : ViewEncapsulation.None
})
export class RemoveEnrollPopupComponent implements AfterViewInit {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;
  @Input() selectedEnrollment: PlanEnrollment;
  @Input() dlassetid: string;

  @Output() closeModalPopup = new EventEmitter();
  @Output() deleteEnrollment = new EventEmitter();

  @ViewChild('backEnrollModal') backEnrollModal: ElementRef;
  @ViewChild('closeEnrollbtnModal') closeEnrollbtnModal: ElementRef;

  constructor(private readonly dataLayerService: DataLayerService) { }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.code === 'Escape') {
      this.closeModalPopup.emit();
      document.getElementById('enrollRemove-' + this.selectedEnrollment?.planId + '-' + this.selectedEnrollment?.planYear).focus();
    }
  }

  ngAfterViewInit(): void {
    this.dataLayerService.setDLModalDataEvent(this.dlassetid, this.profilePage?.EnrollPopupheader, undefined, DL_CONTAINER.ENROLLMENTS);
    this.closeEnrollbtnModal.nativeElement.focus();
  }

  removeEnrollment(event?: any) {
    if (event) {
      const selectedOption = { action: 'Delete Enrollment', planId: this.selectedEnrollment.planId };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.ENROLLMENTS);
    }
    this.deleteEnrollment.emit();
  }

  closePopup(event?: any) {
    if (event) {
      const selectedOption = { planId: this.selectedEnrollment.planId };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK , selectedOption, DL_CONTAINER.ENROLLMENTS);
    }
    this.closeModalPopup.emit();
  }

  closeEnroll_keydown(event: any){
    if (!event.shiftKey && event.code === 'Tab'){
      this.closeEnrollbtnModal.nativeElement.focus();
      event.preventDefault();
    }
  }

  removeBtn_keydown(event: any){
    if (event.shiftKey && event.code === 'Tab'){
      this.closeEnrollbtnModal.nativeElement.focus();
      event.preventDefault();
    }
  }

  enrollClose_keydown(event: any){
    if (event.shiftKey && event.code === 'Tab'){
      this.backEnrollModal.nativeElement.focus();
      event.preventDefault();
    }
  }
}
