import { ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { By } from '@angular/platform-browser';

import { TimeoutPopupComponent } from './timeout-popup.component';

describe('TimeoutPopupComponent - [UNIT TEST CASES]', () => {
  let component: TimeoutPopupComponent;
  let fixture: ComponentFixture<TimeoutPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [TimeoutPopupComponent]
    });

    fixture = TestBed.createComponent(TimeoutPopupComponent);
    component = fixture.componentInstance;
  });

  it('Should create time out popup', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();

    const container = fixture.debugElement.query(By.css('.modal-overlay'));
    const containerEl: HTMLElement = container.nativeElement;
    containerEl.classList.remove('show');
  });

  it('Should call hidePopUp on stayon click', fakeAsync(() => {
    component.profilePage = {timeoutHeader: 'Timeout'};
    component.timePeriod = 0;
    fixture.detectChanges();
    spyOn(component, 'hidePopUp').and.callThrough();
    const comp = fixture.nativeElement.querySelector('#proceed');
    comp.click();
    tick();
    clearInterval(component.intervalRef);
    fixture.detectChanges();
    expect(component.hidePopUp).toHaveBeenCalled();
  }));

  it('Should call logout on close click', fakeAsync(() => {
    component.profilePage = {timeoutHeader: 'Timeout'};
    component.timePeriod = 0;
    fixture.detectChanges();
    clearInterval(component.intervalRef);
    spyOn(component, 'logout').and.callThrough();
    const comp = fixture.nativeElement.querySelector('#visitBack');
    comp.click();
    tick();
    fixture.detectChanges();
    expect(component.logout).toHaveBeenCalled();
  }));
});
