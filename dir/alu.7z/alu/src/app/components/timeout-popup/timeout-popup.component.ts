import { Component, ViewEncapsulation, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { UserinfoService } from '../../services/userinfo.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { ProfilePage } from '../../models/ProfilePage';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-timeout-popup',
  templateUrl: './timeout-popup.component.html',
  styleUrls: ['./timeout-popup.component.scss'],
  encapsulation : ViewEncapsulation.None
})
export class TimeoutPopupComponent implements OnInit {

  @Input() profilePage: ProfilePage;
  @Output() closePopUp = new EventEmitter();

  seconds: any;
  minutes: any;
  timePeriod = 120000;
  intervalRef: any;

  constructor(
    private readonly userInfoService: UserinfoService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) {}

  ngOnInit() {
    this.dataLayerService.setDLModalDataEvent('vp_timeout', 'Timeout Popup');
    this.intervalRef = setInterval(this.timer, 1000);
  }

  hidePopUp(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    clearInterval(this.intervalRef);
    this.closePopUp.emit(true);
  }

  timer = () => {
    this.minutes = Math.floor((this.timePeriod % (1000 * 60 * 60)) / (1000 * 60));
    this.seconds = Math.floor((this.timePeriod % (1000 * 60)) / 1000);

    if (this.timePeriod  < 10) {
      this.timePeriod  = this.timePeriod ;
    }

    if (this.timePeriod  === 0) {
      clearInterval(this.intervalRef);
      this.logout();
    } else {
      this.timePeriod = this.timePeriod - 1000;
    }
  }

  logout(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'User logout after time out', {}, TrackingConstants.eventType.ACTION);

    this.userInfoService.logout().subscribe(data => {
      this.userInfoService.deleteBrowserStorage();
      location.href = '/';
    }, (error) => console.log(error));
  }

}
