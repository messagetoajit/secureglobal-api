import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { ProviderService } from '../../services/provider.service';
import { AppData } from '../../models/AppData';
import { PlanDrugProviderPopupComponent } from './plan-drug-provider-popup.component';
import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';
import { UserProfile } from '../../models/UserProfile';
import { Drug } from '../../models/Drug';
import { Plan } from '../../models/Plan';
import { DrugsAndPharmacy } from '../../models/DrugsAndPharmacy';
import { ProvidersDetails } from '../../models/ProvidersDetails';
import { Provider } from '../../models/Provider';
import { AppConstants } from '../../constants/app-constants';

describe('PlanDrugProviderPopupComponent', () => {
    let component: PlanDrugProviderPopupComponent;
    let fixture: ComponentFixture<PlanDrugProviderPopupComponent>;
    let providerService: ProviderService;
    let drugsAndPharmacyService: DrugsAndPharmacyService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ HttpClientTestingModule ],
            declarations: [ PlanDrugProviderPopupComponent ],
            providers: [ CurrencyPipe , DrugsAndPharmacyService, ProviderService ],
        });

        fixture = TestBed.createComponent(PlanDrugProviderPopupComponent);
        component = fixture.componentInstance;
        drugsAndPharmacyService = TestBed.inject(DrugsAndPharmacyService);
        providerService = TestBed.inject(ProviderService);
        component.appData = new AppData();
        component.plan = new Plan();
    });

    it('should create', () => {
        component.profilePage = {};
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('test sortedDrugs & xOfxDrugsCoveredString getters', () => {
        component.plan.coveredDrugs = ['0', '1', '2'];
        component.plan.coveredDrugsCount = 3;

        component.appData.profileDetails = new UserProfile();
        component.appData.profileDetails.drugsAndPharmacyDetails = new DrugsAndPharmacy();
        component.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails = [new Drug(), new Drug(), new Drug()];
        component.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails[0].drugName = 'b';
        component.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails[1].drugName = 'c';
        component.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails[2].drugName = 'a';
        component.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails[0].nationalDrugCode = '0';
        component.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails[1].nationalDrugCode = '1';
        component.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails[2].nationalDrugCode = '2';

        expect(component.xOfxDrugsCoveredString).toEqual('3 of 3');
        expect(component.sortedDrugs[0].drugName).toEqual('a');
        expect(component.sortedDrugs[1].drugName).toEqual('b');
        expect(component.sortedDrugs[2].drugName).toEqual('c');

        component.appData.profileDetails = null;
        expect(component.sortedDrugs).toEqual([]);
    });

    it('test sortedDoctors & xOfxProvidersCoveredString getter', () => {
        component.plan.planId = '1';

        component.appData.profileDetails = new UserProfile();
        component.appData.profileDetails.providersDetails = new ProvidersDetails();
        component.appData.profileDetails.providersDetails.providerIdList = [new Provider(), new Provider(), new Provider()];
        component.appData.profileDetails.providersDetails.providerIdList[0].providerName = 'b';
        component.appData.profileDetails.providersDetails.providerIdList[1].providerName = 'c';
        component.appData.profileDetails.providersDetails.providerIdList[2].providerName = 'a';
        component.appData.profileDetails.providersDetails.providerIdList[0].plansList = ['0', '1', '2'];
        component.appData.profileDetails.providersDetails.providerIdList[1].plansList = ['0', '1', '2'];
        component.appData.profileDetails.providersDetails.providerIdList[2].plansList = ['0', '1', '2'];

        expect(component.xOfxProvidersCoveredString).toEqual('3 of 3');
        expect(component.sortedDoctors[0].providerName).toEqual('a');
        expect(component.sortedDoctors[1].providerName).toEqual('b');
        expect(component.sortedDoctors[2].providerName).toEqual('c');

        component.appData.profileDetails = null;
        expect(component.sortedDoctors).toEqual([]);
    });

    it('test headerText getter', () => {
        component.popupType = AppConstants.drug;
        expect(component.headerText).toEqual('View Drug Pricing');
        component.popupType = '';
        expect(component.headerText).toEqual('View Providers');
    });

    it('test isHospitalProvider function',() => {
        expect(component.isHospitalProvider('facility')).toEqual(true);
        expect(component.isHospitalProvider('')).toEqual(false);
    });

    it('test checkInvalidProviderName function',() => {
        expect(component.checkInvalidProviderName('providerName')).toEqual('providerName');
        expect(component.checkInvalidProviderName(' , ')).toEqual(AppConstants.savedProvider);
    });
});
