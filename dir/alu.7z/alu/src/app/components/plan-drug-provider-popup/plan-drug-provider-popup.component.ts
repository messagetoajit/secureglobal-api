
import { Component, ViewEncapsulation, Input, Output, EventEmitter, ViewChild, ElementRef, HostListener, AfterViewInit } from '@angular/core';

import { ProviderService } from '../../services/provider.service';
import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { Plan } from '../../models/Plan';
import { AppData } from '../../models/AppData';
import { ProfilePage } from '../../models/ProfilePage';
import { AppConstants } from '../../constants/app-constants';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-plan-drug-provider-popup,[app-plan-drug-provider-popup]',
  templateUrl: './plan-drug-provider-popup.component.html',
  encapsulation : ViewEncapsulation.None
})
export class PlanDrugProviderPopupComponent implements AfterViewInit {

  @ViewChild('backBtn') backBtn: ElementRef;
  @ViewChild('drugpriceModal') drugpriceModal: ElementRef;

  @Input() plan: Plan;
  @Input() popupType: string;
  @Input() appData: AppData;
  @Input() index: number;
  @Input() profilePage: ProfilePage;
  @Input() dlassetid: string;

  @Output() closeModalPopup = new EventEmitter();

  drug = AppConstants.drug;
  doctor = AppConstants.doctor;
  defaultCostValue = AppConstants.defaultCostValue;

  constructor(
    private readonly providerService: ProviderService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngAfterViewInit() {
    this.drugpriceModal.nativeElement.focus();
    this.dataLayerService.setDLModalDataEvent(this.dlassetid, this.headerText);
  }

  get sortedDrugs() {
    if (this.drugsAndPharmacyService.isDrugsDataExists(this.appData)) {
      const coveredDrugs = this.plan.coveredDrugs ? this.plan.coveredDrugs : [];
      return this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.sort((a, b) =>  {
        return ((coveredDrugs.indexOf(a.nationalDrugCode) > -1) === (coveredDrugs.indexOf(b.nationalDrugCode) > -1)
          ? a.drugName.localeCompare(b.drugName)
          : (coveredDrugs.indexOf(a.nationalDrugCode) > -1) === true ? 1 : -1);
      });
    }
    return [];
  }

  get sortedDoctors() {
    if (this.providerService.isProviderDataExists(this.appData)) {
      return this.appData.profileDetails.providersDetails.providerIdList.sort((a, b) => {
        return ((a.plansList.indexOf(this.plan.planId) > -1) === (b.plansList.indexOf(this.plan.planId) > -1)
          ? a.providerName.localeCompare(b.providerName)
          : (a.plansList.indexOf(this.plan.planId) > -1) === true ? 1 : -1);
      });
    }
    return [];
  }

  get headerText() {
    return 'View ' + ((this.popupType === this.drug) ? 'Drug Pricing' : 'Providers');
  }

  get xOfxDrugsCoveredString() {
    const totalDrugs = this.drugsAndPharmacyService.isDrugsDataExists(this.appData) ? this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length : 0;
    const coveredDrugs = this.plan?.coveredDrugsCount ? this.plan.coveredDrugsCount : 0;

    return coveredDrugs + ' of ' + totalDrugs;
  }

  get xOfxProvidersCoveredString() {
    const totalProviders = this.providerService.isProviderDataExists(this.appData) ? this.appData.profileDetails.providersDetails.providerIdList.length : 0;
    const coveredProviders = totalProviders > 0 ? this.providerService.getCoveredProvidersCount(this.plan, this.appData.profileDetails.providersDetails.providerIdList) : 0;

    return coveredProviders + ' of ' + totalProviders;
  }

  isHospitalProvider(providerType: string) {
    return providerType === 'facility';
  }

  checkInvalidProviderName(providerName: string): string {
    return providerName
      && (providerName.trim() === ',' || providerName.trim() === '' || providerName.indexOf('null') > -1) ? AppConstants.savedProvider : providerName;
  }

  visitAddDrugPage(event?: any): void {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'DCE - Add Drug', { plan_name: this.plan?.planName }, TrackingConstants.eventType.ACTION);

    this.drugsAndPharmacyService.launchDCEWithPlanInfo(this.plan, this.appData);
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.code === 'Escape') {
      this.closeModalPopup.emit();
    }
  }

  close(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_DRUG);
    }
    this.closeModalPopup.emit();
  }

  backBtn_keydown(event: any) {
    if (!event.shiftKey && event.code === 'Tab') {
      if (this.drugpriceModal) {
        this.drugpriceModal.nativeElement.focus();
      }
      event.preventDefault();
    }
  }

  close_btn(event: any){
    if (event.shiftKey && event.code === 'Tab'){
      if (this.backBtn){
        this.backBtn.nativeElement.focus();
      }
      event.preventDefault();
    }
  }

  dlClickEvent(event: any){
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption, DL_CONTAINER.SAVED_DRUG);
    }
  }

}
