import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { NotificationComponent } from './notification.component';

describe('NotificationComponent - [UNIT TEST CASES]', () => {
  let component: NotificationComponent;
  let fixture: ComponentFixture<NotificationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NotificationComponent]
    });

    fixture = TestBed.createComponent(NotificationComponent);
    component = fixture.componentInstance;
  });

  it('Should create notification', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('show check icon', () => {
    component.profilePage = { checkIcon: 'icon.png'};
    fixture.detectChanges();
    const checkIcon = fixture.nativeElement.querySelector('img');
    expect(checkIcon).toBeTruthy();
    expect(checkIcon.getAttribute('src')).toEqual('icon.png');
  });

  it('check type binding', () => {
    component.profilePage = { checkIcon: 'icon.png'};
    component.type = 'type';

    fixture.detectChanges();

    const de = fixture.debugElement.query(By.css('.ml-10'));
    const el: HTMLElement = de.nativeElement;
    expect(el).toBeTruthy();
    expect(el.innerText).toBe('type.');
  });

  it('check dismiss button', fakeAsync(() => {
    component.profilePage = { dismissIcon: 'icon.png'};
    fixture.detectChanges();
    spyOn(component, 'dismiss').and.callThrough();
    const dismissEle = fixture.nativeElement.querySelectorAll('img')[1];
    expect(dismissEle).toBeTruthy();
    expect(dismissEle.getAttribute('src')).toEqual('icon.png');
    dismissEle.click();
    tick(100);
    fixture.detectChanges();
    expect(component.dismiss).toHaveBeenCalled();
  }));
});
