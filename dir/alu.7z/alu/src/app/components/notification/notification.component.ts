import { Component, Input, ViewEncapsulation, EventEmitter, Output, ViewChild, AfterViewInit, ElementRef } from '@angular/core';

import { DataLayerService } from '../../services/datalayer.service';

import { ProfilePage } from '../../models/ProfilePage';
import { DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-notification,[app-notification]',
  templateUrl: './notification.component.html',
  encapsulation : ViewEncapsulation.None
})
export class NotificationComponent implements AfterViewInit{
  @ViewChild('closeNotifyBtn') closeNotifyBtn: ElementRef;

  @Input() type: string;
  @Input() content: string;
  @Input() profilePage: ProfilePage;
  @Output() closeNotification = new EventEmitter();

  constructor(private readonly dataLayerService: DataLayerService) { }

  ngAfterViewInit(){
    setTimeout(() => {
      this.closeNotifyBtn.nativeElement.focus();
    }, 100);
  }

  dismiss(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.closeNotification.emit();
  }

}
