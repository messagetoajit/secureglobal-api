
import { Component, ViewEncapsulation, Input } from '@angular/core';

@Component({
  selector: 'app-popover,[app-popover]',
  templateUrl: './popover.component.html',
  encapsulation : ViewEncapsulation.None
})
export class PopoverComponent {

    @Input() title: string;
    @Input() content: string;

    showPopover = false;

    constructor() {}

    togglePopover(show: boolean) {
      this.showPopover = show;
    }

}
