import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { PopoverComponent } from './popover.component';

describe('PopoverComponent', () => {
    let component: PopoverComponent;
    let fixture: ComponentFixture<PopoverComponent>;
    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [
            PopoverComponent
        ],
        providers: [],
      });

      fixture = TestBed.createComponent(PopoverComponent);
      component = fixture.componentInstance;
    });

    it('check title binding', () => {
        component.title = 'title';

        fixture.detectChanges();

        const de = fixture.debugElement.query(By.css('.text-semibold'));
        const el: HTMLElement = de.nativeElement;

        expect(el.innerText).toBe(component.title);
    });

    it('check togglePopover function', fakeAsync(() => {
        component.showPopover = true;
        fixture.detectChanges();
        spyOn(component, 'togglePopover').and.callThrough();
        const comp = fixture.nativeElement.querySelector('.uhc-link-button');
        comp.click();
        tick();
        fixture.detectChanges();
        expect(component.togglePopover).toHaveBeenCalled();
    }));

    it('check content binding', () => {
        component.content = 'content';

        fixture.detectChanges();

        const de = fixture.debugElement.query(By.css('.text-normal'));
        const el: HTMLElement = de.nativeElement;

        expect(el.innerText).toBe(component.content);
    });
});
