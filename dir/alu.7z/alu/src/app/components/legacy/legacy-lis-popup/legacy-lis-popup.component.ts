import { Component, OnInit, Input, ViewEncapsulation, Output, EventEmitter, HostListener, AfterViewInit, ViewChild, ElementRef } from '@angular/core';

import { DataLayerService } from '../../../services/datalayer.service';

import { AppData } from '../../../models/AppData';
import { Plan } from '../../../models/Plan';
import { DL_EVENT_TYPE } from '../../../constants/datalayer-constants';

@Component({
  selector: 'app-legacy-lis-popup,[app-legacy-lis-popup]',
  templateUrl: './legacy-lis-popup.component.html',
  styleUrls: ['./legacy-lis-popup.component.scss'],
  encapsulation : ViewEncapsulation.None
})
export class LegacyLisPopupComponent implements OnInit, AfterViewInit {

  @ViewChild('helpModal') helpModal: ElementRef;
  @ViewChild('lisBackBtn') lisBackBtn: ElementRef;

  @Input() appData: AppData;
  @Input() plan: Plan;
  @Input() dlassetid: string;

  @Output() closeLongTermModalPopup = new EventEmitter();

  specialLisPlan = false;
  premiumInfo = '';

  constructor(private readonly dataLayerService: DataLayerService) { }

  ngAfterViewInit(){
    this.dataLayerService.setDLModalDataEvent(this.dlassetid, this.appData?.planBenefitsContent?.extraHelptext);
    this.helpModal.nativeElement.focus();
  }

  ngOnInit() {
    if (this.appData.planBenefitsContent && this.appData.planBenefitsContent.premiumInfo && this.plan && this.plan.planName) {
      this.premiumInfo = this.appData.planBenefitsContent.premiumInfo;
      this.premiumInfo = this.premiumInfo.replace('{{lisPlanInfo.planName}}', this.plan.planName);
    }
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.code === 'Escape') {
      this.closeLongTermModalPopup.emit();
    }
  }

  closePopup(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    this.closeLongTermModalPopup.emit();
  }

  backBtn_keydown(event: any) {
    if (!event.shiftKey && event.code === 'Tab') {
      if (this.helpModal) {
        this.helpModal.nativeElement.focus();
      }
      event.preventDefault();
    }
  }

}
