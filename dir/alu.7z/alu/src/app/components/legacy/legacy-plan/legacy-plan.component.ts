import { Component, Input, Output, EventEmitter, ViewEncapsulation, OnInit } from '@angular/core';

import { CookieService } from '../../../services/cookie.service';
import { OLEService } from '../../../services/ole.service';
import { UtilityService } from '../../../services/utility.service';
import { TooltipService } from '../../../services/tooltip.service';
import { ProviderService } from '../../../services/provider.service';
import { DateUtilityService } from '../../../services/date-utility.service';
import { StorageService } from '../../../services/storage.service';
import { DataLayerService } from '../../../services/datalayer.service';

import { AppData } from '../../../models/AppData';
import { ProfilePage } from '../../../models/ProfilePage';
import { Plan } from '../../../models/Plan';
import { OLE } from '../../../models/OLE';
import { AppConstants } from '../../../constants/app-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../../constants/datalayer-constants';

@Component({
  selector: 'app-legacy-plan,[app-legacy-plan]',
  templateUrl: './legacy-plan.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyPlanComponent implements OnInit {

  @Input() appData: AppData;
  @Input() plan: Plan;
  @Input() index: number;
  @Input() profilePage: ProfilePage;

  @Output() initiatePlanDelete = new EventEmitter();
  @Output() initiateDrugsAndPharmacyDataBuild = new EventEmitter();
  @Output() initiateProvidersDataBuild = new EventEmitter();

  showPlanDetails = true;
  showPlanDrugsAndPharmacyData = false;
  showPlanProvidersData = false;
  showLongTermModalPopup = false;
  renderingtime = 5000;
  continueEnrollmentText = AppConstants.continueEnrollment;
  submittedEnrollmentText = AppConstants.submitted;
  uniqueKey: string;

  constructor(
    private readonly oleService: OLEService,
    private readonly utilityService: UtilityService,
    private readonly cookieService: CookieService,
    private readonly providerService: ProviderService,
    private readonly tooltipService: TooltipService,
    private readonly dateUtilService: DateUtilityService,
    private readonly storageService: StorageService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit() {
    this.initiatetooltip();
    this.uniqueKey = this.plan.planType.toLowerCase() + '-' + (this.index + 1);
  }

  deletePlan(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planName: this.plan?.planName };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.initiatePlanDelete.emit({
      index: this.index,
      plan: this.plan
    });
  }

  onKeydown(event): void {
    if (event.key === 'Enter') {
      this.initiatePlanDelete.emit({
        index: this.index,
        plan: this.plan
      });
    }
  }

  goToPlanDetail() {
    this.providerService.setProvidersDataInBrowserStorage(this.appData);

    const params = `?contract_number=${this.plan.planId.substring(0, 5)}&pbp_number=${this.plan.planId.substring(5, 8)}` +
                   `&segment_ID=${this.plan.planId.substring(8)}&county_code=${this.plan.county.fipsCountyCode}` +
                   `&year=${this.plan.planYear}&profile=true&product=${this.plan.planType === 'MAPD' ? 'ma' : this.plan.planType.toLowerCase()}`;
    const zipCode = this.appData.profileDetails.plansDetails.zipCode;

    this.storageService.setItem_SS(AppConstants.geotrackingZip, zipCode);
    this.storageService.setItem_SS(AppConstants.vppZipcode, zipCode);
    this.storageService.setItem_LS(AppConstants.dcActiveYear, '' + this.plan.planYear);

    this.utilityService.disableDCEFlags();
    this.utilityService.goToVppPage(params);
  }

  enrollPlan(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planName: this.plan.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    const oleObj: OLE = new OLE();
    let oleCookieString: string;

    this.cookieService.deleteCookie(AppConstants.oleCookieName);

    const olePlan = this.appData.planSearchResultsList.find(p => this.plan.planId === p.planId);

    if (olePlan) {
      if (this.plan.enrollmentStatus && this.plan.enrollmentStatus === AppConstants.continueEnrollment) {
        const enrollment = this.appData.profileDetails.enrollmentsDetails.enrollments.find(e => e.planId === this.plan.planId && e.planYear === this.plan.planYear);

        if (enrollment && enrollment.formData && JSON.parse(enrollment.formData)) {
          this.oleService.setOLEFormData(enrollment);
        }
      }

      olePlan.monthlyPremiumFormatted = this.utilityService.getMonthlyPremiumValue(olePlan, this.appData);
      oleCookieString = this.oleService.setOleObj(this.plan, olePlan, oleObj, this.appData);
      this.cookieService.setCookie(AppConstants.oleCookieName, oleCookieString);
      location.href = oleObj.url;
    }
  }

  togglePlanDetails(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planType: this.plan?.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.showPlanDetails = !this.showPlanDetails;
  }

  initiatePlanDrugsAndPharmacyDataBuild() {
    this.initiateDrugsAndPharmacyDataBuild.emit();
  }

  initiatePlanProvidersDataBuild() {
    this.initiateProvidersDataBuild.emit();
  }

  togglePlanDrugsData() {
    this.showPlanDrugsAndPharmacyData = !this.showPlanDrugsAndPharmacyData;
    if (this.showPlanDrugsAndPharmacyData) {
      this.showPlanProvidersData = false;
    }
  }

  togglePlanProvidersData() {
    this.showPlanProvidersData = !this.showPlanProvidersData;
    if (this.showPlanProvidersData) {
      this.showPlanDrugsAndPharmacyData = false;
    }
  }

  openBenefitsPopup(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, undefined, DL_CONTAINER.SAVED_PLAN);
    }
    this.showLongTermModalPopup = true;
  }

  initiatetooltip() {
    setTimeout(() => {
      this.tooltipService.svgiconfunction();
      this.tooltipService.tooltipmessageservice();
    }, 100);
  }

  isDrugsAndPharmacyDataExists(appData: AppData) {
    return appData.profileDetails.drugsAndPharmacyDetails
      && appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails
      && (appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length > 0)
      && appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj
      && appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.pharmacyNumber;
  }

  isDrugsDataExists(appData: AppData) {
    return appData.profileDetails.drugsAndPharmacyDetails
      && appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails
      && (appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length > 0);
  }

  showEnrollmentButton() {
    const dceSystemYear = this.appData.dceSystemDateTime.getFullYear();
    const planYear = Number(this.plan.planYear);

    return ((planYear === dceSystemYear && this.dateUtilService.isBetween_Jan01_Nov30(this.appData.dceSystemDateTime))
      || (planYear === (dceSystemYear + 1) && this.dateUtilService.isBetween_Oct15_Dec31(this.appData.dceSystemDateTime)))
      && !this.isExcludedAcquiredPlan();
  }

  isExcludedAcquiredPlan() {
    return this.profilePage?.excludedAcquiredPlans?.indexOf(this.plan.planId) > -1;
  }

}
