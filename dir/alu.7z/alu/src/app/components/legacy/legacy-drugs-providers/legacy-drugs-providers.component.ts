import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';

import { ProviderService } from '../../../services/provider.service';
import { DrugsAndPharmacyService } from '../../../services/drugs-and-pharmacy.service';

import { AppData } from '../../../models/AppData';
import { ProfilePage } from '../../../models/ProfilePage';

@Component({
  selector: 'app-legacy-drugs-providers,[app-legacy-drugs-providers]',
  templateUrl: './legacy-drugs-providers.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyDrugsProvidersComponent implements OnInit {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;
  @Input() isUserLoggedIn: boolean;

  constructor(
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly providerService: ProviderService
  ) { }

  ngOnInit(): void {
  }

  isBothDrugsAndProvidersExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData)
      && this.isProviderDataExists();
  }

  getDrugsCount() {
    return this.isDrugsDataExists() ? this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length : 0;
  }

  getProvidersCount() {
    return this.isProviderDataExists() ? this.appData.profileDetails.providersDetails.providerIdList.length : 0;
  }

  isDrugsDataExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData);
  }

  isProviderDataExists() {
    return this.providerService.isProviderDataExists(this.appData);
  }

}
