import { Component, ViewEncapsulation, Input, EventEmitter, Output } from '@angular/core';

import { UserinfoService } from '../../../services/userinfo.service';
import { CookieService } from '../../../services/cookie.service';
import { DrugsAndPharmacyService } from '../../../services/drugs-and-pharmacy.service';
import { StorageService } from '../../../services/storage.service';
import { DataLayerService } from '../../../services/datalayer.service';

import { AppData } from '../../../models/AppData';
import { ProfilePage } from '../../../models/ProfilePage';
import { Drug } from '../../../models/Drug';
import { UserProfile } from '../../../models/UserProfile';
import { Plan } from '../../../models/Plan';
import { AppConstants } from '../../../constants/app-constants';
import { DL_EVENT_TYPE } from '../../../constants/datalayer-constants';

@Component({
  selector: 'app-legacy-plan-drugs,[app-legacy-plan-drugs]',
  templateUrl: './legacy-plan-drugs.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyPlanDrugsComponent {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;
  @Input() plan: Plan;
  @Input() index: number;
  @Input() showPlanDrugsAndPharmacyData: boolean;

  @Output() initiateDrugsAndPharmacyDataBuild = new EventEmitter();
  @Output() togglePlanDrugsData = new EventEmitter();

  siteId: string;

  constructor(
    private readonly userinfoService: UserinfoService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly cookieService: CookieService,
    private readonly storageService: StorageService,
    private readonly dataLayerService: DataLayerService
  ) {
    this.siteId = location.href.indexOf(AppConstants.aarpmedicareplans) > -1 ? AppConstants.aarp : AppConstants.uhc;
  }

  isShowPlanDrugs() {
    return this.plan.planType !== 'MA'
      && !(this.plan && this.appData?.planBenefitsContent?.piedmontPlanYear?.indexOf(this.plan.planYear) > -1
        && this.appData?.planBenefitsContent?.piedmontContentSuppressionList?.indexOf(this.plan.planId) > -1
      );
  }

  deleteDrug(index: number, drug: Drug, event?: any): void {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, drugId: drug?.drugId };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption);
    }
    this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.splice(index, 1);

    const uuid = this.cookieService.getUuidFromCookie();

    this.userinfoService.updateProfileData(uuid, 'drugs', this.getUpdatedDrugsData()).subscribe((response: any) => {
      console.log('Drug deleted successfully.');

      this.drugsAndPharmacyService.deleteDrugsFromBrowserStorage(drug);

      this.userinfoService.getProfileData(uuid, 'drugs', '').subscribe((data: UserProfile) => {
        this.appData.profileDetails.drugsAndPharmacyDetails = data.drugsAndPharmacyDetails;
        this.initiateDrugsAndPharmacyDataBuild.emit();

      }, (error1) => console.log(error1));

    }, (error) => {
      console.log(error);
      this.reInsertDrugOnFailure(index, drug);
    });
  }

  getUpdatedDrugsData(): any {
    return {
      drugsAndPharmacyDetails: this.appData.profileDetails.drugsAndPharmacyDetails
    };
  }

  reInsertDrugOnFailure(index: number, drug: Drug): void {
    this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.splice(index, 0, drug);
  }

  toggleDrugsData(): void {
    this.togglePlanDrugsData.emit();
  }

  launchDCEWithPlanInfo(event?: any): void {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, action: 'launch DCE' };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption);
    }
    this.cookieService.setLocationSessionCookie(this.plan.county, this.plan.planYear, this.plan.zipCode);
    this.cookieService.setDCEInitialCookie(this.siteId, this.cookieService.getLocationSessionCookie(), this.plan);

    const dceLaunchObject = this.drugsAndPharmacyService.getDCELaunchData(this.plan, this.appData.planSearchResultsList);
    this.storageService.setItem_SS(AppConstants.dceLaunchObj, JSON.stringify(dceLaunchObject));

    if (this.isDrugsDataExists()) {
      location.href = '/health-plans/estimate-drug-costs.html?profile=true&planEditDrug=true';
    } else {
      location.href = '/health-plans/estimate-drug-costs.html?profile=true&planAddDrug=true';
    }
  }

  onKeyClose(event: any) {
    if (event.keyCode === 9 && !event.shiftKey) {
      this.toggleDrugsData();
    }
  }

  isDrugsDataExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData);
  }

  isPharmacyExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData)
      && this.appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj
      && this.appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.pharmacyName;
  }

  getPharmacyAddress() {
    let adddress = '';
    const pharmacyAddress = this?.appData?.profileDetails?.drugsAndPharmacyDetails?.pharmacyObj?.pharmacyAddress;

    if (pharmacyAddress) {
      adddress += (pharmacyAddress.addressLine1 ? pharmacyAddress.addressLine1 : '');
      adddress += (pharmacyAddress.city ? ', ' + pharmacyAddress.city : '');
      adddress += (pharmacyAddress.state ? ', ' + pharmacyAddress.state : '');
      adddress += (pharmacyAddress.zipCode ? ', ' + pharmacyAddress.zipCode : '');
    }
    return adddress;
  }

}
