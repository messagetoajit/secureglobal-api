import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';

import { PlanService } from '../../../services/plan.service';
import { CookieService } from '../../../services/cookie.service';
import { ProviderService } from '../../../services/provider.service';
import { UserinfoService } from '../../../services/userinfo.service';
import { DataLayerService } from '../../../services/datalayer.service';

import { Plan } from '../../../models/Plan';
import { AppData } from '../../../models/AppData';
import { Provider } from '../../../models/Provider';
import { ProfilePage } from '../../../models/ProfilePage';
import { UserProfile } from '../../../models/UserProfile';
import { AppConstants } from '../../../constants/app-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../../constants/datalayer-constants';

@Component({
  selector: 'app-legacy-plan-providers,[app-legacy-plan-providers]',
  templateUrl: './legacy-plan-providers.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyPlanProvidersComponent {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;
  @Input() plan: Plan;
  @Input() index: number;
  @Input() showPlanProvidersData: boolean;

  @Output() initiateProvidersDataBuild = new EventEmitter();
  @Output() togglePlanProvidersData = new EventEmitter();

  providerInterval: any;
  uhcDualCompHMODSNP2021Plan = AppConstants.uhcDualCompHMODSNP2021Plan;

  constructor(
    private readonly planService: PlanService,
    private readonly userinfoService: UserinfoService,
    private readonly providerService: ProviderService,
    private readonly cookieService: CookieService,
    private readonly dataLayerService: DataLayerService
  ) {}

  deleteProvider(index: number, provider: Provider, event?: any): void {
    if (event) {
      const selectedOption = { providerId: provider?.providerId, planId: this.plan?.planId };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    this.providerService.setProvidersDataInBrowserStorage(this.appData);
    this.appData.profileDetails.providersDetails.providerIdList.splice(index, 1);

    const uuid = this.cookieService.getUuidFromCookie();

    this.userinfoService.updateProfileData(uuid, 'providers', this.getUpdatedProvidersData()).subscribe((response: any) => {
      console.log('Provider deleted successfully.');

      this.providerService.deleteProviderFromCookie(provider, this.appData);

      this.userinfoService.getProfileData(uuid, 'providers', '').subscribe((data: UserProfile) => {
        this.appData.profileDetails.providersDetails = data.providersDetails;
        this.initiateProvidersDataBuild.emit();

      }, (error1) => console.log(error1));

    }, (error) => {
      console.log(error);
      this.reInsertProviderOnFailure(index, provider);
    });
  }

  getUpdatedProvidersData(): any {
    const isGuestUser = this.cookieService.isGuestUser();
    return {
      providersDetails: this.appData.profileDetails.providersDetails,
      isGuest: isGuestUser
    };
  }

  reInsertProviderOnFailure(index: number, provider: Provider): void {
    this.appData.profileDetails.providersDetails.providerIdList.splice(index, 0, provider);
  }

  toggleProvidersData(): void {
    this.togglePlanProvidersData.emit();
  }

  searchProvider(event?: any) {
    if (event) {
      const selectedOption = { planId: this.plan?.planId, planType: this.plan.planType };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PLAN);
    }
    const anyProviderEligibleFederalPlan = this.planService.getAnyProviderEligibleFederalPlan(this.appData);

    if (anyProviderEligibleFederalPlan) {
      this.providerService.searchProvider(this.appData, anyProviderEligibleFederalPlan);

      this.providerService.getRallyProviderSearchNotification().subscribe((msg: any) => {
        console.log('Rally Provider Search Completed.');

        if (msg?.providerSearchComplete) {
          console.log('Going to rebuild providers data ...');
          this.initiateProvidersDataBuild.emit();
        }
      });
    }
  }

  checkCoverageCount(providerIdList: any) {
    const count = providerIdList.reduce((accumulator, list) => accumulator += list.plansList.indexOf(this.plan.planId) > -1 ? 1 : 0, 0);
    return count;
  }

  isProviderDataExists() {
    return this.providerService.isProviderDataExists(this.appData);
  }

  checkInvalidProviderName(providerName: string): string {
    return providerName && (providerName.trim() === ',' || providerName.trim() === '' || providerName.indexOf('null') > -1) ? AppConstants.savedProvider : providerName;
  }

  onKeyClose(event: any) {
    if (event.keyCode === 9 && !event.shiftKey) {
      this.toggleProvidersData();
    }
  }

}
