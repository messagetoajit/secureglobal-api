import { Component, OnInit, ViewEncapsulation, Input, ViewChild, ElementRef } from '@angular/core';

import { DrugsAndPharmacyService } from '../../../services/drugs-and-pharmacy.service';
import { StorageService } from '../../../services/storage.service';
import { DataLayerService } from '../../../services/datalayer.service';

import { AppData } from '../../../models/AppData';
import { ProfilePage } from '../../../models/ProfilePage';
import { AppConstants } from '../../../constants/app-constants';
import { DL_EVENT_TYPE } from '../../../constants/datalayer-constants';

@Component({
  selector: 'app-legacy-drugs,[app-legacy-drugs]',
  templateUrl: './legacy-drugs.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyDrugsComponent implements OnInit {

  @ViewChild('savedDrugs') savedDrugs: ElementRef;

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;

  constructor(
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly storageService: StorageService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void {
  }

  isDrugsDataExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData);
  }

  isPharmacyExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData)
      && this.appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj
      && this.appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.pharmacyName;
  }

  launchDCE(event?: any): void {
    if (event){
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.storageService.setItem_SS(AppConstants.isDefaultPlan, AppConstants.TRUE_VALUE);
    location.href = '/health-plans/estimate-drug-costs.html?profile=true';
  }

}
