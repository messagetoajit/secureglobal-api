import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

import { UtilityService } from '../../../services/utility.service';
import { UserinfoService } from '../../../services/userinfo.service';
import { ProviderService } from '../../../services/provider.service';
import { DrugsAndPharmacyService } from '../../../services/drugs-and-pharmacy.service';
import { TrackingService } from '../../../services/tracking.service';
import { DataLayerService } from '../../../services/datalayer.service';

import { ProfilePage } from '../../../models/ProfilePage';
import { AppData } from '../../../models/AppData';
import { TrackingConstants } from '../../../constants/tracking-constants';
import { DL_EVENT_TYPE } from '../../../constants/datalayer-constants';

@Component({
  selector: 'app-legacy-dashboard-header,[app-legacy-dashboard-header]',
  templateUrl: './legacy-dashboard-header.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyDashboardHeaderComponent implements OnInit {

  @Input() userDetails: any;
  @Input() profilePage: ProfilePage;
  @Input() appData: AppData;

  constructor(
    private readonly utilityService: UtilityService,
    private readonly userinfoService: UserinfoService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly providerService: ProviderService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void {
  }

  isAuthenticatedUser() {
    return this.userDetails && this.userDetails.firstName;
  }

  renderFirstName() {
    return this.userDetails && this.userDetails.firstName
      ? this.utilityService.renderFirstName(this.userDetails.firstName) : '';
  }

  signIn(event?: any): void {
    if (event) {
      const selectedOption = { action: 'User sign in' };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'User sign in', {}, TrackingConstants.eventType.ACTION);

    this.utilityService.navigateToURL(this.profilePage.signInUrl);
  }

  signOut(event?: any): void {
    if (event) {
      const selectedOption = { action: 'User sign out'};
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption);
    }
    this.userinfoService.logout().subscribe(data => {
      this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'User sign out', {}, TrackingConstants.eventType.ACTION);

      this.userinfoService.deleteBrowserStorage();
      location.href = '/';

    }, (error) => console.log(error));
  }

  getDrugsCount() {
    let count = 0;
    if (this.drugsAndPharmacyService.isDrugsDataExists(this.appData)) {
      count = this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length;
    }
    return count;
  }

  getProvidersCount() {
    let count = 0;
    if (this.providerService.isProviderDataExists(this.appData)) {
      count = this.appData.profileDetails.providersDetails.providerIdList.length;
    }
    return count;
  }

  scrollTo(id, event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.utilityService.scrollToElement(id, true);
  }

}
