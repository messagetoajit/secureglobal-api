import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';

import { ProviderService } from '../../../services/provider.service';

import { AppData } from '../../../models/AppData';
import { ProfilePage } from '../../../models/ProfilePage';
import { Provider } from '../../../models/Provider';
import { AppConstants } from '../../../constants/app-constants';

@Component({
  selector: 'app-legacy-providers,[app-legacy-providers]',
  templateUrl: './legacy-providers.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyProvidersComponent implements OnInit {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;

  constructor(
    private readonly providerService: ProviderService
  ) { }

  ngOnInit(): void {
  }

  isProviderDataExists() {
    return this.providerService.isProviderDataExists(this.appData);
  }

  isHospitalProvider(provider: Provider) {
    return provider
      && provider.providerType
      && provider.providerType === 'facility';
  }

  checkInvalidProviderName(providerName: string): string {
    return providerName
      && (providerName.trim() === ',' || providerName.trim() === '' || providerName.indexOf('null') > -1) ? AppConstants.savedProvider : providerName;
  }

}
