import { Component, OnInit, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';

import { DataLayerService } from '../../../services/datalayer.service';

import { ProfilePage } from '../../../models/ProfilePage';
import { DL_EVENT_TYPE } from '../../../constants/datalayer-constants';

@Component({
  selector: 'app-legacy-add-plans,[app-legacy-add-plans]',
  templateUrl: './legacy-add-plans.component.html',
  encapsulation : ViewEncapsulation.None
})
export class LegacyAddPlansComponent implements OnInit {

  @Input() profilePage: ProfilePage;
  @Input() isUserLoggedIn: boolean;

  @Output() addPlans = new EventEmitter();

  constructor(private readonly dataLayerService: DataLayerService) { }

  ngOnInit(): void {
  }

  redirectToVPP(event?: any) {
    if (event) {
      const selectedOption = { action: 'Navigate to VPP' };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption);
    }
    this.addPlans.emit();
  }

}
