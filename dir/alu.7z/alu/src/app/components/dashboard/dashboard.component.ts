import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-dashboard,[app-dashboard]',
  template: '',
  encapsulation : ViewEncapsulation.None
})
export class DashboardComponent {

  constructor() { }

}
