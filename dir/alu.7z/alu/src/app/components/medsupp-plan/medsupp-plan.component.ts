import { Component, ViewEncapsulation, AfterViewInit, Renderer2, Inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-medsupp-plan',
  templateUrl: './medsupp-plan.component.html',
  encapsulation : ViewEncapsulation.None
})
export class MedsuppPlanComponent implements AfterViewInit {

  constructor(
    private readonly renderer2: Renderer2,
    @Inject(DOCUMENT) private readonly document
  ) {
  }

  ngAfterViewInit(): void {
    const scriptElement = this.renderer2.createElement('script');
    scriptElement.type = 'text/javascript';
    scriptElement.src = '/iscq_ash/vpp/ms.loader.uLayer.js';
    scriptElement.setAttribute('id', 'is_cq_widget_script');
    scriptElement.setAttribute('data-for-script', '');

    this.renderer2.appendChild(this.document.body, scriptElement);
  }

}
