import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { MedsuppPlanComponent } from './medsupp-plan.component';

describe('PlanComponent', () => {
  let component: MedsuppPlanComponent;
  let fixture: ComponentFixture<MedsuppPlanComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ MedsuppPlanComponent ]
    }).compileComponents();

    fixture = TestBed.createComponent(MedsuppPlanComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

});
