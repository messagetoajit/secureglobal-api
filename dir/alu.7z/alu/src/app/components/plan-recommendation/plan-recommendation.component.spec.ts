import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { AppData } from '../../models/AppData';
import { PlanRecommendationComponent } from './plan-recommendation.component';
import { AppConstants } from 'src/app/constants/app-constants';
import { EnrollmentsDetails } from 'src/app/models/EnrollmentsDetails';
import { PlanEnrollment } from 'src/app/models/PlanEnrollment';
import { UtilityService } from 'src/app/services/utility.service';
import { OLEService } from 'src/app/services/ole.service';

describe('PlanRecommendationComponent', () => {
  let component: PlanRecommendationComponent;
  let fixture: ComponentFixture<PlanRecommendationComponent>;
  let utilityService: UtilityService;
  let oleService: OLEService

  const label1 = 'div.uhc-pre-card__label';
  const val1 = '#1 recommendationText';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ PlanRecommendationComponent ],
      providers: [ UtilityService, OLEService ]
    }).compileComponents();

    fixture = TestBed.createComponent(PlanRecommendationComponent);
    utilityService = TestBed.get(UtilityService);
    oleService = TestBed.get(OLEService);
    component = fixture.componentInstance;
    component.appData = new AppData();
  });

  it('should create', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('Current UI: No Recommendations', () => {
    component.profilePage = { yourPREPlanRecommendationsText: 'testPreText'};
    component.appData.preRecommendationType = component.PRE_EMPTY;
    fixture.detectChanges();
    const headerTextEle = fixture.nativeElement.querySelector('h2');
    expect(headerTextEle).toBeTruthy();
    expect(headerTextEle.innerText).toEqual('testPreText');
  });

  it('Current UI: No Recommendations click get started', fakeAsync (() => {
    component.profilePage = { yourPREPlanRecommendationsText: 'testPreText'};
    component.appData.preRecommendationType = component.PRE_EMPTY;
    fixture.detectChanges();
    spyOn(component, 'gotoPRE');
    const recommendBtn = fixture.nativeElement.querySelector('button');
    recommendBtn.click();
    tick(); // simulates the passage of time until all pending asynchronous activities finish
    fixture.detectChanges();
    expect(component.gotoPRE).toHaveBeenCalled();
  }));

  it('Current UI: Ranked Recommendations', fakeAsync (() => {
    component.profilePage = {
      yourPREPlanRecommendationsText: 'testPreText',
      editYourResponseText: 'responseText',
      partCPlansText: 'planCategory',
      recommendationText: 'recommendationText',
      rankedRecommendationsSubText: 'rankedRecommendationsSubText'
    };
    component.appData.preRecommendationType = component.PRE_RANKED;
    component.appData.preRecommendationResults = [{planType: 'MA'},{planType: 'PDP'}];
    fixture.detectChanges();
    spyOn(component, 'editPREResponse');
    expect(fixture.nativeElement.querySelector('h2').innerText).toEqual('testPreText');
    expect(fixture.nativeElement.querySelector('h3').innerText).toEqual('planCategory');
    expect(fixture.nativeElement.querySelector(label1).innerText).toEqual(val1);
    const editLink = fixture.nativeElement.querySelector('a');
    editLink.click();
    tick();
    fixture.detectChanges();
    expect(component.editPREResponse).toHaveBeenCalled();
  }));

  it('Current UI: Ranked Recommendations click recommend button', fakeAsync (() => {
    component.profilePage = {
      partCPlansText: 'planCategory'
    };
    component.appData.preRecommendationType = component.PRE_RANKED;
    component.appData.preRecommendationResults = [{planType: 'MA'},{planType: 'MS'}];
    fixture.detectChanges();
    spyOn(component, 'viewRecommendedPlans').and.callThrough();
    const recommendBtn = fixture.nativeElement.querySelector('button');
    recommendBtn.click();
    tick();
    fixture.detectChanges();
    expect(component.viewRecommendedPlans).toHaveBeenCalled();
  }));

  it('Current UI: EQUAL Recommendations', fakeAsync (() => {
    component.profilePage = {
      yourPREPlanRecommendationsText: 'testPreText',
      editYourResponseText: 'responseText',
      partCPlansText: 'planCategory',
      recommendationText: 'recommendationText',
      equalRecommendationsSubText: 'equalRecommendationsSubText',
    };
    component.appData.preRecommendationType = component.PRE_EQUAL;
    component.appData.preRecommendationResults = [{planType: 'MA'},{planType: 'SNP'}];
    fixture.detectChanges();
    spyOn(component, 'editPREResponse');
    expect(fixture.nativeElement.querySelector('h2').innerText).toEqual('testPreText');
    expect(fixture.nativeElement.querySelector('h3').innerText).toEqual('planCategory');
    expect(fixture.nativeElement.querySelector(label1).innerText).toEqual('recommendationText');
    const editLink = fixture.nativeElement.querySelector('a');
    editLink.click();
    tick();
    fixture.detectChanges();
    expect(component.editPREResponse).toHaveBeenCalled();
  }));

  it('Current UI: EQUAL Recommendations click recommend button', fakeAsync (() => {
    component.profilePage = {
      partCPlansText: 'planCategory'
    };
    component.appData.preRecommendationType = component.PRE_EQUAL;
    component.appData.preRecommendationResults = [{planType: 'MA'}];
    fixture.detectChanges();
    spyOn(component, 'viewRecommendedPlans').and.callThrough();
    const recommendBtn = fixture.nativeElement.querySelector('button');
    recommendBtn.click();
    tick();
    fixture.detectChanges();
    expect(component.viewRecommendedPlans).toHaveBeenCalled();
  }));

  it('Current UI: SINGLE Recommendations', fakeAsync (() => {
    component.profilePage = {
      yourPREPlanRecommendationsText: 'testPreText',
      editYourResponseText: 'responseText',
      partCPlansText: 'planCategory',
      recommendationText: 'recommendationText'
    };
    component.appData.preRecommendationType = component.PRE_SINGLE;
    component.appData.preRecommendationResults = [{planType: 'MA'}];
    fixture.detectChanges();
    spyOn(component, 'editPREResponse');
    expect(fixture.nativeElement.querySelector('h2').innerText).toEqual('testPreText');
    expect(fixture.nativeElement.querySelector('h3').innerText).toEqual('planCategory');
    expect(fixture.nativeElement.querySelector(label1).innerText).toEqual(val1);
    const editLink = fixture.nativeElement.querySelector('a');
    editLink.click();
    tick();
    fixture.detectChanges();
    expect(component.editPREResponse).toHaveBeenCalled();
  }));

  it('Current UI: NONE Recommendations', fakeAsync (() => {
    component.profilePage = {
      yourPREPlanRecommendationsText: 'testPreText',
      editYourResponseText: 'responseText',
      talkToExpertText: 'talkToExpertText',
    };
    component.appData.preRecommendationType = component.PRE_NONE;
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('h3').innerText).toEqual('talkToExpertText');
  }));

  it('New UI: No 1 Ranked Plan Recommendations', fakeAsync (() => {
    const currYear = new Date().getFullYear() + '';
    component.profilePage = {
      yourPREPlanRecommendationsText: 'testPreText',
      editYourResponseText: 'responseText',
      recommendationText: 'recommendationText',
      // enrollInPREPlanText: 'enrollInPREPlanText'
    };
    component.appData.dceSystemDateTime = new Date();
    component.appData.preRecommendationType = component.PRE_NO_1_RANKED_PLAN;
    component.appData.preNo1RankedPlan = { 
      rank: '1', planId: 'H3307002000', planType: 'MAPD', planYear: currYear,
      planName: 'AARP Medicare Advantage Plan 1 (HMO)', county: 'test',
      enrollmentStatus: AppConstants.continueEnrollment,
      details: {}
    };
    component.appData.profileDetails.enrollmentsDetails = new EnrollmentsDetails();
    var planEnrollment = new PlanEnrollment()
    planEnrollment.planYear = currYear;
    planEnrollment.planId = 'H3307002000';
    component.appData.profileDetails.enrollmentsDetails.enrollments = [ planEnrollment ];

    spyOn(oleService, 'setOLEFormData');
    spyOn(component, 'enrollPlan').and.callThrough();
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector(label1).innerText).toEqual(val1);
    var contEnrollBtn = fixture.nativeElement.querySelector('button');
    expect(contEnrollBtn).toBeTruthy();
    contEnrollBtn.click();
    tick();
    expect(component.enrollPlan).toHaveBeenCalled();
  }));

  it('New UI: No 1 Ranked Plan Recommendations', fakeAsync (() => {
    const currYear = new Date().getFullYear() + '';
    component.profilePage = {
      yourPREPlanRecommendationsText: 'testPreText',
      editYourResponseText: 'responseText',
      recommendationText: 'recommendationText',
      viewRecommendedPlanDetailsText: 'viewRecommendedPlanDetailsText'
    };
    component.appData.dceSystemDateTime = new Date();
    component.appData.preRecommendationType = component.PRE_NO_1_RANKED_PLAN;
    component.appData.preNo1RankedPlan = { 
      rank: '1', planId: 'H3307002000', planType: 'MAPD', planYear: currYear,
      planName: 'AARP Medicare Advantage Plan 1 (HMO)', county: 'test',
      enrollmentStatus: AppConstants.continueEnrollment,
      details: {}
    };
    component.appData.profileDetails.enrollmentsDetails = new EnrollmentsDetails();
    var planEnrollment = new PlanEnrollment()
    planEnrollment.planYear = currYear;
    planEnrollment.planId = 'H3307002000';
    component.appData.profileDetails.enrollmentsDetails.enrollments = [ planEnrollment ];

    spyOn(component, 'openPlanDetailsPage').and.callThrough();
    spyOn(utilityService, 'goToVppPage');
    fixture.detectChanges();
    var viewRecLink = fixture.nativeElement.querySelectorAll('a')[1];
    expect(viewRecLink).toBeTruthy();
    viewRecLink.click();
    tick();
    expect(component.openPlanDetailsPage).toHaveBeenCalled();
  }));

});
