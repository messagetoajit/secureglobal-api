import { Component, OnInit, ViewEncapsulation, Input } from '@angular/core';

import { TrackingService } from '../../services/tracking.service';
import { PREService } from '../../services/pre.service';
import { OLEService } from '../../services/ole.service';
import { CookieService } from '../../services/cookie.service';
import { UtilityService } from '../../services/utility.service';
import { StorageService } from '../../services/storage.service';
import { DateUtilityService } from '../../services/date-utility.service';
import { DataLayerService } from '../../services/datalayer.service';

import { OLE } from '../../models/OLE';
import { AppData } from '../../models/AppData';
import { ProfilePage } from '../../models/ProfilePage';
import { AppConstants } from '../../constants/app-constants';
import { TrackingConstants } from '../../constants/tracking-constants';
import { Plan } from '../../models/Plan';
import { County } from '../../models/County';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-plan-recommendation,[app-plan-recommendation]',
  templateUrl: './plan-recommendation.component.html',
  styleUrls: ['./plan-recommendation.component.scss'],
  encapsulation : ViewEncapsulation.None
})
export class PlanRecommendationComponent implements OnInit {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;
  @Input() tollFreeNumber: string;

  PRE_EMPTY = AppConstants.PRE_EMPTY;
  PRE_RANKED = AppConstants.PRE_RANKED;
  PRE_EQUAL = AppConstants.PRE_EQUAL;
  PRE_SINGLE = AppConstants.PRE_SINGLE;
  PRE_SINGLE_UNRANKED = AppConstants.PRE_SINGLE_UNRANKED;
  PRE_NONE = AppConstants.PRE_NONE;
  PRE_NO_1_RANKED_PLAN = AppConstants.PRE_NO_1_RANKED_PLAN;
  PLAN_TYPE_1 = '##PLAN_TYPE_1##';
  PLAN_TYPE_2 = '##PLAN_TYPE_2##';

  continueEnrollmentText = AppConstants.continueEnrollment;
  submittedEnrollmentText = AppConstants.submitted;

  constructor(
    private readonly preService: PREService,
    private readonly oleService: OLEService,
    private readonly cookieService: CookieService,
    private readonly utilityService: UtilityService,
    private readonly storageService: StorageService,
    private readonly trackingService: TrackingService,
    private readonly dateUtilService: DateUtilityService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void {}

  get isDisplayNoOnePRERankedPlan() {
    return this.appData?.isDisplayNoOnePRERankedPlan;
  }

  get planRecommendations() {
    return this.appData.preRecommendationResults?.length > 0 ? this.appData.preRecommendationResults : [];
  }

  get no1RankedPlan() {
    return this.appData.preNo1RankedPlan;
  }

  get no1RankedPlanRecommendationMonthlyPremium() {
    return this.no1RankedPlan?.formattedMonthlyPremium || AppConstants.defaultCostValue;
  }

  get subText() {
    let subTextString = '';
    const recommendations = this.planRecommendations;

    if (this.appData.preRecommendationType === this.PRE_RANKED) {
      subTextString = this.profilePage.rankedRecommendationsSubText;

      if (recommendations?.length > 1) {
        subTextString = subTextString?.replace(this.PLAN_TYPE_1, this.getPlanTypeDesc(recommendations[0].planType));
        subTextString = subTextString?.replace(this.PLAN_TYPE_2, this.getPlanTypeDesc(recommendations[1].planType));
      }

    } else if (this.appData.preRecommendationType === this.PRE_EQUAL) {
      subTextString = this.profilePage.equalRecommendationsSubText;

      if (recommendations?.length > 1) {
        subTextString = subTextString?.replace(this.PLAN_TYPE_1, this.getPlanTypeDesc(recommendations[0].planType));
        subTextString = subTextString?.replace(this.PLAN_TYPE_2, this.getPlanTypeDesc(recommendations[1].planType));
      }

    } else if (this.appData.preRecommendationType === this.PRE_SINGLE || this.appData.preRecommendationType === this.PRE_SINGLE_UNRANKED) {
      subTextString = this.profilePage.singleRecommendationSubText;

      if (recommendations?.length === 1) {
        subTextString = subTextString?.replace(this.PLAN_TYPE_1, this.getPlanTypeDesc(recommendations[0].planType));
      }

    } else if (this.appData.preRecommendationType === this.PRE_NONE) {
      subTextString = this.profilePage.noRecommendationsSubText;

    } else if (this.appData.preRecommendationType === this.PRE_NO_1_RANKED_PLAN) {
      subTextString = this.profilePage.no1RankedPlanRecommendationSubText;
    }

    return subTextString;
  }

  getPlanTypeDesc(planType: string) {
    if (planType?.indexOf('MA') > -1) {
      return this.profilePage?.partCPlanText;

    } else if (planType?.indexOf('PDP') > -1) {
      return this.profilePage?.partDPlanText;

    } else if (planType?.indexOf('SNP') > -1) {
      return this.profilePage?.snpPlanText;

    } else if (planType?.indexOf('MS') > -1) {
      return this.profilePage?.medsuppPlanText;
    }
    return '';
  }

  getPlancategory(planType: string) {
    if (planType?.indexOf('MA') > -1) {
      return this.profilePage?.partCPlansText;

    } else if (planType?.indexOf('PDP') > -1) {
      return this.profilePage?.partDPlansText;

    } else if (planType?.indexOf('SNP') > -1) {
      return this.profilePage?.snpPlansText;

    } else if (planType?.indexOf('MS') > -1) {
      return this.profilePage?.medsuppPlansText;
    }
    return '';
  }

  gotoPRE(event?: any) {
    if (event){
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, undefined, DL_CONTAINER.PRE);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Plan Recommendation button clicked', { ...this.planRecommendations }, TrackingConstants.eventType.ACTION);

    location.href = this.profilePage.prePageUrl;
  }

  viewRecommendedPlans(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, undefined, DL_CONTAINER.PRE);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'View Plan Recommendations button clicked', { ...this.planRecommendations }, TrackingConstants.eventType.ACTION);

    const zipCode = this.appData?.preRecommendationObj?.location?.zipcode;
    const fipsCountyCode = this.appData?.preRecommendationObj?.location?.selectedCounty?.fipsCountyCode;
    const planYear = this.appData?.preRecommendationObj?.planYear ? this.appData.preRecommendationObj.planYear : new Date().getFullYear();

    if (zipCode && fipsCountyCode && planYear) {
      this.preService.setPREDataInBrowserStorage(this.appData);

      const url = `?zipcode=${zipCode}&fips_county_code=${fipsCountyCode}&app=Profile&year=${planYear}#/plan-summary`;
      this.utilityService.goToVppPage(url);

    } else {
      console.log('Not enough data to view recommended plans');
      console.log(this.appData?.preRecommendationObj);
    }
  }

  viewRecommendedPlansinPRE(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, undefined, DL_CONTAINER.PRE);
    }
    this.trackingService.track(TrackingConstants.infoType.ADDITION_INFO, 'AMP # PRE Recommention result', {...this.planRecommendations}, TrackingConstants.eventType.ACTION);

    this.preService.setPREDataInBrowserStorage(this.appData);

    location.href = this.profilePage.viewPREResultsUrl;
  }

  editPREResponse(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, undefined, DL_CONTAINER.PRE);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'PRE Edit Responses link clicked', { ...this.planRecommendations }, TrackingConstants.eventType.ACTION);
    this.preService.setPREDataInBrowserStorage(this.appData);

    const url = this.profilePage.editPREResponsesUrl;
    this.utilityService.navigateToURL(url);
  }

  enrollPlan(prePlan: any, event?: any) {
    if (event) {
      const selectedOption = { planId: prePlan?.planId };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption, DL_CONTAINER.PRE);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Enroll Plan', { plan_name: prePlan.planName }, TrackingConstants.eventType.ACTION);

    this.cookieService.deleteCookie(AppConstants.oleCookieName);

    const planDetailsObj = prePlan.details;

    if (planDetailsObj) {
      if (prePlan.enrollmentStatus && prePlan.enrollmentStatus === AppConstants.continueEnrollment) {
        const enrollment = this.appData.profileDetails.enrollmentsDetails.enrollments.find(e => e.planId === prePlan.planId && e.planYear === prePlan.planYear);

        if (enrollment && enrollment.formData && JSON.parse(enrollment.formData)) {
          this.oleService.setOLEFormData(enrollment);
        }
      }

      planDetailsObj.monthlyPremiumFormatted = this.utilityService.getMonthlyPremiumValue(planDetailsObj, this.appData);

      const oleObj: OLE = new OLE();
      const favPlan: Plan = this.getPlanDataFromPRERankedPlan(prePlan);
      const oleCookieString = this.oleService.setOleObj(favPlan, planDetailsObj, oleObj, this.appData);

      this.cookieService.setCookie(AppConstants.oleCookieName, oleCookieString);

      location.href = oleObj.url;
    }
  }

  getPlanDataFromPRERankedPlan(prePlan: any): Plan {
    const plan = new Plan();
    plan.county = new County();

    if (prePlan && prePlan.county) {
      plan.planId = prePlan.planId;
      plan.planName = prePlan.planName;
      plan.planType = prePlan.planType;
      plan.planYear = prePlan.planYear;
      plan.zipCode = prePlan.zipCode;
      plan.county.fipsCountyCode = prePlan.county.fipsCountyCode;
      plan.county.fipsCountyName = prePlan.county.fipsCountyName;
      plan.county.fipsStateCode = prePlan.county.fipsStateCode;
      plan.county.stateCode = prePlan.county.stateCode;
      plan.county.cmsCountyCodes = prePlan.county.cmsCountyCodes;
    }
    return plan;
  }

  openPlanDetailsPage(prePlan: any, event?: any) {
    if (event) {
      const selectedOption = { action: 'Open Plan Detail Page', planId: prePlan?.planId };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption, DL_CONTAINER.PRE);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Open Plan Detail Page', { plan_name: prePlan.planName }, TrackingConstants.eventType.ACTION);

    const zipCode = this.appData?.preRecommendationObj?.location?.zipcode;
    const fipsCountyCode = this.appData?.preRecommendationObj?.location?.selectedCounty?.fipsCountyCode;

    const params = `?contract_number=${prePlan.planId.substring(0, 5)}&pbp_number=${prePlan.planId.substring(5, 8)}` +
                    `&segment_ID=${prePlan.planId.substring(8)}&county_code=${fipsCountyCode}` +
                    `&year=${prePlan.planYear}&profile=true&product=${prePlan.planType === 'MAPD' ? 'ma' : prePlan.planType.toLowerCase()}`;

    this.storageService.setItem_SS(AppConstants.geotrackingZip, zipCode);
    this.storageService.setItem_SS(AppConstants.vppZipcode, zipCode);
    this.storageService.setItem_LS(AppConstants.dcActiveYear, '' + prePlan.planYear);

    this.utilityService.disableDCEFlags();
    this.utilityService.goToVppPage(params);
  }

  isExcludedAcquiredPlan(prePlan: any) {
    return this.profilePage?.excludedAcquiredPlans?.indexOf(prePlan.planId) > -1;
  }

  showEnrollmentButton(prePlan: any) {
    const dceSystemYear = this.appData.dceSystemDateTime.getFullYear();
    const planYear = Number(prePlan.planYear);

    return ((planYear === dceSystemYear && this.dateUtilService.isBetween_Jan01_Nov30(this.appData.dceSystemDateTime))
      || (planYear === (dceSystemYear + 1) && this.dateUtilService.isBetween_Oct15_Dec31(this.appData.dceSystemDateTime)))
      && !this.isExcludedAcquiredPlan(prePlan);
  }

  dlClickEvent(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, DL_CONTAINER.PRE);
    }
  }

}
