import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { AddPlansComponent } from './add-plans.component';
import { AppData } from 'src/app/models/AppData';

describe('AddPlansComponent', () => {
  let component: AddPlansComponent;
  let fixture: ComponentFixture<AddPlansComponent>;
  const findPlanText = 'Find Plans';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ AddPlansComponent ],
      providers: [ CurrencyPipe ]
    }).compileComponents();

    fixture = TestBed.createComponent(AddPlansComponent);
    component = fixture.componentInstance;
    component.appData = new AppData();
  });

  it('should create', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('show find plans icon', () => {
    component.profilePage = { FindPlansIcon: 'icon.png'};
    fixture.detectChanges();
    const findPlansIcon = fixture.nativeElement.querySelector('img');
    expect(findPlansIcon).toBeTruthy();
    expect(findPlansIcon.getAttribute('src')).toEqual('icon.png');
  });

  it('show find plans button', () => {
    component.profilePage = { FindPlansButton: findPlanText};
    fixture.detectChanges();
    const findPlansBtn = fixture.nativeElement.querySelector('button.uhc-button');
    expect(findPlansBtn).toBeTruthy();
    expect(findPlansBtn.querySelector('span').innerText).toEqual(findPlanText);
  });

  it('redirectToVPP should called after find plans button click', fakeAsync (() => {
    component.profilePage = { FindPlansButton: findPlanText};
    fixture.detectChanges();
    spyOn(component, 'redirectToVPP').and.callThrough();
    const findPlansBtn = fixture.nativeElement.querySelector('button.uhc-button');
    findPlansBtn.click();
    tick(); // simulates the passage of time until all pending asynchronous activities finish
    fixture.detectChanges();
    expect(component.redirectToVPP).toHaveBeenCalled();
  }));

});
