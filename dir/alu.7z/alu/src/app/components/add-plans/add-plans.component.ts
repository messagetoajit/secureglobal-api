import { Component, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';

import { ProfilePage } from '../../models/ProfilePage';
import { ProviderService } from '../../services/provider.service';
import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';
import { PlanService } from '../../services/plan.service';
import { UtilityService } from '../../services/utility.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { AppData } from '../../models/AppData';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-add-plans,[app-add-plans]',
  templateUrl: './add-plans.component.html',
  encapsulation : ViewEncapsulation.None
})
export class AddPlansComponent {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;

  @Output() addPlans = new EventEmitter();

  constructor(
    private readonly planService: PlanService,
    private readonly utililtyService: UtilityService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly providerService: ProviderService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  redirectToVPP(event?: any) {
    if (event) {
      const selectedOption = { action: 'Navigate to VPP Page' };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Goto to VPP Page', {}, TrackingConstants.eventType.ACTION);

    this.addPlans.emit();
  }

  getAddPlansMsg(text) {
    return text ? this.utililtyService.getSanitizedHTML(text) : '';
  }

  hasPlanOrDrugOrDoctor() {
    return this.planService.isFederalPlansExists (this.appData) ||
      this.drugsAndPharmacyService.isDrugsDataExists(this.appData) ||
      this.providerService.isProviderDataExists(this.appData);
  }

}
