import { Component, OnInit, ViewEncapsulation, Input, Output, EventEmitter } from '@angular/core';

import { ProviderService } from '../../services/provider.service';
import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';
import { PlanService } from '../../services/plan.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { AppData } from '../../models/AppData';
import { ProfilePage } from '../../models/ProfilePage';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-drugs-providers,[app-drugs-providers]',
  templateUrl: './drugs-providers.component.html',
  encapsulation : ViewEncapsulation.None
})
export class DrugsProvidersComponent implements OnInit {

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;
  @Input() isUserLoggedIn: boolean;
  @Input() isProfileDataImported: boolean;
  @Input() isCSRLogin: boolean;

  @Output() initiateProvidersDataBuild = new EventEmitter();
  @Output() initiateDrugsAndPharmacyDataBuild = new EventEmitter();
  @Output() importShopperData = new EventEmitter();

  providerInterval: any;

  constructor(
    private readonly planService: PlanService,
    private readonly providerService: ProviderService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void {
  }

  isAnyDrugOrProviderExists() {
    return this.isDrugsDataExists() || this.isProviderDataExists();
  }

  getDrugsCount() {
    return this.isDrugsDataExists() ? this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length : 0;
  }

  getProvidersCount() {
    return this.isProviderDataExists() ? this.appData.profileDetails.providersDetails.providerIdList.length : 0;
  }

  isDrugsDataExists() {
    return this.drugsAndPharmacyService.isDrugsDataExists(this.appData);
  }

  isProviderDataExists() {
    return this.providerService.isProviderDataExists(this.appData);
  }

  isAddDoctorSupported() {
    return this.planService.isAddDoctorSupported(this.appData) ;
  }

  visitAddDrugPage(event?: any): void {
    if (event) {
      const selectedOption = { action: 'DCE - Add Drugs'};
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_DRUG);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'DCE - Add Drugs', {}, TrackingConstants.eventType.ACTION);

    this.drugsAndPharmacyService.launchDCE();
  }

  searchDoctors(event?: any) {
    if (event) {
      const selectedOption = { action: 'DCE - Add Provider'};
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_DRUG);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'DCE - Add Provider', {}, TrackingConstants.eventType.ACTION);

    const anyProviderEligibleFederalPlan = this.planService.getAnyProviderEligibleFederalPlan(this.appData);

    if (anyProviderEligibleFederalPlan) {
      this.providerService.searchProvider(this.appData, anyProviderEligibleFederalPlan);

      this.providerService.getRallyProviderSearchNotification().subscribe((msg: any) => {
        console.log('Rally Provider Search Completed.');

        if (msg?.providerSearchComplete) {
          console.log('Going to rebuild providers data ...');
          this.initiateProvidersDataBuild.emit();
        }
      });
    }
  }

  buildDrugsAndPharmacyData() {
    this.initiateDrugsAndPharmacyDataBuild.emit();
  }

  buildProvidersData() {
    this.initiateProvidersDataBuild.emit();
  }

  openShopperDataImportPopup(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, undefined, DL_CONTAINER.SAVED_DRUG);
    }
    this.importShopperData.emit();
  }

}
