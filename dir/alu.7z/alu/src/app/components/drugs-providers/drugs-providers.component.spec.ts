import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { DrugsProvidersComponent } from './drugs-providers.component';
import { AlertTipComponent } from '../alert-tip/alert-tip.component';

describe('DrugsProvidersComponent', () => {
  let component: DrugsProvidersComponent;
  let fixture: ComponentFixture<DrugsProvidersComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ AlertTipComponent ],
      providers: [ CurrencyPipe ]
    }).compileComponents();

    fixture = TestBed.createComponent(DrugsProvidersComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

});
