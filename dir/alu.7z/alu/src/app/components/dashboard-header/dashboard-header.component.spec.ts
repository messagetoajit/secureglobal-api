import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { DashboardHeaderComponent } from '../dashboard-header/dashboard-header.component';
import { AppData } from '../../models/AppData';

describe('DashboardHeaderComponent', () => {
  let component: DashboardHeaderComponent;
  let fixture: ComponentFixture<DashboardHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      declarations: [ DashboardHeaderComponent ],
      providers: [ CurrencyPipe ]
    }).compileComponents();
    fixture = TestBed.createComponent(DashboardHeaderComponent);
    component = fixture.componentInstance;
    const appData = new AppData();
    appData.savedPlansCount = 0;
    component.appData = appData;
  });

  it('should create', () => {
    component.profilePage = {};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  it('unauthenticated: register button', fakeAsync(() => {
    component.profilePage = {createProfileText: 'createProfileText' };
    fixture.detectChanges();
    spyOn(component, 'register').and.callThrough();
    const button = fixture.nativeElement.querySelector('button');
    expect(button.innerText).toEqual('createProfileText');
    button.click();
    tick();
    fixture.detectChanges();
    expect(component.register).toHaveBeenCalled();
  }));

  it('unauthenticated: saved plan count', fakeAsync(() => {
    component.profilePage = {orSignInToYourProfileText: 'orSignInToYourProfileText'};
    fixture.detectChanges();
    spyOn(component, 'scrollTo').and.callThrough();
    const signInLink = fixture.nativeElement.querySelectorAll('.header-link')[0];
    expect(signInLink.innerText).toEqual(' (0)');
    signInLink.click();
    tick();
    fixture.detectChanges();
    expect(component.scrollTo).toHaveBeenCalled();
  }));


  it('unauthenticated: signin link', fakeAsync(() => {
    component.profilePage = {orSignInToYourProfileText: 'orSignInToYourProfileText'};
    fixture.detectChanges();
    spyOn(component, 'signIn').and.callThrough();
    const signInLink = fixture.nativeElement.querySelectorAll('.header-link')[4];
    expect(signInLink.innerText).toEqual(' orSignInToYourProfileText');
    signInLink.click();
    tick();
    fixture.detectChanges();
    expect(component.signIn).toHaveBeenCalled();
  }));


  it('should create authenticated page', () => {
    component.profilePage = {};
    component.userDetails = { firstName: 'Test'};
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

});
