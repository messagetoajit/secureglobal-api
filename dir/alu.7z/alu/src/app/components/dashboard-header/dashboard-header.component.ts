import { Component, OnInit, Input, ViewEncapsulation } from '@angular/core';

import { UtilityService } from '../../services/utility.service';
import { UserinfoService } from '../../services/userinfo.service';
import { ProviderService } from '../../services/provider.service';
import { DrugsAndPharmacyService } from '../../services/drugs-and-pharmacy.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { ProfilePage } from '../../models/ProfilePage';
import { AppData } from '../../models/AppData';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-dashboard-header,[app-dashboard-header]',
  templateUrl: './dashboard-header.component.html',
  styleUrls: ['./dashboard-header.component.scss'],
  encapsulation : ViewEncapsulation.None
})
export class DashboardHeaderComponent implements OnInit {

  @Input() userDetails: any;
  @Input() profilePage: ProfilePage;
  @Input() appData: AppData;

  constructor(
    private readonly utilityService: UtilityService,
    private readonly userinfoService: UserinfoService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly providerService: ProviderService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void { }

  isAuthenticatedUser() {
    return this.userDetails && this.userDetails.firstName;
  }

  get userType() {
    return this.isAuthenticatedUser() ? 'Auth' : 'Guest';
  }

  renderFirstName() {
    return this.userDetails && this.userDetails.firstName
      ? this.utilityService.renderFirstName(this.userDetails.firstName) : '';
  }

  signIn(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Header: User sign in', {}, TrackingConstants.eventType.ACTION);

    this.utilityService.navigateToURL(this.profilePage.signInUrl);
  }

  signOut(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    this.userinfoService.logout().subscribe(data => {
      this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Header: User sign out', {}, TrackingConstants.eventType.ACTION);

      this.userinfoService.deleteBrowserStorage();
      location.href = '/';

    }, (error) => console.log(error));
  }

  register(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Header: User Profile create', {}, TrackingConstants.eventType.ACTION);

    this.utilityService.navigateToURL(this.profilePage.registrationUrl);
  }

  getDrugsCount() {
    let count = 0;
    if (this.drugsAndPharmacyService.isDrugsDataExists(this.appData)) {
      count = this.appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length;
    }
    return count;
  }

  getProvidersCount() {
    let count = 0;
    if (this.providerService.isProviderDataExists(this.appData)) {
      count = this.appData.profileDetails.providersDetails.providerIdList.length;
    }
    return count;
  }

  scrollTo(id, event?: any) {
    if (event) {
      const selectedOption = { scrollTo: id };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK, selectedOption);
    }
    this.utilityService.scrollToElement(id, true);
  }

}
