import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';

import { LoaderComponent } from './loader.component';

describe('LoaderComponent', () => {
    let component: LoaderComponent;
    let fixture: ComponentFixture<LoaderComponent>;

    beforeEach(() => {
      TestBed.configureTestingModule({
        imports: [],
        declarations: [
            LoaderComponent
        ],
        providers: [],
      });

      fixture = TestBed.createComponent(LoaderComponent);
      component = fixture.componentInstance;
    });

    it('check message binding', () => {
        component.message = 'message';

        fixture.detectChanges();

        const de = fixture.debugElement.query(By.css('.message'));
        const el: HTMLElement = de.nativeElement;

        expect(el.innerText).toBe(component.message);

        const container = fixture.debugElement.query(By.css('.modal-overlay'));
        const containerEl: HTMLElement = container.nativeElement;
        containerEl.classList.remove('show');
    });
});
