import { Component, ViewEncapsulation, Input, Output, EventEmitter, ViewChild, ElementRef, HostListener } from '@angular/core';

import { PlanService } from '../../services/plan.service';
import { CookieService } from '../../services/cookie.service';
import { ProviderService } from '../../services/provider.service';
import { UserinfoService } from '../../services/userinfo.service';
import { TrackingService } from '../../services/tracking.service';
import { DataLayerService } from '../../services/datalayer.service';

import { AppData } from '../../models/AppData';
import { Provider } from '../../models/Provider';
import { ProfilePage } from '../../models/ProfilePage';
import { UserProfile } from '../../models/UserProfile';
import { AppConstants } from '../../constants/app-constants';
import { TrackingConstants } from '../../constants/tracking-constants';
import { DL_CONTAINER, DL_EVENT_TYPE } from '../../constants/datalayer-constants';

@Component({
  selector: 'app-providers,[app-providers]',
  templateUrl: './providers.component.html',
  encapsulation : ViewEncapsulation.None
})
export class ProvidersComponent {
  @ViewChild('removeItemModalCloseBtn') removeItemModalCloseBtn: ElementRef;
  @ViewChild('backBtn') backBtn: ElementRef;
  @ViewChild('removeProvider') removeProvider: ElementRef;

  @Input() appData: AppData;
  @Input() profilePage: ProfilePage;

  @Output() searchProviders = new EventEmitter();
  @Output() initiateProvidersDataBuild = new EventEmitter();

  showRemoveProviderPopup = false;
  selectedIndex: number;
  selectedProvider: Provider;

  constructor(
    private readonly planService: PlanService,
    private readonly cookieService: CookieService,
    private readonly providerService: ProviderService,
    private readonly userinfoService: UserinfoService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) { }

  isProviderDataExists() {
    return this.providerService.isProviderDataExists(this.appData);
  }

  isHospitalProvider(providerType: string) {
    return providerType === 'facility';
  }

  checkInvalidProviderName(providerName: string): string {
    return providerName
      && (providerName.trim() === ',' || providerName.trim() === '' || providerName.indexOf('null') > -1) ? AppConstants.savedProvider : providerName;
  }

  showPopup(index: number, provider: Provider, event?: any) {
    if (event) {
      this.dataLayerService.setDLModalDataEvent(('vp_prov_del_' + index), ('Remove ' + provider?.providerName), event, DL_CONTAINER.SAVED_PCP);
    }
    this.selectedIndex = index;
    this.selectedProvider = provider;
    this.showRemoveProviderPopup = true;
    setTimeout(() => {
      this.removeItemModalCloseBtn.nativeElement.focus();
    }, 100);
  }

  closePopup(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, undefined, DL_CONTAINER.SAVED_PCP);
    }
    this.showRemoveProviderPopup = false;
    this.selectedIndex = -1;
    this.selectedProvider = undefined;
    this.removeProvider?.nativeElement?.focus();
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    if (event.code === 'Escape') {
      this.showRemoveProviderPopup = false;
    }
  }

  deleteProvider(event?: any): void {
    if (event) {
      const selectedOption = { action: 'Delete Provider', providerId: this.selectedProvider.providerId };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption, DL_CONTAINER.SAVED_PCP);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Delete Provider', {provider_name: this.selectedProvider?.providerName}, TrackingConstants.eventType.ACTION);

    this.providerService.setProvidersDataInBrowserStorage(this.appData);
    this.appData.profileDetails.providersDetails.providerIdList.splice(this.selectedIndex, 1);

    const uuid = this.cookieService.getUuidFromCookie();

    this.userinfoService.updateProfileData(uuid, 'providers', this.getUpdatedProvidersData()).subscribe((response: any) => {
      console.log('Provider deleted successfully.');

      this.providerService.deleteProviderFromCookie(this.selectedProvider, this.appData);
      this.closePopup();

      this.userinfoService.getProfileData(uuid, 'providers', '').subscribe((data: UserProfile) => {
        this.appData.profileDetails.providersDetails = data.providersDetails;
        this.initiateProvidersDataBuild.emit();

      }, (error1) => console.log(error1));

    }, (error) => {
      console.log(error);
      this.reInsertProviderOnFailure(this.selectedIndex, this.selectedProvider);
      this.closePopup();
    });
  }

  getUpdatedProvidersData(): any {
    const isGuestUser = this.cookieService.isGuestUser();
    return {
      providersDetails: this.appData.profileDetails.providersDetails,
      isGuest: isGuestUser
    };
  }

  reInsertProviderOnFailure(index: number, provider: Provider): void {
    this.appData.profileDetails.providersDetails.providerIdList.splice(index, 0, provider);
  }

  isAddDoctorEligible() {
    return this.planService.isAddDoctorSupported(this.appData);
  }

  backBtn_keydown(event: any){
    if (!event.shiftKey && event.code === 'Tab'){
      if (this.removeItemModalCloseBtn){
        this.removeItemModalCloseBtn.nativeElement.focus();
      }
      event.preventDefault();
    }
  }

  close_btn(event: any){
    if (event.shiftKey && event.code === 'Tab'){
      if (this.backBtn){
        this.backBtn.nativeElement.focus();
      }
      event.preventDefault();
    }
  }

  searchDoctors(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, undefined, DL_CONTAINER.SAVED_PCP);
    }
    this.searchProviders.emit();
  }

}
