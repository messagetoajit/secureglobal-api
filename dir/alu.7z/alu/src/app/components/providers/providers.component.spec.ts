import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

import { PlanService } from '../../services/plan.service';
import { ProviderService } from '../../services/provider.service';
import { AppData } from '../../models/AppData';
import { ProvidersComponent } from './providers.component';

describe('ProvidersComponent', () => {
    let component: ProvidersComponent;
    let fixture: ComponentFixture<ProvidersComponent>;
    let planService: PlanService;
    let providerService: ProviderService;

    const savedDoctorsIdElem = '#saved-doctors';
    const savedDoctorsBtnElem = '#saved-doctors button';

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [ HttpClientTestingModule ],
            declarations: [ ProvidersComponent ],
            providers: [ CurrencyPipe , PlanService, ProviderService ],
        });

        fixture = TestBed.createComponent(ProvidersComponent);
        component = fixture.componentInstance;
        planService = TestBed.inject(PlanService);
        providerService = TestBed.inject(ProviderService);
        component.appData = new AppData();
    });

    it('should create', () => {
        component.profilePage = {};
        fixture.detectChanges();
        expect(component).toBeTruthy();
    });

    it('test no Providers and doctors', () => {
        component.profilePage = {};
        spyOn(providerService, 'isProviderDataExists').and.returnValue(false);
        spyOn(planService, 'isAddDoctorSupported').and.returnValue(false);
        fixture.detectChanges();
        const addDoctorBtn = fixture.nativeElement.querySelector(savedDoctorsIdElem);
        expect(addDoctorBtn).toBeFalsy();
    });

    xit('test add doctor button - providers', fakeAsync(() => {
        component.profilePage = {standaloneWidgetDoctorsAndProvidersText: 'Providers'};
        spyOn(providerService, 'isProviderDataExists').and.returnValue(true);
        spyOn(component, 'searchDoctors').and.callThrough();
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelector(savedDoctorsIdElem)).toBeTruthy();
        const addDoctorBtn = fixture.nativeElement.querySelector(savedDoctorsBtnElem);
        expect(addDoctorBtn).toBeTruthy();
        addDoctorBtn.click();
        tick();
        expect(component.searchDoctors).toHaveBeenCalled();
    }));

    it('test add doctor button - doctors ', fakeAsync(() => {
        component.profilePage = {};
        spyOn(planService, 'isAddDoctorSupported').and.returnValue(true);
        spyOn(component, 'searchDoctors').and.callThrough();
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelector(savedDoctorsIdElem)).toBeTruthy();
        const addDoctorBtn = fixture.nativeElement.querySelector(savedDoctorsBtnElem);
        expect(addDoctorBtn).toBeTruthy();
        addDoctorBtn.click();
        tick();
        expect(component.searchDoctors).toHaveBeenCalled();
    }));

});
