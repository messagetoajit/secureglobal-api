import { DecimalPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { SafePipe } from './safe.pipe';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';
import { DomSanitizer } from '@angular/platform-browser';

describe('SafePipe', () => {
    let pipe: SafePipe;
    let sanitizer: DomSanitizer;

    beforeEach( () => {
        TestBed.configureTestingModule({
            providers: [
                SafePipe,
                {
                    provide: DomSanitizer,
                    useValue: {
                        bypassSecurityTrustResourceUrl: () => 'safeString'
                    }
                }
              ]
          });
        sanitizer = TestBed.inject(DomSanitizer);
        pipe = new SafePipe(sanitizer);
    });

    it('pipe is defined', () => {
        expect(pipe instanceof SafePipe).toBeTruthy();
    });

    it('transform url', () => {
        expect(pipe.transform('https://www.aarpmedicareplans.com/')).toEqual('safeString');
    });

  });
