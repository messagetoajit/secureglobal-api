import { DecimalPipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { Digit } from './digit.pipe';
import { registerLocaleData } from '@angular/common';
import localeDe from '@angular/common/locales/de';

describe('DecimalPipe', () => {
    let pipe: Digit;
    let decimalPipe: DecimalPipe;

    beforeEach( () => {
        TestBed.configureTestingModule({
            providers: [
                Digit,
                DecimalPipe
            ]
          });
        decimalPipe = TestBed.inject(DecimalPipe);
        pipe = new Digit(decimalPipe);
    });

    it('pipe is defined', () => {
        expect(pipe instanceof Digit).toBeTruthy();
    });

    it('transform does not apply for "--"', () => {
      expect(pipe.transform('--')).toBe('--');
    });

    it('transforms empty to displayable format', () => {
        expect(pipe.transform(false)).toEqual('$false');
    });

    it('transforms decimal to displayable format', () => {
      expect(pipe.transform('12.00')).toEqual('$12');
    });

  });
