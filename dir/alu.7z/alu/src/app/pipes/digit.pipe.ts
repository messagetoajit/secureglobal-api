import { Pipe, PipeTransform } from '@angular/core';
import { DecimalPipe } from '@angular/common';

@Pipe({
  name: 'decimal'
})
export class Digit implements PipeTransform {
  constructor(private readonly decimalPipe: DecimalPipe) {}

  transform(amt) {
    return (amt === '--') ? amt : ('$' + (amt ? this.decimalPipe.transform(amt, '1.2') : amt).toString().replace('.00', ''));
  }

}
