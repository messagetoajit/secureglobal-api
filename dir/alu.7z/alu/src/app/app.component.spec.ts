import { TestBed, ComponentFixture } from '@angular/core/testing';
import { AppComponent } from "./app.component";
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CurrencyPipe } from '@angular/common';

describe('AppComponent', () => {
    let component: AppComponent;
    let fixture: ComponentFixture<AppComponent>;
    
    beforeEach(() => {
        TestBed.configureTestingModule({
          declarations: [ AppComponent ],
          imports: [ HttpClientTestingModule ],
          providers: [ CurrencyPipe ]
        }).compileComponents();
        fixture = TestBed.createComponent(AppComponent);
        component = fixture.componentInstance;
    });

    xit('should create', () => {
        expect(component).toBeTruthy();
    })

    
})