import { Component, OnInit, NgModule, HostListener, EventEmitter, Output, Directive, ElementRef, Input, OnDestroy, Inject, ViewChild } from '@angular/core';
import { CommonModule, DOCUMENT } from '@angular/common';

import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, Validators, AbstractControl } from '@angular/forms';
import * as textMask from 'vanilla-text-mask/dist/vanillaTextMask.js';

import { DTMService } from '../../services/dtm.service';
import { UtilityService } from '../../services/utility.service';
import { CookieService } from '../../services/cookie.service';
import { StorageService } from '../../services/storage.service';
import { MessagingService } from '../../services/messaging.service';
import { ShopperProfileService } from '../../services/shopper-profile.service';
import { DataLayerService } from '../../services/datalayer.service';

import { AppConstants } from '../../constants/app-constants';
import { AppContent } from '../../models/AppContent';
import { URIConstants } from '../../constants/uri-constants';
import { ProfileActionDetails } from '../../models/ProfileActionDetails';
import { DL_EVENT_TYPE } from '../../constants/datalayer-constants';

declare var _satellite;

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: 'input-mask, [input-mask], [inputMask]'
})
export class InputMaskDirective implements OnInit, OnDestroy {

  @Input() inputMask;

  maskedInputController: any;

  constructor(private readonly element: ElementRef) {}

  ngOnInit(): void {
    this.maskedInputController = textMask.maskInput({
      inputElement: this.element.nativeElement,
      ...this.inputMask
    });
  }

  ngOnDestroy() {
    this.maskedInputController.destroy();
  }
}

@Component({
  templateUrl: './data-import-popup.component.html'
})
export class DataImportPopupComponent implements OnInit {

  @ViewChild('popupModalCloseBtn') popupModalCloseBtn?: ElementRef;
  @ViewChild('yesRadioBtn') yesRadioBtn?: ElementRef;
  @ViewChild('memberDob') memberDob?: ElementRef;
  @ViewChild('nonMemberGender') nonMemberGender?: ElementRef;
  @ViewChild('yourName') yourName?: ElementRef;
  @ViewChild('backBtn') backBtn?: ElementRef;

  @Output() displayLoader = new EventEmitter<boolean>();
  @Output() dataImportCallback = new EventEmitter<any>();

  page?: string;
  appContent: AppContent = new AppContent();
  shopperDetails: any;
  tollFreeNumber = '';

  componentStyleName = AppConstants.shopperDataImportComponentName;

  mbiMask = AppConstants.mbiMask;
  dateMask = AppConstants.dateMask;

  mbiPattern = AppConstants.mbiPattern;
  datePattern = AppConstants.datePattern;
  zipPattern = AppConstants.zipPattern;

  showPopup = false;
  dataImportDesc = false;
  secureInfoDesc = false;
  showMBICardExample = false;

  dataImportForm: FormGroup = this.formBuilder.group({
    initialForm: this.formBuilder.group({
      isStart         : [false],
      isValidated     : [false]
    }),
    memberTypeForm: this.formBuilder.group({
      memberType      : ['', [Validators.required]],
      isValidated     : [false]
    }),
    startImportForm: this.formBuilder.group({
      isImport        : [false],
      isValidated     : [false]
    }),
    nonMemberConsentForm: this.formBuilder.group({
      agreementName   : ['', [Validators.required]],
      agreementText   : [''],
      nonMemberConsent: ['n'],
      isValidated     : [false]
    }),
    nonMemberDetailsForm: this.formBuilder.group({
      gender          : ['', [Validators.required]],
      dob             : ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), this.dateValidator(this.utilityService)]],
      zipCode         : ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5), Validators.pattern(AppConstants.zipPattern)]],
      isValidated     : [false]
    }),
    memberDetailsForm: this.formBuilder.group({
      dob             : ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10), this.dateValidator(this.utilityService)]],
      zipCode         : ['', [Validators.required, Validators.minLength(5), Validators.maxLength(5), Validators.pattern(AppConstants.zipPattern)]],
      mbi             : ['', [Validators.required, Validators.minLength(13), Validators.maxLength(13), Validators.pattern(AppConstants.mbiPattern)]],
      isValidated     : [false]
    }),
    importFailureForm: this.formBuilder.group({
      isImportFailed  : [false]
    })
  });

  views = {
    1 : { name: 'initialForm', closeBtnDTMName: 'Get Started:Close' },
    2 : { name: 'memberTypeForm', closeBtnDTMName: 'Do you have Medicare:Close' },
    3 : { name: 'startImportForm', closeBtnDTMName: 'We can import your drugs:Close' },
    4 : { name: 'nonMemberConsentForm', closeBtnDTMName: 'Need your consent:Close' },
    5 : { name: 'nonMemberDetailsForm', closeBtnDTMName: 'Look up your info:Close' },
    6 : { name: 'memberDetailsForm', closeBtnDTMName: 'Look up your info:Close' },
    7 : { name: 'importFailureForm', closeBtnDTMName: 'Unable to find your history:Close' }
  };
  activeView: any = {
    step : 1,
    name : this.views[1].name,
    closeBtnDTMName : this.views[1].closeBtnDTMName
  };

  constructor(
    private readonly formBuilder: FormBuilder,
    @Inject(DOCUMENT) private readonly document: Document,
    private readonly dtmService: DTMService,
    private readonly utilityService: UtilityService,
    private readonly cookieService: CookieService,
    private readonly storageService: StorageService,
    private readonly messagingService: MessagingService,
    private readonly shopperProfileService: ShopperProfileService,
    private readonly dataLayerService: DataLayerService
  ) { }

  ngOnInit(): void {
    this.utilityService.lazyLoadStyles(this.componentStyleName).then(() => {
      console.log(this.componentStyleName + '.css loaded successfully');
      this.showPopup = true;
      this.setBodyScroll(true);
      setTimeout(() => {
        this.popupModalCloseBtn?.nativeElement?.focus();
      }, 100);

    }).catch(() => {
      console.log(this.componentStyleName + '.css loading failed');
    });

    if (this.shopperDetails?.firstName) {
      this.shopperDetails.firstName = this.shopperDetails.firstName.toLowerCase();
    }
    if (this.shopperDetails?.lastName) {
      this.shopperDetails.lastName = this.shopperDetails.lastName.toLowerCase();
    }
    this.initialize_satellite_object();
    this.setAnalyticsData();
  }

  get initialForm(): FormGroup {
    return (this.dataImportForm.get('initialForm') as FormGroup);
  }
  get memberTypeForm() {
    return (this.dataImportForm.get('memberTypeForm') as FormGroup);
  }
  get startImportForm() {
    return (this.dataImportForm.get('startImportForm') as FormGroup);
  }
  get nonMemberConsentForm() {
    return (this.dataImportForm.get('nonMemberConsentForm') as FormGroup);
  }
  get nonMemberDetailsForm() {
    return (this.dataImportForm.get('nonMemberDetailsForm') as FormGroup);
  }
  get memberDetailsForm() {
    return (this.dataImportForm.get('memberDetailsForm') as FormGroup);
  }
  get importFailureForm() {
    return (this.dataImportForm.get('importFailureForm') as FormGroup);
  }

  get activeForm(): FormGroup {
    return (this.dataImportForm.get(this.activeView.name) as FormGroup);
  }
  get activeFormControls() {
    return this.activeForm.controls;
  }
  get isActiveFormValidated(): boolean {
    return this.activeForm.value.isValidated;
  }

  dateValidator(utilityService: UtilityService): any {
    return (control: AbstractControl): any | null => {
      return this.isValidDate(control.value) ? null : { validDate : false };
    };
  }

  isValidDate(date: string): boolean {
    const dateObject: any = new Date(date);
    return (dateObject !== 'Invalid Date') && !isNaN(dateObject);
  }

  setBodyScroll(show: boolean) {
    if (show) {
      this.document.querySelector('body')?.classList?.add('no-y-scroll');
    } else {
      this.document.querySelector('body')?.classList?.remove('no-y-scroll');
    }
  }

  setView(step: number) {
    this.activeView = {
      step,
      name : this.views[step].name,
      closeBtnDTMName : this.views[step].closeBtnDTMName
    };
    this.setDTMData(step);
  }

  resetView() {
    this.setView(1);
  }

  closePopup(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    if (this.page === AppConstants.landroverPage) {
      setTimeout(() => {
        this.dtmService.setDTMData({content: {pageName: (this.isGuestUser ? 'Visitor Profile:Guest' : 'Visitor Profile:Authenticated')}});
      }, 100);
    }
    this.showPopup = false;
    this.setBodyScroll(false);
    this.resetView();
  }

  moveBackwards(event?: any) {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    if (this.activeView.name === 'memberDetailsForm') {
      this.setView(this.activeView.step - 4);

    } else {
      this.setView(this.activeView.step - 1);
    }
  }

  moveForward() {
    this.activeForm.get('isValidated')?.setValue(true);

    if (this.activeForm.invalid) {
      if (this.activeView.name === 'memberTypeForm') {
        setTimeout(() => {
          this.yesRadioBtn?.nativeElement?.focus();
        }, 100);

      } else if (this.activeView.name === 'memberDetailsForm') {
        setTimeout(() => {
          this.memberDob?.nativeElement?.focus();
        }, 100);

      } else if (this.activeView.name === 'nonMemberDetailsForm') {
        setTimeout(() => {
          this.nonMemberGender?.nativeElement?.focus();
        }, 100);

      } else if (this.activeView.name === 'nonMemberConsentForm') {
        setTimeout(() => {
          this.yourName?.nativeElement?.focus();
        }, 100);
      }
      this.dataLayerService.setDLFormErrorEvent(undefined, this.activeView?.name, 'Form Invalid');
      return;

    } else {
      this.dataLayerService.setDLFormSubmitEvent(undefined, this.activeView?.name);
    }

    if (this.activeView.name === 'initialForm') {
      this.activeForm.get('isStart')?.setValue(true);

    } else if (this.activeView.name === 'startImportForm') {
      this.activeForm.get('isImport')?.setValue(true);

    } else if (this.activeView.name === 'nonMemberConsentForm') {
      this.activeForm.get('agreementText')?.setValue(this.document.getElementById('agreement-text')?.innerHTML?.trim());
      this.activeForm.get('nonMemberConsent')?.setValue('y');
    }
    console.log(this.activeForm.value);

    if (this.activeView.name === 'memberTypeForm') {
      if (this.memberTypeForm.value.memberType === 'Member') {
        this.setView(6);
        this.dtmService.setDTMData({visitorProfile: {type: 'Member'}});

      } else {
        this.setView(this.activeView.step + 1);
        this.dtmService.setDTMData({visitorProfile: {type: 'Non Member'}});
      }

    } else if ((this.activeView.name === 'nonMemberDetailsForm' || this.activeView.name === 'memberDetailsForm')) {
      this.importData();

    } else {
      this.setView(this.activeView.step + 1);
    }
  }

  importData() {
    try {
      const uuid = this.cookieService.getUuidFromCookie();
      const isNonMemberFlow = this.memberTypeForm.value.memberType === 'Non-Member' ? true : false;
      const isRetailPharmacy = this.storageService.getItem_LS(AppConstants.isRetailPharmacy);
      const providerStorageDataString = this.storageService.getItem_LS(AppConstants.providerKey, false);
      const providerStorageData = providerStorageDataString ? JSON.parse(providerStorageDataString) : null;

      let nonMemberAgreementText: string = isNonMemberFlow ? this.nonMemberConsentForm.value.agreementText : null;

      if (nonMemberAgreementText) {
        nonMemberAgreementText = nonMemberAgreementText.replace('<span>', '').replace('</span>', '');
      }

      const requestData = {
        uuid,
        isNonMemberFlow,
        isRetailPharmacy        : isRetailPharmacy === undefined || isRetailPharmacy === null || isRetailPharmacy === 'true',
        isReturnStorageData     : this.page === AppConstants.landroverPage ? false : true,
        isReturnProfileData     : this.page === AppConstants.landroverPage ? false : true,
        isReturnSummaryData     : true,
        providerStorageZipCode  : providerStorageData?.ZipCode ? providerStorageData.ZipCode : null,
        activeYear              : this.shopperDetails?.activeYear,
        firstName               : this.shopperDetails?.firstName,
        lastName                : this.shopperDetails?.lastName,
        mbi                     : isNonMemberFlow ? null : this.memberDetailsForm.value.mbi,
        gender                  : isNonMemberFlow ? this.nonMemberDetailsForm.value.gender : null,
        dob                     : isNonMemberFlow ? this.nonMemberDetailsForm.value.dob : this.memberDetailsForm.value.dob,
        zipCode                 : isNonMemberFlow ? this.nonMemberDetailsForm.value.zipCode : this.memberDetailsForm.value.zipCode,
        agreementName           : isNonMemberFlow ? this.nonMemberConsentForm.value.agreementName : null,
        agreementText           : nonMemberAgreementText,
        triggeredBy             : this.page,
        clientOrigin            : this.utilityService.isLocalHost() ? URIConstants.teamEnvUrl : location.origin
      };

      console.log('Request Data : ');
      console.log(requestData);

      if (uuid) {
        this.displayLoader.emit(true);

        this.shopperProfileService.importShopperItems(requestData).subscribe((response: any) => {

          const drugsCount = response?.importSummaryData?.importedDrugsAndPharmacySummary?.drugsCount;
          const providersCount = response?.importSummaryData?.importedProvidersSummary?.providersCount;

          if (drugsCount > 0 || providersCount > 0) {
            console.log('Shopper data import completed.');

            const profileActionDetails = new ProfileActionDetails();
            profileActionDetails.user_id = uuid;
            profileActionDetails.user_fullname = requestData.firstName + ' ' + requestData.lastName;
            profileActionDetails.event_name = 'AMP # optumIdProfile - ' + 'importConsumerData';
            profileActionDetails.profile_action = 'ImportData - ' + (isNonMemberFlow ? 'Non-Member' : 'Member');
            profileActionDetails.drugs_imported = (drugsCount > 0) ? drugsCount : 0;
            profileActionDetails.providers_imported = (providersCount > 0) ? providersCount : 0;

            this.messagingService.trackDataImportActions(profileActionDetails);

            this.setDataImportResponse(true, { data: response, success: true });

          } else {
            console.log('No import Data received');
            this.setDataImportResponse(false, { data: response, success: false });
          }

        }, (error: any) => {
          console.log('Some error occurred while importing shopper data.');

          this.setDataImportResponse(false, { data: error, success: false });
        });

      } else {
        console.log('Invalid UUID');
        this.setDataImportResponse(false, { data: null, success: false });
      }

    } catch (e) {
      console.log('Some error occurred in importData()');
      console.log(e);

      this.setDataImportResponse(false, { data: e, success: false });
    }
  }

  setDataImportResponse(isSuccess: boolean, data: any): void {
    console.log(data);

    this.storageService.setItem_SS(AppConstants.isProfileDataImported, AppConstants.TRUE_VALUE);

    this.displayLoader.emit(false);
    this.importFailureForm?.get('isImportFailed')?.setValue(isSuccess ? false : true);

    if (isSuccess) {
      this.closePopup();
    } else {
      this.setView(7);
    }

    if (this.page === AppConstants.landroverPage) {
      if (isSuccess) {
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Authenticated'}});
      }
      this.dataImportCallback.emit(data);
    }
  }

  get isGuestUser() {
    return this.cookieService.isGuestUser();
  }

  signIn(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK);
    }
    this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:Sign in to your profile'}});
    this.storageService.setItem_SS(AppConstants.isReloadDataImportPopup, AppConstants.TRUE_VALUE);
    location.href = '/optumid-login';
  }

  register(event?: any){
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.storageService.setItem_SS(AppConstants.isReloadDataImportPopup, AppConstants.TRUE_VALUE);
    location.href = '/optumid-registration';
  }

  initialize_satellite_object() {
    try {
      if (typeof _satellite === 'undefined' || typeof _satellite.track === 'undefined') {
        _satellite = {
          track: () => {}
        };
      }
    } catch (e) {
      console.log('Some error occurred while initializing _satellite object.');
    }
  }

  setAnalyticsData(): void {
    const pageName = this.isGuestUser ? 'Visitor Profile:Import Modal:Sign in to your profile' : 'Visitor Profile:Import Modal:Get Started';
    const headingText = this.isGuestUser ? this.appContent.importYourInformation : this.appContent.helpUsPersonalizeYourCostEstimates;

    this.dtmService.setDTMData({ content: { pageName }});
    this.dataLayerService.setDLModalDataEvent('vp_data_import', headingText);
  }

  trackData(event: string) {
    try {
      if (typeof _satellite !== 'undefined' && _satellite && typeof _satellite.track !== 'undefined' && _satellite.track) {
        _satellite.track(event);
      }
    } catch (e) {
      console.log('Some error occurred while tracking _satellite event.');
    }
  }

  setDTMData(step: number) {
    switch (step) {
      case 1:
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:Get Started'}});
        break;
      case 2:
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:Do you have Medicare'}});
        break;
      case 3:
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:We can import your drugs'}});
        break;
      case 4:
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:Need your consent'}});
        break;
      case 5:
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:Look up your info'}});
        break;
      case 6:
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:Look up your info'}});
        break;
      case 7:
        this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Import Modal:Unable to find your history'}});
        break;
      default:
        break;
    }
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    // tslint:disable-next-line: deprecation
    if (event.code === 'Escape') { // Escape key pressed
      this.closePopup();
    }
  }

  nextBtn_keydown(event: any){
    if (!event.shiftKey && event.code === 'Tab'){
      this.popupModalCloseBtn?.nativeElement?.focus();
      event.preventDefault();
    }
  }

  close_btn(event: any){
    if (event.shiftKey && event.code === 'Tab'){
      this.backBtn?.nativeElement?.focus();
      event.preventDefault();
    }
  }

}

@NgModule({
  declarations: [
    InputMaskDirective,
    DataImportPopupComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    DTMService,
    UtilityService,
    CookieService,
    StorageService,
    MessagingService,
    ShopperProfileService
  ]
})
class LazyModule {}
