import { DataImportPopupComponent } from "./data-import-popup.component";
import { ComponentFixture, TestBed } from "@angular/core/testing";
import { FormBuilder } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';


describe('DataImportPopupComponent', () => {
    let component: DataImportPopupComponent;
    let fixture: ComponentFixture<DataImportPopupComponent>;
  
    beforeEach(async () => {
      await TestBed.configureTestingModule({
        imports: [ HttpClientTestingModule ],
        declarations: [ DataImportPopupComponent ],
        providers: [ FormBuilder ]
      }).compileComponents();
  
      fixture = TestBed.createComponent(DataImportPopupComponent);
      component = fixture.componentInstance;
    });
  
    it('should create', () => {
      fixture.detectChanges();
      expect(component).toBeTruthy();
    });
})  