import { Component, OnInit, AfterViewInit, NgModule, HostListener, EventEmitter, Output, ViewChild } from '@angular/core';
import { Directive, ElementRef, HostBinding, Input, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import * as textMask from 'vanilla-text-mask/dist/vanillaTextMask.js';

import { UserinfoService } from '../../services/userinfo.service';
import { UtilityService } from '../../services/utility.service';
import { EmailService } from '../../services/email.service';
import { DTMService } from '../../services/dtm.service';

import { AppData } from '../../models/AppData';
import { ProfilePage } from '../../models/ProfilePage';
import { AppConstants } from '../../constants/app-constants';
import { MessagingService } from '../../services/messaging.service';

declare var _satellite;

@Directive({
  // tslint:disable-next-line:directive-selector
  selector: `input-mask, [input-mask], [inputMask]`
})
class InputMaskDirective implements OnInit, OnDestroy {

  @HostBinding('class.input-mask') compClass = true;

  @Input()
  inputMask = {
    mask: [],
    showMask: false,
    guide: true,
    placeholderChar: '_'
  };

  maskedInputController;

  constructor(private readonly element: ElementRef) {}

  ngOnInit(): void {
    this.maskedInputController = textMask.maskInput({
      inputElement: this.element.nativeElement,
      ...this.inputMask
    });
  }

  ngOnDestroy() {
    this.maskedInputController.destroy();
  }
}

@Component({
  templateUrl: './identity-confirm-popup.component.html'
})
export class IdentityConfirmPopupComponent implements OnInit, AfterViewInit {

  @ViewChild('close_btn') close_btn: ElementRef;
  @ViewChild('continue_btn') continue_btn: ElementRef;
  @ViewChild('confirm_btn') confirm_btn: ElementRef;
  @ViewChild('max_retry_close_btn') max_retry_close_btn: ElementRef;
  @ViewChild('first_name') first_name: ElementRef;
  @ViewChild('loading_message') loading_message: ElementRef;
  @ViewChild('error_message_container') error_message_container: ElementRef;
  @ViewChild('identity_confirm_header') identity_confirm_header: ElementRef;
  @ViewChild('identity_confirm_success_header') identity_confirm_success_header: ElementRef;

  @Output() reloadProfileData = new EventEmitter();

  appData: AppData;
  profilePage: ProfilePage;
  confirmIdentityForm: FormGroup;

  componentStyleName = 'lazy-identity-confirm-popup';

  showMBIExample = true;
  showMBI = false;
  showGender = false;
  isZipCodeMandatory = true;
  infoHide = true;
  showPopup = false;
  readOnlyForm = true;
  showLoading = false;
  formSubmitted = false;
  showAuthError = false;
  showAuthSuccess = false;
  showRemainingRetryError = false;
  isMaxRetryReached = false;

  remainingRetryCount = 3;

  mbiMask = AppConstants.mbiMask;
  dateMask = AppConstants.dateMask;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly userInfoService: UserinfoService,
    private readonly utilityService: UtilityService,
    private readonly emailService: EmailService,
    private readonly messagingService: MessagingService,
    private readonly dtmService: DTMService
  ) { }

  ngAfterViewInit(): void {
    setTimeout(() => { this.identity_confirm_header.nativeElement.focus(); }, 1000);
  }

  ngOnInit(): void {
    this.utilityService.lazyLoadStyles(this.componentStyleName).then(() => {
      console.log(this.componentStyleName + '.css loaded successfully');
      this.showPopup = true;

    }).catch(() => {
      console.log(this.componentStyleName + '.css loading failed');
    });

    this.confirmIdentityForm = this.formBuilder.group({
      email       : ['', [Validators.required, Validators.email, Validators.pattern(AppConstants.emailPattern)]],
      firstName   : ['', [Validators.required]],
      lastName    : ['', [Validators.required]],
      gender      : [''],
      mbi         : [''],
      dob         : ['', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]],
      zipCode     : ['', [Validators.required]]
    });

    this.loadFormFieldsAndData();
    this.initialize_satellite_object();
  }

  get f() {
    return this.confirmIdentityForm.controls;
  }

  renderFullName() {
    return this.utilityService.renderFullName(this.f.firstName.value, this.f.lastName.value);
  }

  isPersonalInfoEditable() {
    return this.profilePage && this.profilePage.EnableEditInformationLink === AppConstants.TRUE_VALUE;
  }

  isUserDetailsExists() {
    return this.appData && this.appData.profileDetails && this.appData.profileDetails.userDetails;
  }

  loadFormFieldsAndData() {
    if (this.isUserDetailsExists()) {
      const userDetails = this.appData.profileDetails.userDetails;
      const telesalesProfileType = userDetails.telesalesProfileType;

      if (telesalesProfileType && telesalesProfileType === 'MEMBER-CONSENT') {
         this.showGender = false;
         this.showMBI  = true;
         this.isZipCodeMandatory = false;
         this.f.mbi.setValidators([Validators.required, Validators.minLength(13), Validators.maxLength(13)]);
         this.f.zipCode.clearValidators();
         this.f.mbi.updateValueAndValidity();
         this.f.zipCode.updateValueAndValidity();
         this.dtmService.setDTMData( {visitorProfile: {type: 'member-consent'}});

      } else if (telesalesProfileType && telesalesProfileType === 'MEMBER-NO-CONSENT') {
          this.showGender = false;
          this.showMBI = false;
          this.isZipCodeMandatory = true;
          this.f.mbi.clearValidators();
          this.f.zipCode.setValidators([Validators.required]);
          this.f.mbi.updateValueAndValidity();
          this.f.zipCode.updateValueAndValidity();
          this.dtmService.setDTMData({visitorProfile: {type: 'member-nonconsent'}});

      } else if (telesalesProfileType && (telesalesProfileType === 'NON-MEMBER-NO-CONSENT' || telesalesProfileType === 'NON-MEMBER-CONSENT')) {
          this.showMBI = false;
          this.showGender = true;
          this.isZipCodeMandatory = true;
          this.f.gender.setValidators([Validators.required]);
          this.f.gender.updateValueAndValidity();
          this.dtmService.setDTMData({visitorProfile: {type: telesalesProfileType.toLowerCase()}});

      } else {
        console.log('Invalid Telesales profile type');
      }

      this.confirmIdentityForm.get('email').setValue(userDetails.email ? userDetails.email : '');
      this.confirmIdentityForm.get('firstName').setValue(userDetails.firstName ? userDetails.firstName : '');
      this.confirmIdentityForm.get('lastName').setValue(userDetails.lastName ? userDetails.lastName : '');
    }
  }

  editDetails() {
    this.readOnlyForm = false;
  }

  closePopup() {
    this.showPopup = false;

    if (!this.showAuthSuccess && !this.isMaxRetryReached) {
      this.userInfoService.updateProfile({action : 's'}).subscribe((data) => {
        // console.log(data);
        this.reloadProfileData.emit(true);

      }, (error) => {
        console.log('Failed to save user preference');
      });
    } else {
      this.reloadProfileData.emit(false);
    }
  }

  toggleMedicareNumber() {
    this.showMBIExample = !this.showMBIExample;
  }

  confirmIdentity(event: any) {
    this.formSubmitted = true;
    this.showAuthError = this.showAuthSuccess = this.isMaxRetryReached = false;

    if (this.confirmIdentityForm.invalid) {
      event.target.querySelector('.ng-invalid').focus();
      this.readOnlyForm = this.isPersonalInfoEditable() ? false : true;
      return;
    }

    if (this.isPersonalInfoEditable() && !this.readOnlyForm) {
      this.readOnlyForm = true;
    }

    this.showLoading = true;
    setTimeout(() => { this.loading_message.nativeElement.focus(); }, 100);

    const userData: any = {...this.confirmIdentityForm.value};
    userData.action = 'm';

    this.trackData('ImportConfirm');

    this.userInfoService.updateProfile(userData).subscribe((data) => {
      // console.log(data);

      if (data && data.isProfileMerged === true) {
        this.showAuthSuccess = true;
        this.showLoading = false;

        this.reloadProfileData.emit(true);
        setTimeout(() => { this.identity_confirm_success_header.nativeElement.focus(); }, 100);

        if (data.mergedProfile) {
          /**** Send Email to Stop Reminders ****/
          const emailDeepLinkUrl = location.origin + this.profilePage.emailDeepLinkUrl;
          this.emailService.stopReminderEmail(data.mergedProfile, emailDeepLinkUrl);
        }

        if (this.isUserDetailsExists()) {
          /**** Send Consumer Profile Merged Domo Message ****/
          this.messagingService.createAndSendDomoMessage(this.appData.profileDetails.userDetails.uuid, 'Consumer - Profile Merged');
          /**** Send tracking data to Kafka Proxy Service ****/
          this.messagingService.trackProfileActions('MergedProfile - ' + this.appData.profileDetails.userDetails.telesalesProfileType, 'profileMerge');
        }
        this.trackData('ImportSuccess');

      } else {
        this.showAuthError = true;
        this.showLoading = false;
        setTimeout(() => { this.error_message_container.nativeElement.focus(); }, 100);
        this.trackData('uierror');

        if (data && data.remainingRetryCount > 0) {
          this.remainingRetryCount = data.remainingRetryCount;
          this.showRemainingRetryError = true;

        } else if (data && data.remainingRetryCount === 0) {
          this.remainingRetryCount = data.remainingRetryCount;
          this.showRemainingRetryError = this.isMaxRetryReached = true;
        }
      }
    }, (error) => {
      console.log('Some error occurred while confirming User Identity');
      console.log(error);

      this.showAuthError = true;
      this.showLoading = false;
      setTimeout(() => { this.error_message_container.nativeElement.focus(); }, 100);
      this.trackData('uierror');

      if (error && error.error && error.error.isProfileMerged === false) {
        if (error.error.remainingRetryCount > 0) {
          this.remainingRetryCount = error.error.remainingRetryCount;
          this.showRemainingRetryError = true;

        } else if (error.error.remainingRetryCount === 0) {
          this.remainingRetryCount = error.error.remainingRetryCount;
          this.showRemainingRetryError = this.isMaxRetryReached = true;
        }
      }
    });
  }

  initialize_satellite_object() {
    try {
      if (typeof _satellite === 'undefined' || typeof _satellite.track === 'undefined') {
        _satellite = {
          track: () => {}
        };
      }
    } catch (e) {
      console.log('Some error occurred while initializing _satellite object.');
    }
  }

  trackData(event: string) {
    try {
      if (typeof _satellite !== 'undefined' && _satellite && typeof _satellite.track !== 'undefined' && _satellite.track) {
        _satellite.track(event);
      }
    } catch (e) {
      console.log('Some error occurred while tracking _satellite event.');
    }
  }

  @HostListener('document:keydown', ['$event'])
  handleKeyboardEvent(event: KeyboardEvent) {
    // tslint:disable-next-line: deprecation
    if (event.keyCode === 27) { // Escape key pressed
      this.closePopup();
    }
  }

  closeBtn_keydown(event: any) {
    if (event.shiftKey && event.keyCode === 9) {
      if (this.isMaxRetryReached) {
        this.max_retry_close_btn.nativeElement.focus();
      } else if ( this.showAuthSuccess) {
        this.continue_btn.nativeElement.focus();
      } else {
        this.confirm_btn.nativeElement.focus();
      }
      event.preventDefault();
    }
  }
  editLink_keydown(event: any) {
    if (event.keyCode === 13 || event.keyCode === 32) {
      this.editDetails();
      setTimeout(() => { this.first_name.nativeElement.focus(); }, 500);
      event.preventDefault();

    } else if (event.shiftKey && event.keyCode === 9) {
      this.close_btn.nativeElement.focus();
      event.preventDefault();
    }
  }
  confirmBtn_keydown(event: any) {
    if (!event.shiftKey && event.keyCode === 9) {
      if (this.isMaxRetryReached) {
        this.max_retry_close_btn.nativeElement.focus();
      } else {
        this.close_btn.nativeElement.focus();
      }
      event.preventDefault();
    }
  }
  maxRetryCloseBtn_keydown(event: any) {
    if (!event.shiftKey && event.keyCode === 9) {
      this.close_btn.nativeElement.focus();
      event.preventDefault();
    }
  }
  continueBtn_keydown(event: any) {
    if (!event.shiftKey && event.keyCode === 9) {
      this.close_btn.nativeElement.focus();
      event.preventDefault();
    }
  }

}

@NgModule({
  declarations: [
    InputMaskDirective,
    IdentityConfirmPopupComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    UserinfoService,
    UtilityService,
    EmailService,
    MessagingService
  ]
})
class LazyModule {}
