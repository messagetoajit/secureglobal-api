export class MessagingConstants {

    static business_event                       = 'business_event';
    static user_tracking_system                 = 'dtsaas';
    static kafka_producer_cn                    = 'mnr.ucp.portal';
    static kafka_topic_test                     = 'kaas.mnr-portal.data-event.test';
    static kafka_topic_stage                    = 'kaas.mnr-portal.data-event.stage';
    static kafka_topic_prod                     = 'kaas.prod.ctc.mnr-portal.data-event.prod';

}
