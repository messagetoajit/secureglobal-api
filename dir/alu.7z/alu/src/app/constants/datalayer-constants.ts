export const DL_EVENT_TYPE = {
  LINK_CLICK: 'linkClick',
  BUTTON_CLICK: 'buttonClick',
  FORM_SUBMIT: 'formSubmit',
  FORM_ERROR: 'formError',
  PAGE_LOAD: 'pageLoad',
  DYNAMIC_CONTENT: 'dynamicContentShow',
  UI_ERROR: 'uierror',
};
export const DL_CONTAINER = {
  SAVED_PLAN: 'saved plan',
  SAVED_DRUG: 'saved drug',
  SAVED_PCP: 'saved pcp',
  PRE: 'recommended plan',
  TFN_SECTION: 'tfn',
  ENROLLMENTS: 'saved enrollments'
};
