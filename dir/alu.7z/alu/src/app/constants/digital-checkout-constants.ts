export class DigitalCheckoutConstants {

    static baseURI                      = '/digital-checkout';
    static userDetailsURL               = '/userDetails';
    static guestURL                     = '/guest';
    static userDataURL                  = '/Users';
    static authValidateURL              = '/apps/aarp/authValidate';
    static logoutURL                    = '/logout';
    static savecsrUserActionsURL        = '/CSRUser/logActivity';
    static updateProfileURL             = '/profiles/merge/v1';

}
