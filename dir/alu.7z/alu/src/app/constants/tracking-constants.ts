declare var customTracking: any;

export class TrackingConstants {

    static eventType = (typeof customTracking !== 'undefined' && customTracking?.eventType) ? customTracking.eventType : {};

    static infoType = (typeof customTracking !== 'undefined' && customTracking?.infoType) ? customTracking.infoType : {};

}
