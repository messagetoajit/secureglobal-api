export class URIConstants {

    static baseURI                          = '/digital-checkout';
    static vppContentPath                   = '/content/commontools/vpp';
    static benefitsTableContentPath         = '/plan/jcr:content/vppParsys/columnCtrlPar/column_control/module-accordion-tabs%20module%20column1/plancardwidget.json';
    static tooltipPath                      = '/tool-tip-configuration/jcr:content/maincontent_empty_template/tooltipconfiguration.20.json';
    static cnsInfoPath                      = '/CnSPlans.20.json';
    static mapdMarketingBullets             = '/bin/vpp/marketingBullets.aarp.mapd.json';
    static pdpMarketingBullets              = '/bin/vpp/marketingBullets.aarp.pdp.json';
    static landroverContentPath             = '/content/landrover.20.json';
    static stateSpecificContentPath         = '/api/assets/MRD/content-fragments/landrover/medicare-supplement-plans-content.json';
    static signInUrl                        = '/optumid-login';
    static registrationUrl                  = '/optumid-registration';
    static teamEnvUrl                       = 'https://www.team-e-aarpmedicareplans.ocp-elr-core-nonprod.optum.com';
    static aarpPharmacyPage                 = 'aarp-pharmacy.html';
    static shopperDataImportContentPath     = '/api/assets/MRD/content-fragments/shopper-data-import-popup.json';

}
