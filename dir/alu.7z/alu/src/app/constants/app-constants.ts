import { NavigationExtras } from '@angular/router';

export class AppConstants {

  /**** Local / Session Storage Keys without 'ucp_' suffix ****/

  static formDataKey                    = 'ngx-webstorage|formdata';
  static providerKey                    = 'provider';

  /**** Local / Session Storage Keys with 'ucp_' suffix ****/

  static geotrackingZip                 = 'geotrackingZip';
  static vppZipcode                     = 'vppZipcode';
  static dceLaunchObj                   = 'dceLaunchObj';
  static deeplinkParams                 = 'deeplinkParams';
  static savedPlanYear                  = 'savedPlanYear';
  static profileUserChatData            = 'profileUserChatData';
  static memberEnrolledPlans            = 'memberEnrolledPlans';
  static sharedInformationSHIP          = 'sharedInformationSHIP';
  static dcActiveYear                   = 'dcActiveYear';
  static isDefaultPlan                  = 'isDefaultPlan';
  static geotrackingState               = 'geotrackingState';
  static dceVisitorProfileFlag          = 'dceVisitorProfileFlag';
  static isRetailPharmacy               = 'isRetailPharmacy';
  static lastSavedPlan                  = 'lastSavedPlan';
  static dceDetailsToPlanDetails        = 'dceDetailsToPlanDetails';
  static dceSummaryToPlanDetails        = 'dceSummaryToPlanDetails';
  static prevPage                       = 'prevPage';
  static isProfileDataImported          = 'isProfileDataImported';
  static isReloadDataImportPopup        = 'isReloadDataImportPopup';
  static planRecommendationObj          = 'planRecommendationObj';
  static planRecommendationResults      = 'planRecommendationResults';
  static agentProfileData               = 'agentProfileData';

  /**** Cookie Storage Keys ****/

  static dcCookieName                   = 'dcCookie';
  static dgcCsrCookieName               = 'dgccsrCookie';
  static oleCookieName                  = 'OLEInfoCookie';
  static planInformationCookie          = 'planInformation';
  static locationSessionCookie          = 'locationSessionCookie';
  static tfnSessionCookie               = 'TFNSessionCookie';
  static vppSourceTFNInfo               = 'VppSourceTFNInfo';
  static rxVisitor                      = 'rxVisitor';

  /**** String Constants ****/

  static invalidSession                 = 'Invalid session';
  static submitted                      = 'Submitted';
  static pending                        = 'Pending';
  static approved                       = 'Approved';
  static withdrawn                      = 'Withdrawn';
  static denied                         = 'Denied';
  static continueEnrollment             = 'Continue Enrollment';
  static agent                          = 'AGENT';
  static localhost                      = 'localhost';
  static aarpmedicareplans              = 'aarpmedicareplans';
  static aarp                           = 'aarp';
  static uhc                            = 'uhc';
  static AMP                            = 'AMP';
  static UMS                            = 'UMS';
  static retailChainPharmacy            = 'Retail Chain Pharmacy';
  static optumRxMailServicePharmacy     = 'OptumRx Mail Service Pharmacy';
  static retailChainPharmacyNo          = '2426814';
  static preferredMailServicePharmacyNo = '05TSC';
  static uhcDualCompHMODSNP2021Plan     = 'H1360001000';
  static uhcDualComp1HMODSNP2021Plan    = 'H3387013000';
  static savedProvider                  = 'Saved Provider';
  static drug                           = 'drug';
  static doctor                         = 'doctor';
  static defaultCostValue               = '--';
  static estimatedAnnualDrugCost        = 'Estimated Annual Drug Cost';
  static monthlyPremium                 = 'Monthly Premium';
  static prescriptionDrusTier1          = 'Prescription Drugs, Tier 1';
  static TRUE_VALUE                     = 'true';
  static FALSE_VALUE                    = 'false';
  static GPS_OLE_CONFIRM_NO_PREFIX      = 'WS';
  static DRUG_FREQUENCIES               = ['day', 'week', 'month'];
  static DRUG_SUPPLY_LENGTHS            = ['30', '90', 'every 1 month', 'every 3 months'];
  static FEDERAL_PLAN_TYPES             = ['MA', 'MAPD', 'PDP', 'SNP'];
  static PRE_EMPTY                      = 'PRE_EMPTY';
  static PRE_RANKED                     = 'PRE_RANKED';
  static PRE_EQUAL                      = 'PRE_EQUAL';
  static PRE_SINGLE                     = 'PRE_SINGLE';
  static PRE_SINGLE_UNRANKED            = 'PRE_SINGLE_UNRANKED';
  static PRE_NONE                       = 'PRE_NONE';
  static PRE_NO_1_RANKED_PLAN           = 'PRE_NO_1_RANKED_PLAN';
  static landroverPage                  = 'landrover';
  static shopperDataImportComponentName = 'lazy-data-import-popup';
  static defaultCloseIcon               = '/content/dam/MRD/images/icons/close-icon@2x.png';
  static getStarted                     = 'Get Started';
  static EVERY_1_MONTH                  = 'Every 1 Month';
  static EVERY_3_MONTHS                 = 'Every 3 Months';
  static errBenefitsNotFound            = 'Benefits not found !!';

  /**** Form Validation Constants ****/

  static emailPattern                   = '[A-Za-z0-9._%\'-]+@[A-Za-z0-9.-]+\.[a-zA-Z]{2,4}$';
  static zipPattern                     = '[0-9]{5}';
  static datePattern                    = '(?:(?:0[1-9]|1[0-2])[\/\\-. ]?(?:0[1-9]|[12][0-9])|(?:(?:0[13-9]|1[0-2])[\/\\-. ]?30)|(?:(?:0[13578]|1[02])[\/\\-. ]?31))[\/\\-. ]?(?:19|20)[0-9]{2}';
  static mbiPattern                     = '[0-9]{1}[A-Za-z0-9]{2}[0-9]{1}-[A-Za-z0-9]{2}[0-9]{1}-[A-Za-z0-9]{2}[0-9]{2}';
  static numberPattern                  = '[0-9]';
  static alphaNumericPattern            = '[A-Za-z0-9]';

  static mbiMask                        = {
    mask: [
      new RegExp(AppConstants.numberPattern),
      new RegExp(AppConstants.alphaNumericPattern),
      new RegExp(AppConstants.alphaNumericPattern),
      new RegExp(AppConstants.numberPattern),
      '-',
      new RegExp(AppConstants.alphaNumericPattern),
      new RegExp(AppConstants.alphaNumericPattern),
      new RegExp(AppConstants.numberPattern),
      '-',
      new RegExp(AppConstants.alphaNumericPattern),
      new RegExp(AppConstants.alphaNumericPattern),
      new RegExp(AppConstants.numberPattern),
      new RegExp(AppConstants.numberPattern)

    ],
    showMask: false,
    guide: false,
    placeholderChar: '_'
  };

  static dateMask                       = {
    mask: [
      new RegExp(AppConstants.numberPattern),
      new RegExp(AppConstants.numberPattern),
      '/',
      new RegExp(AppConstants.numberPattern),
      new RegExp(AppConstants.numberPattern),
      '/',
      new RegExp(AppConstants.numberPattern),
      new RegExp(AppConstants.numberPattern),
      new RegExp(AppConstants.numberPattern),
      new RegExp(AppConstants.numberPattern)

    ],
    showMask: false,
    guide: false,
    placeholderChar: '_'
  };

  static submittedOLEStatus             = {
    1:  { gps_status: 'New',                          portal_status: AppConstants.pending },
    2:  { gps_status: 'Pending SMS Outbound',         portal_status: AppConstants.pending },
    3:  { gps_status: 'Pending SMS Inbound',          portal_status: AppConstants.pending },
    4:  { gps_status: 'SMS Received',                 portal_status: AppConstants.pending },
    5:  { gps_status: 'Post SMS Validation',          portal_status: AppConstants.pending },
    6:  { gps_status: 'Pre CMS Validation',           portal_status: AppConstants.pending },
    7:  { gps_status: 'Pending CMS Outbound',         portal_status: AppConstants.pending },
    8:  { gps_status: 'Pending CMS Inbound',          portal_status: AppConstants.pending },
    9:  { gps_status: 'CMS Received',                 portal_status: AppConstants.pending },
    10: { gps_status: 'CMS Auto Enroll Pre Approved', portal_status: AppConstants.pending },
    11: { gps_status: 'Approved',                     portal_status: AppConstants.approved},
    12: { gps_status: 'Denied',                       portal_status: AppConstants.denied  },
    13: { gps_status: 'Withdrawn',                    portal_status: AppConstants.withdrawn},
    14: { gps_status: 'Employer_changes_Review',      portal_status: AppConstants.pending },
    15: { gps_status: 'SNP Validation',               portal_status: AppConstants.pending },
    16: { gps_status: 'PCP Validation',               portal_status: AppConstants.pending },
    17: { gps_status: 'Forward to External System',   portal_status: AppConstants.pending },
    18: { gps_status: 'Sent to External System',      portal_status: AppConstants.pending },
    19: { gps_status: 'Imcomplete',                   portal_status: AppConstants.pending },
    20: { gps_status: 'Mailed',                       portal_status: AppConstants.pending },
    21: { gps_status: 'Migrated',                     portal_status: AppConstants.pending },
    22: { gps_status: 'Pending BEQ Outbound',         portal_status: AppConstants.pending },
    23: { gps_status: 'Pending BEQ Inbound',          portal_status: AppConstants.pending },
    24: { gps_status: 'BEQ Received',                 portal_status: AppConstants.pending }
  };

  static navigationConfig               = {
    queryParams         : { code: undefined },
    queryParamsHandling : 'merge',
    replaceUrl          : true
  } as NavigationExtras;

}
