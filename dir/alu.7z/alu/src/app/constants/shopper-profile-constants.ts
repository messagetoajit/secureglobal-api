export class ShopperProfileConstants {

    static baseURI                          = '/shopper-profile';

    static trackProfile                     = '/api/profiles/track/v1';
    static domoMessagingURL                 = '/api/domo/v1';
    static oleApplicationsStatus            = '/api/applications/status/v1/search';
    static importShopperItemsURL            = '/api/shopper-items/import/v1';

}
