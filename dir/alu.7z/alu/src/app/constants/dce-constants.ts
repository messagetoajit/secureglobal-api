export class DCEConstants {

    static planBenefitsBaseURI      = '/planbenefitsinfo';
    static drugInfoBaseURI          = '/drug-info-api/druginfo';
    static drugPricingBaseURI       = '/drug-pricing-api/drugpricing';
    static pharmacySearchBaseURI    = '/pharmacyinfo';
    static estimatePlanCostsURI     = '/estimateplancost';
    static searchPharmacyURI        = '/searchpharmacy';
    static searchPlansURI           = '/searchplans';
    static genericDrugInfoURI       = '/genericdruginfo';
    static serverDateURI            = '/profiledetail';
    static geoLocationBaseURI       = '/GeoLocationWAR/geolocationrest';
    static geoLocationCountiesURI   = '/counties';
    static drugsInfoURI             = '/drugs/v1/search';
    static individualPlanContacts   = '/planContacts/individual/v1/search';

}
