export class EmailConstants {

    static baseURI                      = '/EmailWAR/emailrest';
    static stopReminderEmailURL         = '/profile/email/v1';

}
