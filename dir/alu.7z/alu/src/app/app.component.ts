import { Component, OnInit, ViewEncapsulation, HostListener, ViewChild, ElementRef, NgZone, Inject } from '@angular/core';
import { ViewContainerRef, ComponentFactoryResolver, ComponentRef } from '@angular/core';
import { Router} from '@angular/router';
import { ReplaySubject } from 'rxjs';
import { DOCUMENT } from '@angular/common';

import { UserinfoService } from './services/userinfo.service';
import { ContentService } from './services/content.service';
import { ProviderService } from './services/provider.service';
import { DrugsAndPharmacyService } from './services/drugs-and-pharmacy.service';
import { PlanService } from './services/plan.service';
import { CookieService } from './services/cookie.service';
import { DTMService } from './services/dtm.service';
import { OLEService } from './services/ole.service';
import { PREService } from './services/pre.service';
import { DateUtilityService } from './services/date-utility.service';
import { StorageService } from './services/storage.service';
import { UtilityService } from './services/utility.service';
import { MessagingService } from './services/messaging.service';
import { TooltipService } from './services/tooltip.service';
import { TFNService } from './services/tfn.service';
import { UserDataContextService } from './services/user-data-context.service';
import { TrackingService } from './services/tracking.service';
import { DataLayerService } from './services/datalayer.service';

import { AppData } from './models/AppData';
import { ProfilePage } from './models/ProfilePage';
import { UserProfile } from './models/UserProfile';
import { AppConstants } from './constants/app-constants';
import { URIConstants } from './constants/uri-constants';
import { Plan } from './models/Plan';
import { TrackingConstants } from './constants/tracking-constants';
import { AppContent } from './models/AppContent';
import { DL_EVENT_TYPE } from './constants/datalayer-constants';

declare var dgcUUID: any;
declare var controller: any;
declare var sharedInformationSHIP: any;
declare var SERVICE_PATTERN_CHAT_CONFIG: any;
declare var getSelectedStateCode: any;
declare var $;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  encapsulation : ViewEncapsulation.None
})
export class AppComponent implements OnInit {

  @ViewChild('new_header_section') new_header_section: ElementRef;
  @ViewChild('legacy_header_section') legacy_header_section: ElementRef;
  @ViewChild('confirm_identity_container', {read: ViewContainerRef}) confirmIdentityContainerRef: ViewContainerRef;
  @ViewChild('data_import_container', { read: ViewContainerRef }) dataImportContainerRef?: ViewContainerRef;

  showDataImportLoader = false;
  lazyDataImportComponent?: ComponentRef<any>;
  appContent: AppContent = new AppContent();

  lazyComponent: ComponentRef<any>;
  searchPlansCall = new ReplaySubject(2);
  currentYear = new Date().getFullYear();
  appData: AppData = new AppData();
  profilePage: ProfilePage = new ProfilePage();

  showModalFlag = false;
  isCSRLogin = false;
  isRedirectionFlow = false;
  showLoader = false;
  loaderMessage = 'Loading...';
  showGuestAlertTip = true;
  backLinkText = '';
  dceVisitorProfileFlag = '';
  onlyOneMaPlan = false;
  onlyOnePdpPlan = false;
  onlyOneDsnpPlan = false;
  tollFreeNumber = '';
  dcePharmacyFlag = '';
  isProfileDataImported: boolean;
  showImportTip: boolean;
  showImportTipForPlanId: string;
  showNotification = false;
  notificationType = '';
  notificationContent = '';
  selectedState;
  intervalRef: any;

  userDetails: any = {
    fullName: null, nickName: null, firstName: null, lastName: null,
    uuid: null, email: null, optumId: null
  };

  idleInterval: any;
  idleTime = 0;
  brandNavElement = '.footer, .brandandnavigation';

  constructor(
    private readonly zone: NgZone,
    private readonly userinfoService: UserinfoService,
    private readonly contentService: ContentService,
    private readonly planService: PlanService,
    private readonly router: Router,
    private readonly tooltipService: TooltipService,
    private readonly drugsAndPharmacyService: DrugsAndPharmacyService,
    private readonly providerService: ProviderService,
    private readonly oleService: OLEService,
    private readonly preService: PREService,
    private readonly dtmService: DTMService,
    private readonly cookieService: CookieService,
    private readonly dateUtilService: DateUtilityService,
    private readonly storageService: StorageService,
    private readonly userDataContextService: UserDataContextService,
    private readonly utilityService: UtilityService,
    private readonly messagingService: MessagingService,
    private readonly componentFactoryResolver: ComponentFactoryResolver,
    @Inject(DOCUMENT) private readonly document: Document,
    private readonly tfnService: TFNService,
    private readonly trackingService: TrackingService,
    private readonly dataLayerService: DataLayerService
  ) {
    // tslint:disable-next-line:no-string-literal
    window['landroverAppComponent'] = {
      zone: this.zone,
      rebuildPlansData: (buildMedsuppPlans) => this.rebuildPlansData(buildMedsuppPlans)
    };
  }

  ngOnInit() {
    const isProfileDataImported = this.storageService.getItem_SS(AppConstants.isProfileDataImported);
    if (isProfileDataImported && isProfileDataImported === AppConstants.TRUE_VALUE) {
      this.isProfileDataImported = true;
    }

    const sharedInfoSHIPData = this.storageService.getItem_SS(AppConstants.sharedInformationSHIP);
    if (sharedInfoSHIPData) {
      sharedInformationSHIP = JSON.parse(sharedInfoSHIPData);
    }

    if (this.utilityService.isLocalHost()) {
      this.cookieService.setCookie('TFNSessionCookie', '810027,AEP,1-877-699-5710,1-877-699-5710,4575,/change-location.html,false,false,null');
      this.cookieService.setCookie('dcCookie', JSON.stringify({uuid : '5beaa7e5-348c-47ed-9c33-9e363faada3e', isGuest : false}));
      this.cookieService.setCookie('dgcCookie', '68b6f3d4bf0e5ac6a6e1c03e6d640fd3b8aff36c60b7f21a9d717829d5cc6878b392392ef521a9ae38d06d28e224cee4f63bb3408a697e4f7b5d4cbb313df37e15816742679846cb544876bea9551fae21055eb9a87c7de2052b3d198d3e0278');
    }

    const uuid = this.cookieService.getUuidFromCookie();

    if (this.utilityService.getQueryParamValue('planId') && this.utilityService.getQueryParamValue('year')) {
      this.storageService.setItem_SS(AppConstants.deeplinkParams, JSON.stringify({planId: this.utilityService.getQueryParamValue('planId'), year: this.utilityService.getQueryParamValue('year')}));

      if (this.cookieService.isGuestUser()) {
        this.utilityService.navigateToURL(this.profilePage.signInUrl);
      }
    }

    if (this.utilityService.getQueryParamValue('code') || this.utilityService.getQueryParamValue('token') ) {
      if (this.utilityService.getQueryParamValue('token')) {
        console.log('Agent redirection flow...');
        this.isCSRLogin = this.isRedirectionFlow = true;
        this.setProcessingOverlay(true, 'Redirecting to VPP page...');
        this.enableAgentMode();
      }
      this.authValidate(this.utilityService.getQueryParamValue('code'), this.utilityService.getQueryParamValue('token'));

    } else if (uuid && uuid !== '') {
      console.log('Agent Cloaked in to profile page');

      const csrInfo = this.cookieService.getDcCookie();
      this.isCSRLogin = csrInfo?.isCSRLogin === true;

      console.log('isCSRLogin :: ' + this.isCSRLogin);
      this.getUserData(uuid, false);
    } else {
      this.cookieService.deleteCookie(AppConstants.dcCookieName);
      this.dtmService.setDTMData({content: {pageName: 'Visitor Profile:Guest'}});
      this.getUserData(null, false);
    }

    this.doCustomTracking();
    this.setProfilePage();
    this.extractBackLink();
    this.getTollFreeNumber();
    this.setDataImportPopupContent();
  }


  doCustomTracking() {
    const trackingData = [{
      isCSRLogin: this.isCSRLogin,
      uuid: this.cookieService.getUuidFromCookie(),
      isGuestUser: this.cookieService.isGuestUser()
    }];

    this.trackingService.track(TrackingConstants.infoType.SESSION_INFO, 'Acquisition Data', trackingData, TrackingConstants.eventType.ACTION);

    if (this.isCSRLogin) {
      this.trackingService.track(TrackingConstants.infoType.SESSION_INFO, 'Telesales Check', trackingData, TrackingConstants.eventType.LOAD);
    }
  }

  private extractBackLink() {
    this.dcePharmacyFlag = this.storageService.getItem_SS(AppConstants.prevPage);
    this.dceVisitorProfileFlag = this.storageService.getItem_SS(AppConstants.dceVisitorProfileFlag);

    if (this.dcePharmacyFlag?.indexOf(URIConstants.aarpPharmacyPage) > -1) {
      this.backLinkText = 'Return to Pharmacy Search';

    } else if (this.dceVisitorProfileFlag && (this.dceVisitorProfileFlag === 'dcePlanDetails' || this.dceVisitorProfileFlag === 'dcePlanSummary'
        || this.dceVisitorProfileFlag === 'dceGetStarted' || this.dceVisitorProfileFlag === 'dceBuildDrug' || this.dceVisitorProfileFlag === 'dceZipInformation')) {
      this.backLinkText = 'Back to Drug Cost Estimator';

    } else {
      this.backLinkText = 'Back to Plans';
    }
  }

  setProcessingOverlay(showOverlay: boolean, message: string) {
    this.loaderMessage = message;
    this.showLoader = showOverlay;
  }

  getTollFreeNumber() {
    const thiz = this;
    setTimeout(() => {
      thiz.tollFreeNumber = thiz.tfnService.getAuthorTFN();
    }, 2000);
  }

  get state() {
    if (!this.selectedState && typeof(getSelectedStateCode) !== 'undefined' && typeof (getSelectedStateCode) === 'function') {
      this.selectedState = getSelectedStateCode();
    }
    return this.selectedState;
  }

  authValidate(code: string, token: string): void {
    const authValidateInputRequestData = {
      code,
      requestHost: this.utilityService.isNotLocalHost() ? location.origin : URIConstants.teamEnvUrl,
      dcClientCookie: this.cookieService.getCookie(AppConstants.dcCookieName),
      csrToken: token
    };

    this.userinfoService.authValidate(authValidateInputRequestData).subscribe(data => {
      if (data && data.uuid) {
        this.appData.agentUserName = data.agentUserName;

        if (data.isNewOptumIdProfileCreated && data.isNewOptumIdProfileCreated === true){
          this.messagingService.trackProfileActions('Create - ConsumerProfile', 'createConsumerProfile');
        }
        this.getUserData(data.uuid, true);
      }
    }, (error) => console.log(error));
  }

  getActiveYear(dceSystemDateTime: Date): number {
    const dceSystemYear = dceSystemDateTime.getFullYear();
    const dceSystemMonth = dceSystemDateTime.getMonth();
    const activeYear = this.dateUtilService.isAEPPeriod(dceSystemMonth) ? (dceSystemYear + 1) : dceSystemYear;

    const deepLinkParams = this.storageService.getItem_SS(AppConstants.deeplinkParams);
    const deepLinkParamsObj = deepLinkParams ? JSON.parse(deepLinkParams) : null;

    return deepLinkParamsObj ? (deepLinkParamsObj.year ? deepLinkParamsObj.year : activeYear) : activeYear;
  }

  getUserData(uuid: string, checkTempProfiles: boolean) {
    this.contentService.getDCEServerDateTime().subscribe((response: any) => {
      this.appData.dceSystemDateTime = response && response.data && response.data.systemDate ? new Date(response.data.systemDate) : new Date();
      console.log('************ DCE SYSTEM DATE ************');
      console.log(this.appData.dceSystemDateTime);
      console.log('*****************************************');

      const dceSystemYear = this.appData.dceSystemDateTime.getFullYear();
      this.currentYear = dceSystemYear;
      const savedPlanYear = this.storageService.getItem_LS(AppConstants.savedPlanYear);
      if (savedPlanYear) {
        this.appData.activeYear = +savedPlanYear;
        // this.storageService.removeItem_LS(AppConstants.savedPlanYear);
      } else {
        this.appData.activeYear = this.getActiveYear(this.appData.dceSystemDateTime);
      }

      this.getProfileData(uuid, checkTempProfiles);

    }, (errorResponse) => console.log(errorResponse));
  }

  updateChatConfigObject(): void {
    try {
      if (this.userDetails ) {
        const profileUserChatData: any = [`firstName:${this.userDetails.firstName}`, `lastName:${this.userDetails.lastName}`, `uuid :${this.userDetails.uuid }`, `email:${this.userDetails.email}`];
        if (SERVICE_PATTERN_CHAT_CONFIG && typeof SERVICE_PATTERN_CHAT_CONFIG === 'object' && SERVICE_PATTERN_CHAT_CONFIG.constructor === Object && SERVICE_PATTERN_CHAT_CONFIG.parameters){
          SERVICE_PATTERN_CHAT_CONFIG.parameters.visitorProfile = profileUserChatData;
        }
        this.storageService.setItem_SS(AppConstants.profileUserChatData, JSON.stringify(profileUserChatData));
      }

    } catch (e) {
      console.log('Some error occurred while updating chat config object');
    }
  }

  async lazyLoadIdentityConfirmPopup() {
    console.log('Identity Confirmation popup laoding in progress...');
    this.confirmIdentityContainerRef.clear();

    const { IdentityConfirmPopupComponent } = await import('./lazy-load/identity-confirm-popup/identity-confirm-popup.component');
    const factory = this.componentFactoryResolver.resolveComponentFactory(IdentityConfirmPopupComponent);
    this.lazyComponent = this.confirmIdentityContainerRef.createComponent(factory);

    this.lazyComponent.instance.appData = this.appData;
    this.lazyComponent.instance.profilePage = this.profilePage;

    this.lazyComponent.instance.reloadProfileData.subscribe((isDataMerged) => {
      if (isDataMerged) {
        console.log('Going to reload updated profile data...');
        const uuid = this.cookieService.getUuidFromCookie();
        this.getProfileData(uuid, false);
      }
      setTimeout(() => { this.isMedsuppPlansExists ? this.legacy_header_section?.nativeElement?.focus() : this.new_header_section?.nativeElement?.focus(); }, 100);

    }, (error) => {
      console.log('Error occured while capturing lazy loaded compoenent emitted event', error);
    });

    console.log('Identity Confirmation popup loaded successfully.');
  }

  getProfileData(uuid: string, checkTempProfiles: boolean): void {
    if (uuid) {
      this.userinfoService.getProfileData(uuid, 'all', this.appData.activeYear.toString(), checkTempProfiles).subscribe((response: UserProfile) => {
        let isGuest = true;
        // response.plansDetails = null;
        // response.drugsAndPharmacyDetails = undefined;
        // response.providersDetails = undefined;
        // response.enrollmentsDetails = undefined;
        // this.isProfileDataImported = true;
        this.appData.profileDetails = response;

        console.log(response);

        if (this.utilityService.isNotLocalHost() && !this.cookieService.isGuestUser() && !(response && response.userDetails)) {
          this.userinfoService.logout().subscribe(data => {
            this.userinfoService.deleteBrowserStorage();
            this.utilityService.navigateToURL(this.profilePage.signInUrl);
          });
        }

        const dataImportPopupReloadData = this.storageService.getItem_SS(AppConstants.isReloadDataImportPopup);

        if (response && response.userDetails && response.userDetails.uuid) {
          if (this.utilityService.isNotLocalHost()) {
            this.initializeIdleInterval();
          }

          console.log('Authenticated User');
          setTimeout(() => { this.router.navigate(['authenticated'], AppConstants.navigationConfig); }, 500);

          if (this.utilityService.isLoadIdentityConfirmPopup(response.userDetails)) {
            this.lazyLoadIdentityConfirmPopup();
          }

          this.userDetails = response.userDetails;

          this.updateChatConfigObject();

          if (this.isCSRLogin === true) {
            const csrInfo = this.cookieService.getDcCookie();

            if (csrInfo && csrInfo.isWriteEnabledForCSR === true) {
              this.cookieService.setCSRDcCookie(this.userDetails.uuid, false, true, true);
              this.appData.isWriteEnabledForCSR = csrInfo.isWriteEnabledForCSR;
              $(this.brandNavElement).css({'pointer-events': 'auto'}).removeClass('cloak-in');

            } else {
              this.cookieService.setCSRDcCookie(this.userDetails.uuid, false, false, true);
              this.appData.isWriteEnabledForCSR = false;
              $(this.brandNavElement).css({'pointer-events': 'none'}).addClass('cloak-in');
            }
            this.appData.isCSRLogin = true;

          } else {
            this.cookieService.setDcCookie(this.userDetails.uuid, false);

            if (dataImportPopupReloadData === AppConstants.TRUE_VALUE) {
              this.importShopperData();
            }
            this.storageService.removeItem_SS(AppConstants.isReloadDataImportPopup);
          }

          this.setdgcUUID(response.userDetails.uuid);
          this.getTollFreeNumber();
          isGuest = false;

        } else {
          setTimeout(() => { this.router.navigate(['guest'], AppConstants.navigationConfig); }, 500);
        }

        if (dataImportPopupReloadData !== AppConstants.TRUE_VALUE) {

          if (!isGuest) {
            const previousPage = this.storageService.getItem_SS(AppConstants.prevPage);
            const vpDataLayerObject = this.utilityService.getVPDLDataObject(this.appData?.profileDetails);
            this.dataLayerService.setDLPageLoadEvent(this.profilePage, previousPage, vpDataLayerObject);
          }

          this.dtmService.setDTMData({
            content: {
              pageName: (isGuest ? 'Visitor Profile:Guest' : 'Visitor Profile:Authenticated')
            }
          });
        }

        if (this.appData.profileDetails) {
          this.buildMedsuppPlansData();
          this.getPlansContent();
        }

      }, (errorResponse) => {
        console.log(errorResponse);

        if (this.utilityService.isNotLocalHost()) {
          if (errorResponse.error && errorResponse.error.statusCode === 401 && errorResponse.error.message === AppConstants.invalidSession) {
            console.log('Invalid session (401) : Fetching data after server dgcCookie ->');

            this.userinfoService.logout().subscribe(data => {
              this.getUserData(uuid, false);
            }, (error) => console.log(error));
          }

          setTimeout(() => { this.router.navigate(['guest'], AppConstants.navigationConfig); }, 500);
        }
      });
    }
  }

  getPlansContent(): void {
    this.contentService.getPlansContent().subscribe(responseArray => {
      this.appData.mapdMarketingBullets = responseArray[0];
      this.appData.pdpMarketingBullets = responseArray[1];
      this.appData.planBenefitsContent = responseArray[2];
      const tooltips = {tooltipkey:  responseArray[4].customtooltipkey, tooltipvalue: responseArray[4].customtooltipvalue};
      this.appData.tooltips = {...tooltips};

      this.appData = this.planService.setPlansContentData(this.appData, responseArray[3]);
      this.buildPlansData(false);

    }, (error) => {
      console.log('Some error occurred while fetching plans content');
      console.log(error);
    });
  }

  cloakIntoVPP(): void {
    if (this.isRedirectionFlow) {
      console.log('Agent will be redirected...');
      const planDataExists = this.planService.isPlansDataExists(this.appData);
      const drugsDataExists = this.drugsAndPharmacyService.isDrugsDataExists(this.appData);
      const providerDataExists = this.providerService.isProviderDataExists(this.appData);

      if (planDataExists && !drugsDataExists && !providerDataExists) {
        /**** If only Plans data exists, then directly goto VPP ****/
        console.log('1. Only Plans data exists, going to VPP...');
        this.redirectToVPP();

      } else if (drugsDataExists && !providerDataExists) {
        /**** If only Drugs data exists & Provider data doesn't, then on Drugs dataLoadComplete, goto VPP ****/
        console.log('2. Drugs data exists & Provider data does not, on Drugs dataLoadComplete, goto VPP');

        this.drugsAndPharmacyService.getDrugsDataLoadingNotification().subscribe((msg: any) => {
          if (msg && msg.dataLoadComplete) {
            console.log('2.1 Drugs dataLoadComplete successful, going to VPP...');
            this.redirectToVPP();
          }
        });

      } else if (providerDataExists && !planDataExists) {
        /**** If only Providers data exists & Plans data doesn't, then on Providers dataLoadComplete, check for Drugs dataLoadComplete & goto VPP ****/
        console.log('3. Providers data exists & Plans data does not, then on Providers dataLoadComplete, check for Drugs dataLoadComplete & goto VPP');

        this.providerService.getProvidersDataLoadingNotification().subscribe((msg: any) => {
          if (msg && msg.dataLoadComplete) {
            console.log('3.1 Providers dataLoadComplete successful, check for Drugs dataLoadComplete & goto VPP');

            if (drugsDataExists) {
              console.log('3.1.1 searchPlans call completed, check for Drugs dataLoadComplete & goto VPP...');

              this.drugsAndPharmacyService.getDrugsDataLoadingNotification().subscribe((drugMsg: any) => {
                if (drugMsg && drugMsg.dataLoadComplete) {
                  console.log('3.1.1.1 Drugs dataLoadComplete successful, going to VPP...');
                  this.redirectToVPP();
                }
              });
            } else {
              console.log('3.1.1 Providers dataLoadComplete successful, going to VPP...');
              this.redirectToVPP();
            }
          }
        });

      } else if (providerDataExists && planDataExists) {
        /**** If only Providers & Plans data exists, then on searchPlans call completion, check for Drugs dataLoadComplete, then set Providers & goto VPP ****/
        console.log('4. Providers & Plans data exists, then on searchPlans call completion, check for Drugs dataLoadComplete, then set Providers & goto VPP');

        this.searchPlansCall.asObservable().subscribe((msg: any) => {
          if (msg && msg.dataLoadComplete) {
            console.log('4.1 Providers dataLoadComplete successful, check for Drugs dataLoadComplete & goto VPP');

            if (drugsDataExists) {
              console.log('4.1.1 searchPlans call completed, check for Drugs dataLoadComplete & goto VPP...');

              this.drugsAndPharmacyService.getDrugsDataLoadingNotification().subscribe((drugMsg: any) => {
                if (drugMsg && drugMsg.dataLoadComplete) {
                  console.log('4.1.1.1 Drugs dataLoadComplete successful, going to VPP...');
                  this.addPlans();
                }
              });
            } else {
              console.log('4.1.1 searchPlans call completed, set Providers & goto VPP...');
              this.addPlans();
            }
          }
        });
      } else {
        console.log('5. directly going to VPP...');
        this.redirectToVPP();
      }
    }
  }

  buildPlansData(buildOnlyPlansData: boolean = true): void {
    this.appData = this.planService.setPlansDetails(this.appData);
    this.cloakIntoVPP();

    if (!buildOnlyPlansData) {
      if (this.planService.isPlansDataExists(this.appData)) {
        setTimeout(() => { this.tooltipService.tooltipmessageservice(); }, 1000);

        this.appData.planSearchResultsList = [];

        this.planService.getPlanBenefits(this.appData.profileDetails.plansDetails.plans[0]).subscribe((benefitsResponsesArray: any) => {

          if (benefitsResponsesArray?.length > 0) {
            benefitsResponsesArray.forEach(benefitsResponse => {
              if (benefitsResponse?.data?.plans?.length > 0) {
                this.appData.planSearchResultsList.push(...benefitsResponse.data.plans);
              }
            });

            this.searchPlansCall.next({dataLoadComplete: true});

            this.planService.setMarketingBullets(this.appData);
            this.planService.setPlanBenefits(this.appData);
          }

          this.buildPREData();
          this.buildEnrollmentData();
          this.mergeDrugsAndPharmacyData();
          this.buildProvidersData();

        }, (error) => {
          this.buildPREData();
          this.buildEnrollmentData();
          this.mergeDrugsAndPharmacyData();
          this.buildProvidersData();
        });

      } else {
        this.buildPREData();
        this.buildEnrollmentData();
        this.mergeDrugsAndPharmacyData();
        this.buildProvidersData();
      }

    } else {
      this.buildEnrollmentData();
      this.planService.setMarketingBullets(this.appData);
      this.planService.setPlanBenefits(this.appData);

      if (this.planService.isPlansDataExists(this.appData)) {
        this.drugsAndPharmacyService.updatePlanDrugsData(this.appData);
      }
    }

  }

  mergeDrugsAndPharmacyData(): void {
    const mergedData = (this.utilityService.isLocalHost() || this.isRedirectionFlow) ? null : this.drugsAndPharmacyService.getDrugsAndPharmacyMergedData(this.appData) ;

    if (mergedData?.drugInfoDetails?.length > 0) {
      this.userinfoService.updateProfileData(this.appData.profileDetails.uuid, 'drugs', { drugsAndPharmacyDetails: mergedData }).subscribe((response: any) => {
        this.userinfoService.getProfileData(this.appData.profileDetails.uuid, 'drugs', '').subscribe((data: UserProfile) => {

          this.appData.profileDetails.drugsAndPharmacyDetails = data.drugsAndPharmacyDetails;
          this.buildDrugsAndPharmacyData();

        }, (error1) => { console.log(error1); this.buildDrugsAndPharmacyData(); });
      }, (error) => { console.log(error); this.buildDrugsAndPharmacyData(); });

    } else {
      this.buildDrugsAndPharmacyData();
    }
  }

  buildDrugsAndPharmacyData(): void {
    const drugsData = this.drugsAndPharmacyService.setDrugsAndPharmacyDetails(this.appData, this.appData.drugsAndPharmacyDataExists);
    this.appData = drugsData.appData;
    this.appData.drugsAndPharmacyDataExists = drugsData.drugsAndPharmacyDataExists;

    if (this.planService.isPlansDataExists(this.appData)) {
      this.drugsAndPharmacyService.getPharmacyDataLoadingNotification().subscribe((pharmacyMsg: any) => {
        if (pharmacyMsg && pharmacyMsg.dataLoadComplete) {
          console.log('Pharmacy data load completed.');
          this.appData = this.drugsAndPharmacyService.updatePlanDrugsData(this.appData);
        }

      }, (error: any) => {
        console.log('Some error occurred while waiting for pharmacy data load completion', error);
      });
    }
  }

  buildProvidersData(): void {
    const providerData = this.providerService.setProvidersDetails(this.appData, this.appData.providersDataExists);
    this.appData = providerData.appData;
    this.appData.providersDataExists = providerData.providersDataExists;
  }

  buildEnrollmentData(): void {
    if (this.isAuthenticatedUser()) {
      const enrollmentData = this.oleService.setEnrollmentDetails(this.appData, this.appData.enrollmentDataExists);
      this.appData = enrollmentData.appData;
      this.appData.enrollmentDataExists = enrollmentData.enrollmentDataExists;
    }
  }

  buildPREData(): void {
    if (this.isAuthenticatedUser()) {
      const preData = this.preService.setPlanRecommendations(this.appData, this.appData.preDataExists);
      this.appData = preData.appData;
      this.appData.preDataExists = preData.preDataExists;
    }
  }

  buildMedsuppPlansData(): void {
    const medsuppPlans: any[] = this.planService.buildMedsuppPlansData(this.appData);
    this.appData.medsuppPlansList = medsuppPlans;
  }

  setProfilePage(): void {
    this.contentService.getLandroverContent().subscribe((profileContent: any) => {
      const properties = {};
      const jcrContent = 'jcr:content';

      if (profileContent && profileContent[jcrContent] && profileContent[jcrContent].brandandnavigation) {
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.header);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.enrollment);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.plancard);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.plans);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.addplans);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.drugsandproviders);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.popup_drugs_provider);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.drugsproviderslist);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.planrecommendation);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.saveplans);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.needhelp);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.confirmIdentity);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.sessiontimeout);
        Object.assign(properties, profileContent[jcrContent].brandandnavigation.removeenrolledplan);

        properties['containerbuttonjsondata'] = profileContent[jcrContent].brandandnavigation?.containerbuttonjsondata;
        properties['containerformjsondata'] = profileContent[jcrContent].brandandnavigation?.containerformjsondata;
        properties['containerlinkjsondata'] = profileContent[jcrContent].brandandnavigation?.containerlinkjsondata;
        properties['containerpagejsondata'] = profileContent[jcrContent].brandandnavigation?.containerpagejsondata;
        properties['containermodaljsondata'] = profileContent[jcrContent].brandandnavigation?.containermodaljsondata;
        properties['containeruierrorjsondata'] = profileContent[jcrContent].brandandnavigation?.containeruierrorjsondata;
      }
      this.profilePage = new ProfilePage(properties);

      setTimeout(() => {
        if (this.cookieService.isGuestUser()) {
            const previousPage = this.storageService.getItem_SS(AppConstants.prevPage);
            const vpDataLayerObject = this.utilityService.getVPDLDataObject(this.appData?.profileDetails);
            this.dataLayerService.setDLPageLoadEvent(this.profilePage, previousPage, vpDataLayerObject);
        }
      }, 1000);

      if (this.lazyComponent && this.lazyComponent.instance) {
        console.log('Setting lazyComponent content after it has been initialized.');
        this.lazyComponent.instance.profilePage = this.profilePage;
      }

      this.setStateSpecificContent();
    }, (error) => {
      console.log('Some Error occurred while fetching AEM Authorable content.');
      console.log(error);
    });
  }

  setStateSpecificContent() {
    this.contentService.getStateSpecificContent().subscribe((stateContent: any) => {
      const stateProperties = {};
      const propKeys = ['ExclusionsandLimitations', 'MededHeader', 'Disclaimer', 'DisclaimerStep_1', 'DisclaimerStep_4', 'DisclaimerStep_5', 'DisclaimerStep_6', 'DisclaimerStep_7', 'CmsCodetext'];

      if (stateContent?.entities?.length > 0) {
        for (const entry of stateContent.entities) {
          const elements = entry.properties.elements;

          for (const key of Object.keys(elements)) {
            if (propKeys.indexOf(key) > -1) {
              const prop = elements[key];
              const variations = { master: prop.value, disable: elements.disable.value };

              for (const vkey of Object.keys(prop.variations)) {
                const states = elements.states.variations[vkey]?.value?.filter(val => val.indexOf('Location:') > -1).map(loc => loc.replace('Location:', ''));
                const plans =  elements.states.variations[vkey]?.value?.filter(val => val.indexOf('landrover:medsupp_plan/plan-') > -1).map(plan => plan.replace('landrover:medsupp_plan/plan-', '').toUpperCase());
                const stateValue =   {value: prop.variations[vkey].value, disable: elements.disable.variations[vkey].value };

                states.forEach(state => {
                  if (!variations[state] && plans?.length === 0) {
                    Object.assign(variations, {[state]: stateValue});
                  }
                  if (plans) {
                    plans.forEach(plan => {
                      Object.assign(variations, {[state + '-' + plan]: stateValue});
                    });
                  }
                });
              }
              Object.assign(stateProperties, {[key]: variations});
            }
          }
        }
      }
      this.profilePage.stateSpecificProps = stateProperties;

    }, (error) => {
      console.log('Some Error occurred while fetching AEM State Specific content.');
      console.log(error);
    });
  }

  @HostListener('mousemove') onMouseMove() {
    if (!this.showModalFlag) { this.idleTime = 0; }
  }
  @HostListener('keypress') onKeyPress() {
    if (!this.showModalFlag) { this.idleTime = 0; }
  }

  initializeIdleInterval(): any {
    const thiz = this;
    this.idleInterval = setInterval( () => {
      thiz.idleTime++;
      this.showModalFlag = thiz.idleTime > parseInt(this.profilePage.popupopentime, 10) ? true : false;
    }, 1000);
  }

  closeTimeoutPopUp(): any {
    this.idleTime = 0;
    this.showModalFlag = false;
  }

  isAuthenticatedUser() {
    return this.appData.profileDetails.userDetails && this.appData.profileDetails.userDetails.uuid;
  }

  getPlanYearData(year: number, event?: any) {
    if (event) {
      const selectedOption = { planYear: year };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption);
    }
    const uuid = this.cookieService.getUuidFromCookie();
    const deepLinkParams = this.storageService.getItem_SS(AppConstants.deeplinkParams);

    if (deepLinkParams) {
      this.appData.activeYear = JSON.parse(deepLinkParams).year ? JSON.parse(deepLinkParams).year : null;
      this.getProfileData(uuid, false);

    } else if (this.appData.activeYear !== year) {
      this.appData.activeYear = year;
      this.getProfileData(uuid, false);
    }
    this.storageService.setItem_LS(AppConstants.savedPlanYear, JSON.stringify(year));
  }

  setdgcUUID(uuid: string) {
    try {
      dgcUUID = uuid;
    } catch (e) {
      console.log('Some error occurred while setting dgcUUID');
    }
  }

  print(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Print Page', {}, TrackingConstants.eventType.ACTION);

    if (typeof controller !== 'undefined' && controller && controller.model && typeof(controller.model.visitorProfilePrint) === 'function') {
      controller.model.visitorProfilePrint();
    }
    window.print();
  }

  addPlans() {
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Add Plans - Goto VPP Page', {}, TrackingConstants.eventType.ACTION);

    this.providerService.setProvidersDataInBrowserStorage(this.appData);
    this.redirectToVPP();
  }

  redirectToVPP(): void {
    this.storageService.setItem_LS(AppConstants.dcActiveYear, '' + this.appData.activeYear);
    if (this.isCSRLogin) {
      this.messagingService.trackProfileItems('View Profile', 'viewProfile', this.appData);
    } else {
      this.utilityService.goToVppPage();
    }
  }

  isAEPPeriod(): boolean {
    if (this.appData.dceSystemDateTime) {
      const dceSystemMonth = this.appData.dceSystemDateTime.getMonth();
      return this.dateUtilService.isAEPPeriod(dceSystemMonth);
    }
    return false;
  }

  enableAgentMode(): void {
    this.storageService.removeItem_LS(AppConstants.providerKey, false);
    this.storageService.removeItem_LS(this.storageService.getItem_SS(AppConstants.geotrackingZip));
    this.storageService.removeItem_LS(this.storageService.getItem_SS(AppConstants.vppZipcode));

    this.storageService.removeItem_SS(AppConstants.vppZipcode);
    this.storageService.removeItem_SS(AppConstants.geotrackingZip);
    this.storageService.removeItem_SS(AppConstants.isProfileDataImported);
    this.userDataContextService.removeDrugStorage();

    this.cookieService.setCSRDcCookie(this.userDetails.uuid, false, true, true);
    this.appData.isWriteEnabledForCSR = true;

    $(this.brandNavElement).css({'pointer-events': 'auto'}).removeClass('cloak-in');
  }

  backToPlans(event?: any): void {
    if (event) {
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.LINK_CLICK);
    }
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Back to plans', {}, TrackingConstants.eventType.ACTION);

    this.storageService.setItem_LS(AppConstants.dcActiveYear, '' + this.appData.activeYear);

    this.dcePharmacyFlag = this.storageService.getItem_SS(AppConstants.prevPage);
    this.dceVisitorProfileFlag = this.storageService.getItem_SS(AppConstants.dceVisitorProfileFlag);

    if (this.dcePharmacyFlag.indexOf(URIConstants.aarpPharmacyPage) > -1) {
      location.href = this.dcePharmacyFlag;

    } else if (this.dceVisitorProfileFlag && (this.dceVisitorProfileFlag === 'dcePlanDetails' || this.dceVisitorProfileFlag === 'dcePlanSummary'
        || this.dceVisitorProfileFlag === 'dceGetStarted' || this.dceVisitorProfileFlag === 'dceBuildDrug' || this.dceVisitorProfileFlag === 'dceZipInformation')) {
       location.href = '/health-plans/estimate-drug-costs.html?dceProfile=true';

    } else {
      this.utilityService.goToVppPage();
    }
  }

  closeGuestAlertTip() {
    this.showGuestAlertTip = false;
  }

  isUserLoggedIn() {
    return this.userDetails && this.userDetails.firstName;
  }

  get isMedsuppPlansExists() {
    return this.appData?.medsuppPlansList?.length > 0;
  }

  get showLegacyUI() {
    return this.appData?.medsuppPlansList?.length > 0 && this.state && this.profilePage.excludedMedsuppStates?.indexOf(this.state) > -1;
  }

  deletePlan(planData: any): void {
    if (planData.plan.planType === 'MA' || planData.plan.planType === 'MAPD') {
      this.appData.maPlansList.splice(planData.index, 1);
    } else if (planData.plan.planType === 'PDP') {
      this.appData.pdpPlansList.splice(planData.index, 1);
    } else if (planData.plan.planType.indexOf('SNP') > -1) {
      this.appData.snpPlansList.splice(planData.index, 1);
    }

    const uuid = this.cookieService.getUuidFromCookie();

    setTimeout(() => {
      this.userinfoService.deleteProfileData(uuid, 'plans', planData.plan.planYear, planData.plan.planId).subscribe((response: any) => {
        console.log('Plan deleted successfully.');

        const planCode = planData.plan.planId + ' ' + planData.plan.planYear + ' ' + (planData.plan.planType === 'MAPD' ? 'MA' : planData.plan.planType);
        this.planService.deletePlanFromLocalStorage(this.appData.profileDetails.plansDetails.zipCode, planCode);
        this.rebuildPlansData();

      }, (error) => {
        console.log(error);
        this.reInsertPlanOnFailure(planData.index, planData.plan);
      });
    }, 500);
  }

  rebuildPlansData(buildMedsuppPlans = false) {
    const uuid = this.cookieService.getUuidFromCookie();

    this.userinfoService.getProfileData(uuid, 'plans', this.appData.activeYear.toString()).subscribe((data: UserProfile) => {
      this.appData.profileDetails.plansDetails = data?.plansDetails;

      if (buildMedsuppPlans) {
        this.userinfoService.getProfileData(uuid, 'medsuppPlans', this.appData.activeYear.toString()).subscribe((profileData: UserProfile) => {
          this.appData.profileDetails.medsuppData = profileData?.medsuppData;
          this.buildMedsuppPlansData();
          this.buildPlansData();

        }, (error1) => {
          console.log('Some error occurred while fetching medsupp plans data.');
          console.log(error1);
        });

      } else {
        this.buildPlansData();
      }

    }, (error) => {
      console.log('Some error occurred while fetching plans data.');
      console.log(error);
    });
  }

  reInsertPlanOnFailure(index: number, plan: Plan): void {
    if (plan.planType === 'MA' || plan.planType === 'MAPD') {
      this.appData.maPlansList.splice(index, 0, plan);
    } else if (plan.planType === 'PDP') {
      this.appData.pdpPlansList.splice(index, 0, plan);
    } else if (plan.planType && plan.planType.indexOf('SNP') > -1) {
      this.appData.snpPlansList.splice(index, 0, plan);
    }
  }

  comparePlans(type: string, event: Event): any {
    if (event) {
      const selectedOption = { planType: type };
      this.dataLayerService.setDLClickEvent(event, DL_EVENT_TYPE.BUTTON_CLICK, selectedOption);
    }
    let plans: Plan[];
    if (type === 'ma') {
      let maplans = [];

      if (this.appData?.maPlansList?.length > 1) {
        maplans = this.appData.maPlansList.filter(p => this.profilePage?.excludedAcquiredPlans?.indexOf(p.planId) === -1);
      }

      if (maplans?.length <= 1) {
        this.dtmService.setDTMData({visitorProfile: {comparemsg: 'Save at least two Medicare Advantage Plans to compare'}});
        this.onlyOneMaPlan = true;
        return;

      } else {
        plans = maplans;
      }

    } else if (type === 'pdp') {
      if (this.appData?.pdpPlansList?.length <= 1) {
        this.dtmService.setDTMData({visitorProfile: {comparemsg: 'Save at least two Prescription Drug Plans to compare'}});
        this.onlyOnePdpPlan = true;
        return;

      } else {
        plans = this.appData.pdpPlansList;
      }

    } else if (type === 'snp') {
      const dsnpPlansList = this.appData?.snpPlansList?.filter(p => {
        const plan = this.appData?.planSearchResultsList?.find(s => p.planId === s.planId && s.snpType === 'Dual - Eligible');
        return plan ? true : false;
      });

      if (dsnpPlansList?.length > 1) {
        plans = dsnpPlansList;

      } else {
        this.dtmService.setDTMData({visitorProfile: {comparemsg: 'Save at least two Special Needs Plans to compare'}});
        this.onlyOneDsnpPlan = true;
        return;
      }

    } else {
      return;
    }
    const planType = ((plans[0].planType).indexOf('MA') > -1 ? 'MA' : plans[0].planType).toLowerCase();

    this.storageService.setItem_LS(AppConstants.dcActiveYear, '' + this.appData.activeYear);

    const trackingData = { plans: plans?.map(p => p.planName), planType };
    this.trackingService.track(TrackingConstants.infoType.USER_ACTION, 'Compare Plans', trackingData, TrackingConstants.eventType.ACTION);

    const params = `?plans=${plans.map(p => p.planId).join()}&profile=true&product=${planType}&activeYear=${this.appData.activeYear}`;
    this.utilityService.goToVppPage(params);
  }

  closeNotification() {
    this.showNotification = false;
  }

  showStatePropertyContent(key: string) {
    return this.isMedsuppPlansExists
      && this.profilePage.stateSpecificProps
      && this.profilePage.stateSpecificProps[key]
      && !this.profilePage.stateSpecificProps[key].disable
      && !(this.state in this.profilePage.stateSpecificProps[key] && this.profilePage.stateSpecificProps[key][this.state].disable);
  }

  statePropertyContent(key: string) {
    let content = '';

    if (this.profilePage.stateSpecificProps && key in this.profilePage.stateSpecificProps) {
      if (this.state in this.profilePage.stateSpecificProps[key]) {
        content = this.profilePage.stateSpecificProps[key][this.state].value;
      } else {
        content = this.profilePage.stateSpecificProps[key].master;
      }
    }

    if (content?.indexOf('#">{{tfn}}') > -1) {
      content = content.replace('#">{{tfn}}', 'tel:' + this.tollFreeNumber + '">' + this.tollFreeNumber);
    }
    return content;
  }

  showDisclaimerPropertyContent(key: string) {
    const hide = 'display: none !important';

    if (this.isMedsuppPlansExists && ($('#vppResDisclaimer').is(':visible'))) {
      $('.globalfooternav .componentcodeForVP').attr('style', hide);
      $('#vppResDisclaimer').attr('style', hide);
    }

    return this.isMedsuppPlansExists
      && this.profilePage.stateSpecificProps
      && this.profilePage.stateSpecificProps[key]
      && !this.profilePage.stateSpecificProps[key].disable
      && !(this.state in this.profilePage.stateSpecificProps[key] && this.profilePage.stateSpecificProps[key][this.state].disable);
  }

  stateDisclaimerPropertyContent(key: string) {
    if (this.profilePage.stateSpecificProps && key in this.profilePage.stateSpecificProps) {
      const plankeys = this.appData?.medsuppPlansList?.map(plan => this.state + '-' + plan.planCode);
      const planContent = plankeys?.find(plankey => plankey in this.profilePage.stateSpecificProps[key]);

      if (planContent) {
        return this.profilePage.stateSpecificProps[key][planContent].value;

      } else if (this.state in this.profilePage.stateSpecificProps[key]) {
        return this.profilePage.stateSpecificProps[key][this.state].value;

      } else {
        return this.profilePage.stateSpecificProps[key].master;
      }
    }
  }

  setDataImportPopupContent(): void {
    this.contentService.getShopperDataImportContent().subscribe((profileContent: any) => {
      const properties = {};

      if (profileContent?.entities?.length > 0) {
        for (const entity of profileContent.entities) {
          const elements = entity.properties.elements;

          if (elements) {
            for (const key of Object.keys(elements)) {
              Object.assign(properties, {[key]: elements[key]?.value});
            }
          }
        }
      }
      this.appContent = new AppContent(properties);

      if (this.lazyDataImportComponent && this.lazyDataImportComponent.instance) {
        console.log('Setting lazyDataImportComponent content after it has been initialized.');
        this.lazyDataImportComponent.instance.appContent = this.appContent;
      }

    }, (error: any) => {
      console.log('Some Error occurred while fetching Data Import Popup AEM Authorable content.');
      console.log(error);
    });
  }

  importShopperData() {
    console.log('Received request to import shopper data');

    if (!this.document.getElementById('data-import-popup')) {
      const shopperDetails = {
        firstName : this.appData?.profileDetails?.userDetails?.firstName,
        lastName  : this.appData?.profileDetails?.userDetails?.lastName,
        activeYear: this.appData?.activeYear
      };
      this.lazyLoadDataImportPopup(shopperDetails);

    } else if (this.lazyDataImportComponent) {
      this.lazyDataImportComponent.instance.showPopup = true;
    }
  }

  async lazyLoadDataImportPopup(shopperDetails: any) {
    console.log('Data Import popup loading in progress...');
    this.dataImportContainerRef?.clear();

    const { DataImportPopupComponent } = await import('./lazy-load/data-import-popup/data-import-popup.component');
    const factory = this.componentFactoryResolver.resolveComponentFactory(DataImportPopupComponent);

    this.lazyDataImportComponent = this.dataImportContainerRef?.createComponent(factory);

    if (this.lazyDataImportComponent && this.lazyDataImportComponent.instance) {
      this.lazyDataImportComponent.instance.page = AppConstants.landroverPage;
      this.lazyDataImportComponent.instance.appContent = this.appContent;
      this.lazyDataImportComponent.instance.shopperDetails = shopperDetails;
      this.lazyDataImportComponent.instance.tollFreeNumber = this.tfnService.getAuthorTFN();

      this.lazyDataImportComponent.instance.displayLoader.subscribe((showDataImportLoader: boolean) => {
        this.showDataImportLoader = showDataImportLoader;
      }, (error: any) => {
        console.log('Error occurred while checking loader display');
      });

      this.lazyDataImportComponent.instance.dataImportCallback.subscribe((callbackData: boolean) => {
        this.dataImportCallback(callbackData);
      }, (error: any) => {
        console.log('Error occurred while calling dataImportCallback()');
      });
    }

    console.log('Data Import popup loaded successfully.');
  }

  dataImportCallback(data: any): void {
    console.log(data);

    this.isProfileDataImported = true;
    this.storageService.setItem_SS(AppConstants.isProfileDataImported, AppConstants.TRUE_VALUE);

    if (data?.success) {
      console.log('Landrover data Import completed successfully');

      this.notify(this.profilePage.Success, this.profilePage.importSuccess);
      this.getProfileData(this.cookieService.getUuidFromCookie(), false);

    } else {
      console.log('!! Landrover data Import unsuccessful !!');
    }
  }

  notify(type: string, content: string): void {
    this.notificationType = type;
    this.notificationContent = content;

    this.showNotification = true;
    this.showImportTip = true;
    this.utilityService.trackData('VP_ImportSuccess');

    this.showImportTipForPlanId = this.planService.getFederalPlans(this.appData)?.[0]?.planId;
  }
}
