import { NgModule } from '@angular/core';
import { DecimalPipe, CurrencyPipe } from '@angular/common';

import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { SafePipe } from './pipes/safe.pipe';
import { Digit } from './pipes/digit.pipe';

import { AppComponent } from './app.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardHeaderComponent } from './components/dashboard-header/dashboard-header.component';
import { AlertTipComponent } from './components/alert-tip/alert-tip.component';
import { EnrollmentsComponent } from './components/enrollments/enrollments.component';
import { MedsuppPlanComponent } from './components/medsupp-plan/medsupp-plan.component';
import { AddPlansComponent } from './components/add-plans/add-plans.component';
import { DrugsProvidersComponent } from './components/drugs-providers/drugs-providers.component';
import { DrugsComponent } from './components/drugs/drugs.component';
import { ProvidersComponent } from './components/providers/providers.component';
import { PlanRecommendationComponent } from './components/plan-recommendation/plan-recommendation.component';
import { DashboardFooterComponent } from './components/dashboard-footer/dashboard-footer.component';
import { AuthGuardService as AuthGuard } from './services/authguard.service';
import { PlanComponent } from './components/plan/plan.component';
import { LoaderComponent } from './components/loader/loader.component';
import { TimeoutPopupComponent } from './components/timeout-popup/timeout-popup.component';
import { RemoveEnrollPopupComponent } from './components/remove-enroll-popup/remove-enroll-popup.component';
import { PlanDrugProviderPopupComponent } from './components/plan-drug-provider-popup/plan-drug-provider-popup.component';
import { PopoverComponent } from './components/popover/popover.component';
import { LegacyPlanComponent } from './components//legacy/legacy-plan/legacy-plan.component';
import { LegacyPlanDrugsComponent } from './components/legacy/legacy-plan-drugs/legacy-plan-drugs.component';
import { LegacyPlanProvidersComponent } from './components/legacy/legacy-plan-providers/legacy-plan-providers.component';
import { LegacyLisPopupComponent } from './components/legacy/legacy-lis-popup/legacy-lis-popup.component';
import { LegacyAddPlansComponent } from './components/legacy/legacy-add-plans/legacy-add-plans.component';
import { LegacyDrugsComponent } from './components/legacy/legacy-drugs/legacy-drugs.component';
import { LegacyProvidersComponent } from './components/legacy/legacy-providers/legacy-providers.component';
import { LegacyDrugsProvidersComponent } from './components/legacy/legacy-drugs-providers/legacy-drugs-providers.component';
import { LegacyDashboardHeaderComponent } from './components/legacy/legacy-dashboard-header/legacy-dashboard-header.component';
import { NotificationComponent } from './components/notification/notification.component';
import { DataImportLoaderComponent } from './components/data-import-loader/data-import-loader.component';

@NgModule({
  declarations: [
    AppComponent,
    SafePipe,
    Digit,
    DashboardComponent,
    DashboardHeaderComponent,
    AlertTipComponent,
    EnrollmentsComponent,
    MedsuppPlanComponent,
    AddPlansComponent,
    PlanComponent,
    DrugsProvidersComponent,
    DrugsComponent,
    ProvidersComponent,
    PlanRecommendationComponent,
    DashboardFooterComponent,
    LoaderComponent,
    TimeoutPopupComponent,
    RemoveEnrollPopupComponent,
    PlanDrugProviderPopupComponent,
    PopoverComponent,
    LegacyAddPlansComponent,
    LegacyPlanComponent,
    LegacyPlanProvidersComponent,
    LegacyPlanDrugsComponent,
    LegacyLisPopupComponent,
    LegacyDrugsComponent,
    LegacyProvidersComponent,
    LegacyDrugsProvidersComponent,
    LegacyDashboardHeaderComponent,
    NotificationComponent,
    DataImportLoaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    AuthGuard,
    DecimalPipe,
    CurrencyPipe
  ],
  bootstrap: [
    AppComponent
  ]
})
export class AppModule { }
