import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ReplaySubject, Observable, forkJoin } from 'rxjs';

import { DTMService } from './dtm.service';
import { CookieService } from './cookie.service';
import { StorageService } from './storage.service';
import { LocationService } from './location.service';
import { UserDataContextService } from './user-data-context.service';

import { Drug } from '../models/Drug';
import { Plan } from '../models/Plan';
import { County } from '../models/County';
import { AppData } from '../models/AppData';
import { PlanService } from './plan.service';
import { Pharmacy } from '../models/Pharmacy';
import { PlansBenefit } from '../models/PlanBenefit';
import { DCELaunchData } from '../models/DCELaunchData';
import { AppConstants } from '../constants/app-constants';
import { DCEConstants } from '../constants/dce-constants';

declare var setFlyoutContents: any;

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'
  })
};

@Injectable({
  providedIn: 'root'
})
export class DrugsAndPharmacyService {

  private drugsDataLoading = new ReplaySubject(2);
  private pharmacyDataLoading = new ReplaySubject(2);

  siteId: string;

  constructor(
    private readonly http: HttpClient,
    private readonly dtmService: DTMService,
    private readonly locationService: LocationService,
    private readonly planService: PlanService,
    private readonly cookieService: CookieService,
    private readonly storageService: StorageService,
    private readonly userDataContextService: UserDataContextService
  ) {
    this.siteId = location.href.indexOf(AppConstants.aarpmedicareplans) > -1 ? AppConstants.aarp : AppConstants.uhc;
  }

  getDrugsDataLoadingNotification(): Observable<any> {
    return this.drugsDataLoading.asObservable();
  }

  getPharmacyDataLoadingNotification(): Observable<any> {
    return this.pharmacyDataLoading.asObservable();
  }

  resetPharmacyDataLoadingSubject(): void {
    this.pharmacyDataLoading = new ReplaySubject(2);
  }

  deleteDrugsFromBrowserStorage(drug: Drug): void {
    try {
      const drugStorageData = this.userDataContextService.getDrugStorageData();

      if (drugStorageData?.drugs?.length > 0) {
        drugStorageData.drugs = drugStorageData.drugs.filter((d: any) => d.proxyNdcCode !== drug.nationalDrugCode);
        this.userDataContextService.setDrugStorageData(drugStorageData);
      }

    } catch (e) {
      console.log('Some error occurred while deleting drug from browser storage.');
    }
  }

  transformStorageToDBDrug(storageDrug: any): Drug {
    return {
      isGeneric           : storageDrug.isGeneric,
      drugId              : storageDrug.drugId,
      nationalDrugCode    : storageDrug.proxyNdcCode,
      drugName            : storageDrug.brandName,
      drugDosage          : storageDrug.dosageStrength,
      drugQuantity        : storageDrug.quantity,
      drugFrequency       : storageDrug.frequency,
      drugSupplyLength    : storageDrug.supplyLength,
      drugPackageName     : storageDrug.packageName,
      drugPackageSize     : storageDrug.packageSize,
      drugPackageQuantity : storageDrug.packageQuantity
    };
  }

  getDrugsAndPharmacyMergedData(appData: AppData): any {
    try {
      const storageDrugsAndPharmacyData = this.userDataContextService.getDrugStorageData();

      if (storageDrugsAndPharmacyData) {
        const drugsAndPharmacyDetails = {
          drugInfoDetails : [],
          pharmacyObj: {}
        };

        if (storageDrugsAndPharmacyData?.drugs?.length > 0) {

          if (this.isDrugsDataExists(appData)) {
            /* Find Storage Drugs which are not present in DB, then transform into DB drugs structure. */
            drugsAndPharmacyDetails.drugInfoDetails = storageDrugsAndPharmacyData.drugs.filter((storageDrug: any) =>
              !appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.find((dbDrug: any) => storageDrug.proxyNdcCode === dbDrug.nationalDrugCode)
            ).map((storageDrug: any) => this.transformStorageToDBDrug(storageDrug));

            /* If DB drugs exists then merge them into Storage Drugs found in previous step */
            if (drugsAndPharmacyDetails.drugInfoDetails.length > 0) {
              drugsAndPharmacyDetails.drugInfoDetails =  drugsAndPharmacyDetails.drugInfoDetails.concat(appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails);
            } else {
              return null;
            }

          } else {
            /* If only Storage Drugs found, then transform into DB drugs structure. */
            drugsAndPharmacyDetails.drugInfoDetails = storageDrugsAndPharmacyData.drugs.map((drug: any) => this.transformStorageToDBDrug(drug));
          }

          /* If pharmacy info found in storage, then inject it into DB object. */
          if (storageDrugsAndPharmacyData?.pharmacy?.pharmacyNumber) {
            drugsAndPharmacyDetails.pharmacyObj = {
              pharmacyNumber  : storageDrugsAndPharmacyData.pharmacy.pharmacyNumber,
              mailOrder       : storageDrugsAndPharmacyData.pharmacy.mailOrder
            };
          }
        }

        return drugsAndPharmacyDetails;
      }

      return null;

    } catch (e) {
      console.log('Some error occurred while merging Browser Storage - DB drugs and pharmacy data');
      return null;
    }
  }

  getZipCodeFromPlansDetails(appData: AppData): string {
    if (appData.profileDetails.plansDetails) {
      return appData.profileDetails.plansDetails.zipCode;
    } else {
      return '';
    }
  }

  isDrugsDataExists(appData: AppData): boolean {
    return appData
      && appData.profileDetails
      && appData.profileDetails.drugsAndPharmacyDetails
      && appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails
      && appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length > 0;
  }

  updateDrugInfo(drug: Drug) {
    if (drug) {

      /* If Supply Length exists */
      if (drug.drugQuantity && drug.drugSupplyLength) {

        /* If Supply Length value is invalid then set it to '30' */
        if (AppConstants.DRUG_SUPPLY_LENGTHS.indexOf(drug.drugSupplyLength.trim().toLowerCase()) === -1) {
          drug.drugSupplyLength = '30';
        }

        /* If Frequency has valid value (i.e. Day, Week, Month) */
        if (drug.drugFrequency && AppConstants.DRUG_FREQUENCIES.indexOf(drug.drugFrequency.trim().toLowerCase()) > -1) {
          const drugFrequency = drug.drugFrequency.trim().toLowerCase();
          let drugSupplyLength = drug.drugSupplyLength.trim().toLowerCase();

          if (drugSupplyLength === '90') {
            drugSupplyLength = AppConstants.EVERY_3_MONTHS.toLowerCase();
          } else if (drugSupplyLength === '30') {
            drugSupplyLength = AppConstants.EVERY_1_MONTH.toLowerCase();
          }

          drug.refillText = drug.drugQuantity + ' per ' + drugFrequency + ', refill ' + drugSupplyLength;

          /* Create Legacy Refill Text */
          let legacyDrugSupplyLength = drug.drugSupplyLength;

          if (legacyDrugSupplyLength === '90') {
            legacyDrugSupplyLength = AppConstants.EVERY_3_MONTHS;
          } else if (legacyDrugSupplyLength === '30') {
            legacyDrugSupplyLength = AppConstants.EVERY_1_MONTH;
          }

          drug.legacyRefillText = 'Qty ' + drug.drugQuantity + ' ' + legacyDrugSupplyLength;

        /* If Frequency has invalid value */
        } else {
          let legacyDrugSupplyLength = drug.drugSupplyLength;

          if (legacyDrugSupplyLength === '90') {
            legacyDrugSupplyLength = AppConstants.EVERY_3_MONTHS;
          } else if (legacyDrugSupplyLength === '30') {
            legacyDrugSupplyLength = AppConstants.EVERY_1_MONTH;
          }

          drug.refillText = 'Qty ' + drug.drugQuantity + ' ' + legacyDrugSupplyLength;
          drug.legacyRefillText = drug.refillText;
        }

      /* If Supply Length doesn't exists */
      } else if (drug.drugQuantity && drug.drugFrequency) {
        /* If frequency value is invalid then set it to '30' */
        if (AppConstants.DRUG_SUPPLY_LENGTHS.indexOf(drug.drugFrequency.trim().toLowerCase()) === -1) {
          drug.drugFrequency = '30';
        }

        let drugFrequency = drug.drugFrequency;

        if (drugFrequency === '90') {
          drugFrequency = AppConstants.EVERY_3_MONTHS;
        } else if (drugFrequency === '30') {
          drugFrequency = AppConstants.EVERY_1_MONTH;
        }

        drug.refillText = 'Qty ' + drug.drugQuantity + ' ' + drugFrequency;

        /* Create Legacy Refill Text */
        drug.legacyRefillText = drug.refillText;

      } else {
        console.error('Invalid drug data found');
        console.log(drug);
      }
    }
    return drug;
  }

  setDrugsAndPharmacyDetails(appData: AppData, drugsAndPharmacyDataExists: boolean): any {
    this.resetPharmacyDataLoadingSubject();
    const currentYear = appData.activeYear.toString();

    if (this.isDrugsDataExists(appData)) {
      drugsAndPharmacyDataExists = true;

      const drugsNdcList = appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.map(d => d.nationalDrugCode).join('|');
      this.dtmService.setDTMData({visitorProfile: {drugs: drugsNdcList}});

      appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.forEach(this.updateDrugInfo);

      if (appData.profileDetails.drugsAndPharmacyDetails?.pharmacyObj?.pharmacyNumber) {
        this.searchPharmacy(this.createSearchPharmacyObject(appData, '90210', currentYear)).subscribe(data => {
          if (data.data) {
            const pharmacyInfo = this.getPharmacyInfo(data.data, appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.pharmacyNumber);

            if (this.isRetailChainPharmacy(pharmacyInfo?.pharmacyNumber)) {
              pharmacyInfo.pharmacyName = AppConstants.retailChainPharmacy;
            } else if (this.isPreferredMailServicePharmacy(pharmacyInfo?.pharmacyNumber)) {
              pharmacyInfo.pharmacyName = AppConstants.optumRxMailServicePharmacy;
            }

            appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.pharmacyName = pharmacyInfo?.pharmacyName || null;
            appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.pharmacyAddress = pharmacyInfo?.pharmacyAddress || null;
            appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.mailOrder = pharmacyInfo?.mailOrder || false;

            this.pharmacyDataLoading.next({dataLoadComplete: true});

            this.updateDrugStorageData(this.getZipCodeFromPlansDetails(appData), appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails, pharmacyInfo, currentYear);

          } else {
            console.log('No data found from Pharmacy Search call');
            this.pharmacyDataLoading.next({dataLoadComplete: true});
            this.drugsDataLoading.next({dataLoadComplete: true});
          }
        }, (error) => {
          console.log('Some error occurred while fetching pharmacy details by pharmacyNumber');
          this.pharmacyDataLoading.next({dataLoadComplete: true});
          this.drugsDataLoading.next({dataLoadComplete: true});
        });

      } else {
        this.pharmacyDataLoading.next({dataLoadComplete: true});
        this.updateDrugStorageData(this.getZipCodeFromPlansDetails(appData), appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails, null, currentYear);
      }

      if (!appData.plansDataExists && typeof setFlyoutContents === 'function') {
        setFlyoutContents(true);
      }

    } else {
      this.pharmacyDataLoading.next({dataLoadComplete: true});
      drugsAndPharmacyDataExists = false;

      if (!appData.plansDataExists && appData.providersDataExists && typeof setFlyoutContents === 'function') {
        setFlyoutContents(true);
      } else if (!appData.plansDataExists && !appData.providersDataExists && !appData.medSuppPlansDataExists && typeof setFlyoutContents === 'function') {
        setFlyoutContents(false);
      }
      this.dtmService.setDTMData({visitorProfile: {drugs: ''}});
    }

    return {appData, drugsAndPharmacyDataExists};
  }

  getPharmacyInfo(pharmacies: any, pharmacyNumber: any): any {
    let pharmacyObj = null;

    if (pharmacies?.pharmacyList?.length > 0) {
      pharmacies.pharmacyList.forEach((pharmacy: any) => {
        if (pharmacy.pharmacyNumber === pharmacyNumber) {
          pharmacyObj = {
            pharmacyName      : pharmacy.pharmacyName,
            pharmacyNumber    : pharmacy.pharmacyNumber,
            mailOrder         : pharmacy.mailOrder,
            pharmacySaver     : pharmacy.pharmacySaver,
            preferredNetwork  : pharmacy.preferredNetwork,
            pharmacyAddress   : pharmacy.pharmacyAddress
          };
        }
      });
    }
    return pharmacyObj;
  }

  isRetailChainPharmacy(pharmacyNumber: string) {
    const isRetailPharmacy = this.storageService.getItem_LS(AppConstants.isRetailPharmacy);

    return (isRetailPharmacy === undefined || isRetailPharmacy === null || isRetailPharmacy === AppConstants.TRUE_VALUE)
      && pharmacyNumber === AppConstants.retailChainPharmacyNo;
  }

  isPreferredMailServicePharmacy(pharmacyNumber: string) {
    return pharmacyNumber === AppConstants.preferredMailServicePharmacyNo;
  }

  updateStorageDrugInfo(drug: Drug) {
    let modifiedDrugData;

    if (drug) {
      modifiedDrugData = {
        drugId              : drug.drugId,
        isGeneric           : drug.isGeneric,
        drugName            : drug.drugName,
        drugDosage          : drug.drugDosage,
        drugQuantity        : drug.drugQuantity,
        drugFrequency       : drug.drugFrequency,
        drugSupplyLength    : drug.drugSupplyLength,
        nationalDrugCode    : drug.nationalDrugCode,
        drugPackageName     : drug.drugPackageName,
        drugPackageSize     : drug.drugPackageSize,
        drugPackageQuantity : drug.drugPackageQuantity
      };

      if (modifiedDrugData.drugSupplyLength) {
        if (modifiedDrugData.drugSupplyLength === '90') {
          modifiedDrugData.drugSupplyLength = AppConstants.EVERY_3_MONTHS;
        } else if (modifiedDrugData.drugSupplyLength === '30') {
          modifiedDrugData.drugSupplyLength = AppConstants.EVERY_1_MONTH;
        }

        if (!modifiedDrugData.drugFrequency || AppConstants.DRUG_FREQUENCIES.indexOf(modifiedDrugData.drugFrequency?.trim().toLowerCase()) === -1) {
          modifiedDrugData.drugFrequency = null;
        }

      } else {
        if (modifiedDrugData.drugFrequency === '90' || modifiedDrugData.drugFrequency?.trim().toLowerCase() === AppConstants.EVERY_3_MONTHS.toLowerCase()) {
          modifiedDrugData.drugSupplyLength = AppConstants.EVERY_3_MONTHS;
        } else {
          modifiedDrugData.drugSupplyLength = AppConstants.EVERY_1_MONTH;
        }
        modifiedDrugData.drugFrequency = null;
      }
    }
    return modifiedDrugData;
  }

  updateDrugStorageData(zipCode: string, drugsData: Drug[], pharmacyData: Pharmacy, currentYear: string): void {
    try {
      const drugsAndPharmacyData: any = {
        zipCode,
        pharmacy: {}
      };

      if (pharmacyData) {
        drugsAndPharmacyData.pharmacy = pharmacyData;
      }

      const generic_drugs = drugsData.filter(drug => drug.isGeneric);
      const non_generic_drugs = drugsData.filter(drug => !drug.isGeneric);

      const drugsInfoSearchRequest: any = { isDCProfileDrugsFlow : true };
      const isGenericDrugsExists: boolean = generic_drugs && generic_drugs.length > 0;
      const isNonGenericDrugsExists: boolean = non_generic_drugs && non_generic_drugs.length > 0;

      if (isNonGenericDrugsExists) {
        drugsInfoSearchRequest.drugs = non_generic_drugs.map(drug => ({
          ndc: drug.nationalDrugCode,
          drugName: drug.drugName,
          drugGenericNameAndDosage: drug.drugDosage
        }));
      }

      this.getDrugsDetails(drugsInfoSearchRequest, generic_drugs, currentYear).subscribe(drugDetailsResponses => {
        // console.log('Drugs Detail Responses -->');
        // console.log(drugDetailsResponses);

        let generic_drugs_data = [];
        let non_generic_drugs_data = [];

        if (isNonGenericDrugsExists) {
          const non_generic_drugs_details = drugDetailsResponses[0];

          if (non_generic_drugs_details && non_generic_drugs_details.drugs && non_generic_drugs_details.drugs.length > 0) {

            non_generic_drugs_data = non_generic_drugs.map(this.updateStorageDrugInfo).map((drug: any) => {
              const drugInfo = non_generic_drugs_details.drugs.find(d => d.ndc === drug.nationalDrugCode && d.dosageName === drug.drugDosage);

              const drugData: any = {
                isGeneric           : drug.isGeneric,
                brandName           : drug.drugName,
                dosageStrength      : drug.drugDosage,
                drugId              : drugInfo?.drugId,
                dosageID            : drugInfo?.dosageId,
                frequency           : drug.drugFrequency,
                supplyLength        : drug.drugSupplyLength,
                quantity            : drug.drugQuantity,
                proxyNdcCode        : drug.nationalDrugCode,
                packageName         : drug.drugPackageName,
                packageQuantity     : drug.drugPackageQuantity,
                packageSize         : drug.drugPackageSize,
                drugType            : null,
                drugDescriptionType : null,
                ariaid              : null,
                genericDrugId       : null,
                genericndcCode      : null,
                genericDrugName     : null,
                genericDosageID     : null,
                genericDosageName   : null
              };

              return drugData;
            });

          } else {
            console.log('No details found for Non-Generic Drugs');
          }
        }

        if (isGenericDrugsExists) {
          let index = isNonGenericDrugsExists ? 1 : 0;

          generic_drugs_data = generic_drugs.map(this.updateStorageDrugInfo).map((drug: any) => {
            const drugData: any = {
              isGeneric           : drug.isGeneric,
              brandName           : drug.drugName,
              dosageStrength      : drug.drugDosage,
              drugId              : drug.drugId,
              dosageID            : null,
              frequency           : drug.drugFrequency,
              supplyLength        : drug.drugSupplyLength,
              quantity            : drug.drugQuantity,
              proxyNdcCode        : drug.nationalDrugCode,
              packageName         : drug.drugPackageName,
              packageQuantity     : drug.drugPackageQuantity,
              packageSize         : drug.drugPackageSize,
              drugType            : null,
              drugDescriptionType : null,
              ariaid              : null,
              genericDrugId       : null,
              genericndcCode      : null,
              genericDrugName     : null,
              genericDosageID     : null,
              genericDosageName   : null
            };

            if (drug.isGeneric && drugDetailsResponses[index].data) {
              const genericDrugInfo       = drugDetailsResponses[index].data;
              const drugDosageInfo        = genericDrugInfo.drugDosageInfoList[0];

              drugData.drugId             = genericDrugInfo.brandedDrugId;
              drugData.dosageID           = genericDrugInfo.brandedDrugDosageId;
              drugData.genericDrugId      = genericDrugInfo.drugId;
              drugData.genericndcCode     = drugDosageInfo?.nationalDrugCode;
              drugData.genericDrugName    = genericDrugInfo.drugName;
              drugData.genericDosageID    = drugDosageInfo?.dosageID;
              drugData.genericDosageName  = drugDosageInfo?.labelName;

              index++;
            }
            return drugData;
          });
        }

        drugsAndPharmacyData.drugs = [...non_generic_drugs_data, ...generic_drugs_data];

        this.userDataContextService.setDrugStorageData(drugsAndPharmacyData);
        this.drugsDataLoading.next({dataLoadComplete: true});

      }, (error) => {
        console.log('Some error occurred while fetching drug(s) details');
        console.log(error);
        this.drugsDataLoading.next({dataLoadComplete: true});
      });

    } catch (e) {
      console.log('Some error occurred while updating DCE DrugsAndPharmacy data in local storage.');
      console.log(e);
      this.drugsDataLoading.next({dataLoadComplete: true});
    }
  }

  getDrugsDetails(drugsInfoSearchRequest: any, genericDrugsData: Drug[], currentYear: string): Observable<any[]> {
    const serviceCalls: any = [];

    if (drugsInfoSearchRequest && drugsInfoSearchRequest.drugs && drugsInfoSearchRequest.drugs.length > 0) {
      serviceCalls.push(this.drugsInfoSearch(drugsInfoSearchRequest));
    }

    if (genericDrugsData && genericDrugsData.length > 0) {
      genericDrugsData.forEach(drug => {
        const genericDrugInfoModel = {
          drugDetails : {
            drugTypeId: 1,
            drugIndetifier: drug.nationalDrugCode,
            drugName: drug.drugName ? drug.drugName.toLowerCase() : drug.drugName
          },
          currentYear
        };
        serviceCalls.push(this.getGenericDrugInfo(genericDrugInfoModel));
      });
    }

    return forkJoin(serviceCalls);
  }

  getGenericDrugInfo(genericDrugInfoModel: any): Observable<any> {
    const genericDrugInfoURI = DCEConstants.drugInfoBaseURI + DCEConstants.genericDrugInfoURI
      + '/' + genericDrugInfoModel.drugDetails.drugTypeId + '/' + genericDrugInfoModel.drugDetails.drugIndetifier
      + '/' + genericDrugInfoModel.currentYear + '?drug=' + encodeURIComponent(genericDrugInfoModel.drugDetails.drugName);

    return this.http.get(genericDrugInfoURI);
  }

  drugsInfoSearch(requestData: any): Observable<any> {
    const url = DCEConstants.drugInfoBaseURI + DCEConstants.drugsInfoURI;
    return this.http.post<any>(url, requestData, httpOptions);
  }

  estimatePlanCosts(estimatePlanCostsRequestData: any): Observable<any> {
    const estimatePlanCostsURL = DCEConstants.drugPricingBaseURI + DCEConstants.estimatePlanCostsURI;
    return this.http.post<any>(estimatePlanCostsURL, estimatePlanCostsRequestData, httpOptions);
  }

  searchPharmacy(searchPharmacyRequestData: any): Observable<any> {
    const searchPharmacyURL = DCEConstants.pharmacySearchBaseURI + DCEConstants.searchPharmacyURI;
    return this.http.post<any>(searchPharmacyURL, searchPharmacyRequestData, httpOptions);
  }

  getTempPlanObject(zipCode: string, county: County, pharmacy: Pharmacy): any {
    return {
      planStartMonth : '01',
      zipCode,
      county : {
        fipsCountyCode : county.fipsCountyCode,
        fipsCountyName : county.fipsCountyName,
        fipsStateCode : county.fipsStateCode,
        stateCode : county.stateCode,
        cmsCountyCodes : county.cmsCountyCodes
      },
      brandId : location.href.indexOf(AppConstants.aarpmedicareplans) > -1 ? AppConstants.aarp : AppConstants.uhc,
      accumulatedTotalDrugCost : null,
      accumulatedTroopBalance : null,
      copayCategory : '0',
      plans: [],
      pharmacies : [{
          pharmacyNumber : pharmacy?.pharmacyNumber ? pharmacy.pharmacyNumber : null,
          mailOrder : pharmacy?.mailOrder ? pharmacy.mailOrder : null,
          pharmacySaver : pharmacy?.pharmacySaver ? pharmacy.pharmacySaver : null
        }
      ],
      drugs: []
    };
  }

  getEstimatePlanCostsData(appData: AppData): Observable<any[]> {
    const zipCode = appData.profileDetails.plansDetails.zipCode;
    const county = appData.profileDetails.plansDetails.plans[0].county;
    const pharmacy = appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj;

    const estimateMAPDPlanCost = JSON.parse(JSON.stringify(this.getTempPlanObject(zipCode, county, pharmacy)));
    const estimatePDPPlanCost = JSON.parse(JSON.stringify(this.getTempPlanObject(zipCode, county, pharmacy)));
    const estimateSNPPlanCost = JSON.parse(JSON.stringify(this.getTempPlanObject(zipCode, county, pharmacy)));

    appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.forEach((drug: Drug) => {
      let drugFrequency = drug.drugFrequency;
      let drugSupplyLength: any = drug.drugSupplyLength;

      if (drug.drugQuantity && drugSupplyLength) {
        drugSupplyLength = drugSupplyLength.trim().toLowerCase();

        if (drugFrequency && AppConstants.DRUG_FREQUENCIES.indexOf(drugFrequency.toLowerCase()) === -1) {
          drugFrequency = null;
        }

        if (drugSupplyLength === AppConstants.EVERY_3_MONTHS.toLowerCase()) {
          drugSupplyLength = '90';
        } else if (drugSupplyLength === AppConstants.EVERY_1_MONTH.toLowerCase()) {
          drugSupplyLength = '30';
        }

      } else if (drug.drugQuantity && drugFrequency) {
        drugFrequency = drugFrequency.trim().toLowerCase();

        if (drugFrequency === '90' || drugFrequency === AppConstants.EVERY_3_MONTHS.toLowerCase()) {
          drugSupplyLength = '90';
        } else if (drugFrequency === '30' || drugFrequency === AppConstants.EVERY_1_MONTH.toLowerCase()) {
          drugSupplyLength = '30';
        }

        drugFrequency = null;

      } else {
        console.log('Invalid Drug data');
        console.log(drug);
      }

      const tempDrugObject = {
        drugFrequency,
        drugSupplyLength,
        drugQuantity : drug.drugQuantity,
        packageQuantity : drug.drugPackageQuantity,
        nationalDrugCode : drug.nationalDrugCode,
        packageSize : drug.drugPackageSize
      };

      estimateMAPDPlanCost.drugs.push(tempDrugObject);
      estimatePDPPlanCost.drugs.push(tempDrugObject);
      estimateSNPPlanCost.drugs.push(tempDrugObject);
    });

    appData.maPlansList.forEach((plan: Plan) => {
      if (plan.planType === 'MAPD') {
        estimateMAPDPlanCost.plans.push({
          contractId: plan.planId.substring(0, 5),
          pbpNumber: plan.planId.substring(5, 8),
          segmentId: plan.planId.substring(8),
          planYear: plan.planYear
        });
      }
    });

    appData.pdpPlansList.forEach((plan: Plan) => {
      estimatePDPPlanCost.plans.push({
        contractId: plan.planId.substring(0, 5),
        pbpNumber: plan.planId.substring(5, 8),
        segmentId: plan.planId.substring(8),
        planYear: plan.planYear
      });
    });

    appData.snpPlansList.forEach((plan: Plan) => {
      estimateSNPPlanCost.plans.push({
        contractId: plan.planId.substring(0, 5),
        pbpNumber: plan.planId.substring(5, 8),
        segmentId: plan.planId.substring(8),
        planYear: plan.planYear
      });
    });

    const serviceCalls: any = [];

    if (appData.maPlansList.length > 0 && estimateMAPDPlanCost.plans.length > 0) {
      serviceCalls.push(this.estimatePlanCosts(estimateMAPDPlanCost));
    }
    if (appData.pdpPlansList.length > 0) {
      serviceCalls.push(this.estimatePlanCosts(estimatePDPPlanCost));
    }
    if (appData.snpPlansList.length > 0) {
      serviceCalls.push(this.estimatePlanCosts(estimateSNPPlanCost));
    }

    return forkJoin(serviceCalls);
  }

  getOutOfNetworkObject(plan: Plan, pharmacy: Pharmacy): any {
    return {
      profileInfo: null,
      pharmacySearchCriteria: {
        pharmacyAddress : {
          addressLine1 : null,
          addressLine2 : null,
          city : null,
          state : null,
          zipCode : plan.zipCode
        },
        radius : '25',
        pharmacyNumber: pharmacy?.pharmacyNumber ? pharmacy.pharmacyNumber : null,
        pharmacyNameFilter : null,
        filtersInclusive : true,
        pharmacySearchFilters : {
          twentyFourHourTypeFilter : null,
          ninetyDayTypeFilter : null,
          longTermCareTypeFilter : null,
          specialtyTypeFilter : null,
          retailTypeFilter : null,
          indianTribalUnionFilter : null,
          mailOrderTypeFilter : null,
          eprescriptionFilter : null,
          pharmacySaverFilter : null,
          preferredNetworkFilter : null
        },
        yearFilter : plan.planYear,
        paginationIndex : '1',
        maxRecordPerPage : '1',
        ndcFilter : null,
        compositePlanId : {
          groupInformation : null,
          planType: {
              name: plan.planType,
              category: 'Individual'
          },
          contractId: plan.planId.substring(0, 5),
          pbpNumber: plan.planId.substring(5, 8),
          planYear : plan.planYear,
          segmentId: plan.planId.substring(8)
        }
      }
    };
  }

  getSearchPharmacyData(appData: AppData): Observable<any[]> {
    const serviceCalls: any = [];
    const pharmacy = appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj;

    appData.maPlansList.forEach(plan => {
      if (plan.planType === 'MAPD') {
        serviceCalls.push(this.searchPharmacy(this.getOutOfNetworkObject(plan, pharmacy)));
      }
    });

    appData.pdpPlansList.forEach(plan => {
      serviceCalls.push(this.searchPharmacy(this.getOutOfNetworkObject(plan, pharmacy)));
    });

    appData.snpPlansList.forEach(plan => {
      serviceCalls.push(this.searchPharmacy(this.getOutOfNetworkObject(plan, pharmacy)));
    });

    return forkJoin(serviceCalls);
  }

  updatePlanDrugsData(appData: AppData): AppData {

    if (this.isDrugsDataExists(appData)) {
      console.log('Plan Drugs cost estimation started...');

      this.getEstimatePlanCostsData(appData).subscribe(estimatedCostArray => {

        this.getSearchPharmacyData(appData).subscribe(pharmacySearchArray => {
          const estimatedPlanCost = estimatedCostArray.concat(pharmacySearchArray);

          appData = this.processEstimatedPlanCost(appData, estimatedPlanCost);
          this.planService.setPlanBenefits(appData);

          console.log(appData);
          console.log('Plan Drugs cost estimation completed.');
        });
      });

      return appData;

    } else {
      return this.resetEstimatePlanCost(appData);
    }
  }

  resetEstimatePlanCost(appData: AppData): AppData {
    if (appData.maPlansList.length > 0) {
      appData.maPlansList.forEach((plan: Plan) => {
        plan.annualDrugCost = 0;
        plan.coveredDrugsCount = 0;
        plan.coveredDrugs = [];
        this.resetPlanEstimatedAnnualDrugCost(plan);
      });
    }

    if (appData.pdpPlansList.length > 0) {
      appData.pdpPlansList.forEach((plan: Plan) => {
        plan.annualDrugCost = 0;
        plan.coveredDrugsCount = 0;
        plan.coveredDrugs = [];
        this.resetPlanEstimatedAnnualDrugCost(plan);
      });
    }

    if (appData.snpPlansList.length > 0) {
      appData.snpPlansList.forEach((plan: Plan) => {
        plan.annualDrugCost = 0;
        plan.coveredDrugsCount = 0;
        plan.coveredDrugs = [];
        this.resetPlanEstimatedAnnualDrugCost(plan);
      });
    }

    return appData;
  }

  resetPlanEstimatedAnnualDrugCost(plan: Plan) {
    if (plan && plan.benefits && plan.benefits.length > 0) {
      plan.benefits = plan.benefits.filter((benefit: PlansBenefit) => benefit && benefit.label && benefit.label.indexOf(AppConstants.estimatedAnnualDrugCost) === -1);
    }
  }

  processEstimatedPlanCost(appData: AppData, estimatedPlanCost: any[]): AppData {
    const drugsAndPharmacyData = appData.profileDetails.drugsAndPharmacyDetails;
    const searchPharmacyResponse = [];

    estimatedPlanCost.forEach(cost => {
      if (cost?.data?.pharmacyList?.length > 1) {
        const networkVal = cost.data.pharmacyList[1].network;
        const saver = cost.data.pharmacyList[1].pharmacySaver;
        const preferred = cost.data.pharmacyList[1].preferredNetwork;
        let pharmaNetwork = false;

        if (networkVal === AppConstants.FALSE_VALUE || networkVal == null || networkVal === '') {
          pharmaNetwork = false;
          if (drugsAndPharmacyData && (drugsAndPharmacyData.pharmacyObj.mailOrder === true ||  drugsAndPharmacyData.pharmacyObj.mailOrder)) {
            pharmaNetwork = true;
          }
        } else {
          pharmaNetwork = true;
        }
        searchPharmacyResponse.push({outOfNetwork: pharmaNetwork, pharmacySaver: saver, preferredNetwork: preferred});

      } else if (cost?.data?.pharmacyList?.length === 1) {
        if (drugsAndPharmacyData?.pharmacyObj?.mailOrder) {
          searchPharmacyResponse.push({outOfNetwork: true});
        } else {
          searchPharmacyResponse.push({outOfNetwork: false});
        }
      }

    });

    estimatedPlanCost.forEach(cost => {
      if (cost && cost.data && cost.data !== '' && cost.data.plans) {
        cost.data.plans.forEach((plan: any) => {
          if (searchPharmacyResponse.length > 0) {
            plan.network = searchPharmacyResponse[0].outOfNetwork;
            plan.saver = searchPharmacyResponse[0].pharmacySaver;
            plan.preferred = searchPharmacyResponse[0].preferredNetwork;
            searchPharmacyResponse.splice(0, 1);
          }
        });
      }
    });

    estimatedPlanCost.forEach(cost => {
      if (cost && cost.data && cost.data !== '' && cost.data.plans) {

        cost.data.plans.forEach((plan: any) => {

          appData.maPlansList.forEach((maplan: Plan) => {
            const contractId = maplan.planId.substring(0, 5);
            const pbpNumber = maplan.planId.substring(5, 8);

            if (contractId === plan.compositePlanId.contractId && pbpNumber === plan.compositePlanId.pbpNumber) {
              const pharmacyDrugcosts = plan.pharmacyCosts[0];

              maplan.network = plan.network;
              maplan.annualDrugCost = pharmacyDrugcosts.planSummaryCost.totalDrugCost;

              let coveredDrugsCount = 0;
              maplan.coveredDrugs = [];
              maplan.costsDuringInitialCoveragePeriod = {};

              pharmacyDrugcosts.drugsCost.forEach((drugCost: any) => {
                if (drugCost.covered === true) {
                  coveredDrugsCount = parseInt(coveredDrugsCount.toString(), 10) + 1 ;
                  maplan.coveredDrugs.push(drugCost.nationalDrugCode);
                }
                maplan.costsDuringInitialCoveragePeriod[drugCost.nationalDrugCode] = drugCost.costDuringInitialCoveragePeriod ? drugCost.costDuringInitialCoveragePeriod : 0 ;
              });
              maplan.coveredDrugsCount = coveredDrugsCount;
            }
          });

          appData.pdpPlansList.forEach((pdpplan: Plan) => {
            const contractId = pdpplan.planId.substring(0, 5);
            const pbpNumber = pdpplan.planId.substring(5, 8);

            if (contractId === plan.compositePlanId.contractId && pbpNumber === plan.compositePlanId.pbpNumber) {
              const pharmacyDrugcosts = plan.pharmacyCosts[0];

              pdpplan.network = plan.network;
              pdpplan.annualDrugCost = pharmacyDrugcosts.planSummaryCost.totalDrugCost;

              let coveredDrugsCount = 0;
              pdpplan.coveredDrugs = [];
              pdpplan.costsDuringInitialCoveragePeriod = {};

              pharmacyDrugcosts.drugsCost.forEach((drugCost: any) => {
                if (drugCost.covered) {
                  coveredDrugsCount = parseInt(coveredDrugsCount.toString(), 10) + 1 ;
                  pdpplan.coveredDrugs.push(drugCost.nationalDrugCode);
                }
                pdpplan.costsDuringInitialCoveragePeriod[drugCost.nationalDrugCode] = drugCost.costDuringInitialCoveragePeriod ? drugCost.costDuringInitialCoveragePeriod : 0 ;
              });
              pdpplan.coveredDrugsCount = coveredDrugsCount;
            }
          });

          appData.snpPlansList.forEach((snpplan: Plan) => {
            const contractId = snpplan.planId.substring(0, 5);
            const pbpNumber = snpplan.planId.substring(5, 8);

            if (contractId === plan.compositePlanId.contractId && pbpNumber === plan.compositePlanId.pbpNumber) {
              const pharmacyDrugcosts = plan.pharmacyCosts[0];

              snpplan.network = plan.network;
              snpplan.annualDrugCost = pharmacyDrugcosts.planSummaryCost.totalDrugCost;

              let coveredDrugsCount = 0;
              snpplan.coveredDrugs = [];
              snpplan.costsDuringInitialCoveragePeriod = {};

              pharmacyDrugcosts.drugsCost.forEach((drugCost: any) => {
                if (drugCost.covered) {
                  coveredDrugsCount = parseInt(coveredDrugsCount.toString(), 10) + 1 ;
                  snpplan.coveredDrugs.push(drugCost.nationalDrugCode);
                }
                snpplan.costsDuringInitialCoveragePeriod[drugCost.nationalDrugCode] = drugCost.costDuringInitialCoveragePeriod ? drugCost.costDuringInitialCoveragePeriod : 0 ;
              });
              snpplan.coveredDrugsCount = coveredDrugsCount;
            }
          });
        });
      }

    });

    return appData;
  }

  createSearchPharmacyObject(appData: AppData, zipcode: string, year: string): any {
    return {
      profileInfo : {},
      pharmacySearchCriteria : {
        pharmacyAddress : {
          addressLine1 : null,
          addressLine2 : null,
          city : null,
          state : null,
          zipCode : zipcode,
          phoneNumber : null,
          tty : null
        },
        radius : '25',
        pharmacyNameFilter : null,
        filtersInclusive : true,
        pharmacySearchFilters : null,
        yearFilter : year,
        paginationIndex : null,
        maxRecordPerPage : null,
        ndcFilter : null,
        compositePlanId : null,
        pharmacyNumber : appData.profileDetails.drugsAndPharmacyDetails?.pharmacyObj?.pharmacyNumber
      }
    };
  }

  getDCELaunchData(plan: Plan, planSearchResultsList: any[]): DCELaunchData {
    try {
      const dceLaunchData = new DCELaunchData();

      dceLaunchData.planName = plan.planName;
      dceLaunchData.planType = plan.planType;
      dceLaunchData.vppView = 'planSummary';
      dceLaunchData.dceView = 'default';
      dceLaunchData.planId = plan.planId;
      dceLaunchData.zipCode = plan.zipCode;
      dceLaunchData.planYear = plan.planYear;
      dceLaunchData.contractId = plan.planId.substring(0, 5);
      dceLaunchData.pbpNumber = plan.planId.substring(5, 8);
      dceLaunchData.segmentId = plan.planId.substring(8);

      if (plan.county) {
        dceLaunchData.stateCode = plan.county.stateCode;
        dceLaunchData.fipsCode = plan.county.fipsCountyCode;
        dceLaunchData.county = {
          cmsCountyCodes: plan.county.cmsCountyCodes,
          stateCode: plan.county.stateCode,
          fipsCountyCode: plan.county.fipsCountyCode,
          fipsCountyName: plan.county.fipsCountyName,
          fipsStateCode: plan.county.fipsStateCode
        };
        dceLaunchData.isUsOtherTerritories = this.locationService.isUSOtherTerritory(dceLaunchData.stateCode);
      }

      const planDetails: any = planSearchResultsList.filter(detail => plan.planId === detail.planId);
      dceLaunchData.monthlyPremium = ( planDetails[0] && planDetails[0].monthlyPremium ) ? planDetails[0].monthlyPremium : 0;
      dceLaunchData.brandId = (planDetails[0] && planDetails[0].brandId ) ? planDetails[0].brandId : '';
      dceLaunchData.isPreferred = ( planDetails[0] && planDetails[0].preferredNetwork ) ? planDetails[0].preferredNetwork : plan.preferredNetwork;
      dceLaunchData.isSaver = ( planDetails[0] && planDetails[0].pharmacySaver ) ? planDetails[0].pharmacySaver : plan.pharmacySaver;

      return dceLaunchData;

    } catch (e) {
      console.log('Some error occurred while  building DCE Launch data');
      return null;
    }
  }

  launchDCE(): void {
    this.storageService.setItem_SS(AppConstants.isDefaultPlan, AppConstants.TRUE_VALUE);
    location.href = '/health-plans/estimate-drug-costs.html?profile=true';
  }

  launchDCEWithPlanInfo(plan: Plan, appData: AppData): void {
    this.cookieService.setLocationSessionCookie(plan.county, plan.planYear, plan.zipCode);
    this.cookieService.setDCEInitialCookie(this.siteId, this.cookieService.getLocationSessionCookie(), plan);

    const dceLaunchObject = this.getDCELaunchData(plan, appData.planSearchResultsList);
    this.storageService.setItem_SS(AppConstants.dceLaunchObj, JSON.stringify(dceLaunchObject));

    if (this.isDrugsDataExists(appData)) {
      location.href = '/health-plans/estimate-drug-costs.html?profile=true&planEditDrug=true';
    } else {
      location.href = '/health-plans/estimate-drug-costs.html?profile=true&planAddDrug=true';
    }
  }

}
