import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  constructor() {}

  formatFipsCode(fipscode: any): string {
    const fipscodelength = fipscode.toString().length;

    if (fipscodelength === 1) {
      return '00' + fipscode.toString();
    } else if (fipscodelength > 1 && fipscodelength < 3) {
      return '0' + fipscode.toString();
    } else {
      return fipscode;
    }
  }

  formatZipCode(zipcode: any): string {
    const zipcodelength = zipcode.toString().length;
    if (zipcodelength === 4) {
      return '0' + zipcode.toString();
    } else {
      return zipcode;
    }
  }

  isUSOtherTerritory(stateCode: string): boolean {
    const otherTerritoriesData = ['GU', 'AS', 'VI', 'MP', 'UM', 'PR', 'FM', 'MH'];
    return (stateCode && otherTerritoriesData.indexOf(stateCode) > -1) ? true : false;
  }

}
