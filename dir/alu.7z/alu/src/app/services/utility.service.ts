import { DOCUMENT } from '@angular/common';
import { Injectable, Inject } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { AppConstants } from '../constants/app-constants';
import { UserDetails } from '../models/UserDetails';
import { Plan } from '../models/Plan';
import { AppData } from '../models/AppData';
import { DCEConstants } from '../constants/dce-constants';
import { StorageService } from './storage.service';

declare var _satellite: any;

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  constructor(
    private readonly http: HttpClient,
    private readonly sanitized: DomSanitizer,
    private readonly storageService: StorageService,
    @Inject(DOCUMENT) private readonly document: Document
  ) {}

  getQueryParamValue(queryParamName: string): any {
    const results = new RegExp('[\?&]' + queryParamName + '=([^&#]*)').exec(window.location.href);
    return results == null ? null : (decodeURI(results[1]) || 0);
  }

  isLoadIdentityConfirmPopup(userDetails: UserDetails): boolean {
    return !this.document.getElementById('identity-confirm-popup')
      && userDetails
      && userDetails.telesalesProfileType
      && userDetails.createdBy !== AppConstants.agent;
  }

  lazyLoadStyles(styleName: string) {
    return new Promise((resolve, reject) => {
      const styleElement = this.document.getElementById(styleName) as HTMLLinkElement;
      const styleElementHref =  this.isLocalHost() ? `${styleName}.css` : `/etc/clientlibs/landrover-ui/scripts/client/${styleName}.css`;

      if (styleElement) {
        console.log(styleName + '.css already attached to <head>');
        styleElement.href = styleElementHref;

      } else {
        console.log(styleName + '.css loading in progress...');
        const head = this.document.getElementsByTagName('head')[0];
        const lazyStyleElement = this.document.createElement('link');

        lazyStyleElement.id = styleName;
        lazyStyleElement.rel = 'stylesheet';
        lazyStyleElement.type = 'text/css';
        lazyStyleElement.href = styleElementHref;
        lazyStyleElement.onload = resolve;

        head.appendChild(lazyStyleElement);
      }
    });
  }

  renderFullName(firstName: string, lastName: string) {
    let fName = firstName;
    let lName = lastName;
    let fullName = '';

    if (fName && lName) {
      fName = fName.charAt(0).toUpperCase() + fName.substring(1).toLowerCase();
      lName = lName.charAt(0).toUpperCase() + lName.substring(1).toLowerCase();
      fullName = fName + ' ' + lName;

    } else if (fName) {
      fName = fName.charAt(0).toUpperCase() + fName.substring(1).toLowerCase();
      fullName = fName;

    } else if (lName) {
      lName = lName.charAt(0).toUpperCase() + lName.substring(1).toLowerCase();
      fullName = lName;
    }
    return fullName;
  }

  renderFirstName(firstName: string) {
    return firstName ? firstName.charAt(0).toUpperCase() + firstName.substring(1).toLowerCase() : '';
  }

  convertToDBDateFormat(dateString: string): string {
    let dbDateString: string;

    try {
      if (dateString && dateString.indexOf('/') > -1) {
        const dateArray = dateString.trim().split('/');
        dbDateString = dateArray.length === 3 ? (dateArray[2] + '-' + dateArray[0] + '-' + dateArray[1]) : null;
      }
    } catch (e) {
      console.log('Exception occurred while converting date string to DB date format');
    }
    return dbDateString;
  }

  getUhcStatusFromTelesalesProfileType(telesalesProfileType: string) {
    let uhcStatus: string;

    if (telesalesProfileType && telesalesProfileType === 'MEMBER-CONSENT') {
      uhcStatus = 'M';
    } else if (telesalesProfileType && telesalesProfileType === 'NON-MEMBER-CONSENT') {
      uhcStatus = 'P';
    } else if (telesalesProfileType && telesalesProfileType === 'MEMBER-NO-CONSENT') {
      uhcStatus = 'TPM';
    } else if (telesalesProfileType && telesalesProfileType === 'NON-MEMBER-NO-CONSENT') {
      uhcStatus = 'TPP';
    }
    return uhcStatus;
  }

  isNotLocalHost() {
    return location.host.indexOf(AppConstants.localhost) === -1;
  }

  isLocalHost() {
    return location.host.indexOf(AppConstants.localhost) > -1;
  }

  scrollToElement(id: string, enableSmoothScrolling = false) {
    const element = document.getElementById(id);

    if (element) {
      element.focus();

      if (enableSmoothScrolling) {
        element.scrollIntoView({ behavior: 'smooth' });
      } else {
        element.scrollIntoView();
      }

    } else {
      console.log('Element does n\'t exist');
    }
  }

  isValidDate(date: Date): boolean {
    return Object.prototype.toString.call(date) === '[object Date]'
      && !isNaN(date?.getTime());
  }

  is_DSNP_plan(plan: Plan, appData: AppData): boolean {
    return appData?.planBenefitsContent?.mnrDsnpPlanId
      && appData?.planBenefitsContent?.mnrDsnpPlanId.indexOf(plan?.planId) >= 0;
  }

  is_CNS_plan(plan: Plan, appData: AppData): boolean {
    if (appData.cnsInfo) {
      const cnsPlan = appData?.cnsInfo?.find(val => val?.planId === plan?.planId);
      if (cnsPlan) {
        return true;
      }
    }
    return false;
  }

  is_DualLookAlike_plan(restPlanObj: any, appData: AppData) {
    return restPlanObj?.dualSNPSubType === appData?.planBenefitsContent?.dualLookalike
      && restPlanObj?.snpType !== appData?.planBenefitsContent?.snpTypeInstitutional;
  }

  getMonthlyPremiumValue(plan: any, appData: AppData): string {
    let monthlyPremium = '$0';

    try {
      if (plan?.compositePlanId?.planType?.name === 'MA' || plan?.compositePlanId?.planType?.name === 'MAPD') {
        if (this.is_DualLookAlike_plan(plan, appData) && plan.monthlyPremium > 0) {
          // tslint:disable-next-line:triple-equals
          monthlyPremium = `$0 - $${plan.monthlyPremium == 0 ? plan.monthlyPremium : plan.monthlyPremium.toFixed(2)}`;
        } else {
          // tslint:disable-next-line:triple-equals
          monthlyPremium = `$${plan.monthlyPremium == 0 ? plan.monthlyPremium : plan.monthlyPremium.toFixed(2)}`;
        }

      } else if (plan?.compositePlanId?.planType?.name === 'PDP') {
        // tslint:disable-next-line:triple-equals
        monthlyPremium = `$${plan.monthlyPremium == 0 ? plan.monthlyPremium : plan.monthlyPremium.toFixed(2)}`;

      } else if (plan?.compositePlanId?.planType?.name?.indexOf('SNP') > -1) {
        if (!plan.isSpecialSNPPlan && (this.is_DSNP_plan(plan, appData) || this.is_CNS_plan(plan, appData) || this.is_DualLookAlike_plan(plan, appData))) {
          if (plan.monthlyPremium > 0) {
            monthlyPremium = `$0 - $${plan.monthlyPremium}`;
          } else {
            monthlyPremium = `$${plan.monthlyPremium}`;
          }
        }

        if (plan.isSpecialSNPPlan && (this.is_DSNP_plan(plan, appData) || this.is_CNS_plan(plan, appData) || this.is_DualLookAlike_plan(plan, appData))) {
          monthlyPremium = `$0`;
        } else if (!plan.isSpecialSNPPlan && !(this.is_DSNP_plan(plan, appData) || this.is_CNS_plan(plan, appData) || this.is_DualLookAlike_plan(plan, appData))) {
          monthlyPremium = `$${plan.monthlyPremium}`;
        }
      }

    } catch (e) {
      console.log('Some error occurred while getting Monthly Premium value of plan : [' + plan?.planName + ']');
    }

    return monthlyPremium;
  }

  getPlanDetails(
    planId: string,
    planYear: string,
    includeDrugBenefit = false,
    includeMedicalBenefit = false,
    includeLICSBenefit = false,
    showDescriptiveText = false
  ) {
    const url = DCEConstants.planBenefitsBaseURI + DCEConstants.searchPlansURI;
    const requestData = {
      profileInfo: {
        profileId: 'UCP'
      },
      compositePlanIdList: [
        {
          contractId  : planId?.substring(0, 5),
          pbpNumber   : planId?.substring(5, 8),
          segmentId   : planId?.substring(8),
          planYear
        }
      ],
      includeDrugBenefit,
      includeMedicalBenefit,
      includeLICSBenefit,
      showDescriptiveText
    };

    return this.http.post<any>(url, requestData, httpOptions);
  }

  goToVppPage(params: string = '') {
    this.storageService.removeItem_SS(AppConstants.dceLaunchObj);
    this.storageService.removeItem_SS(AppConstants.dceVisitorProfileFlag);
    location.href = '/health-plans.html' + (params ? params : '');
  }

  disableDCEFlags() {
    const dceDetailsToPlanDetailsFlag = this.storageService.getItem_SS(AppConstants.dceDetailsToPlanDetails);
    const dceSummaryToPlanDetailsFlag = this.storageService.getItem_SS(AppConstants.dceSummaryToPlanDetails);

    if (dceDetailsToPlanDetailsFlag) {
      this.storageService.setItem_SS(AppConstants.dceDetailsToPlanDetails, AppConstants.FALSE_VALUE);
    }
    if (dceSummaryToPlanDetailsFlag) {
      this.storageService.setItem_SS(AppConstants.dceSummaryToPlanDetails, AppConstants.FALSE_VALUE);
    }
  }

  navigateToURL(url: string): void {
    if (url) {
      location.href = url;
    } else {
      console.log('! Invalid URL !');
    }
  }

  getSanitizedHTML(text: string) {
    return text ? this.sanitized.bypassSecurityTrustHtml(text) : '';
  }

  setBodyScroll(show: boolean) {
    if (show) {
      this.document.querySelector('body')?.classList?.remove('no-y-scroll');
    } else {
      this.document.querySelector('body')?.classList?.add('no-y-scroll');
    }
  }

  trackData(event: string) {
    try {
      if (typeof _satellite !== 'undefined' && _satellite && typeof _satellite.track !== 'undefined' && _satellite.track) {
        _satellite.track(event);
      }
    } catch (e) {
      console.log('Some error occurred while tracking _satellite event.');
    }
  }

  getVPDLDataObject(profileDetails?: any): any {
    try {
      if (profileDetails) {
        const vpObj = {
          authenticated     : profileDetails.uuid !== undefined,
          savedPlans        : profileDetails.plansDetails?.plans?.length,
          dcEntered         : profileDetails.drugsAndPharmacyDetails?.drugInfoDetails?.length,
          phEntered         : profileDetails.drugsAndPharmacyDetails?.pharmacyObj ? 1 : 0,
          pcpEntered        : profileDetails.providersDetails?.providerIdList?.length,
          savedPlanIds      : profileDetails.plansDetails?.savedPlans,
          savedEnrollments  : [],
          recommendedPlanIDs: []
        };

        if (profileDetails.preData?.data) {
          const preRecommendationData = JSON.parse(profileDetails.preData.data);

          if (preRecommendationData?.planRecommendationObj?.plans?.length > 0) {
            preRecommendationData.planRecommendationObj.plans.forEach((plan: any) => vpObj.recommendedPlanIDs.push(plan.planId));
          }
        }

        if (profileDetails?.enrollmentsDetails?.enrollments?.length > 0) {
          profileDetails.enrollmentsDetails.enrollments.forEach((enrollment: any) => {
            if (enrollment) {
              vpObj.savedEnrollments.push({ planId : enrollment.planId, status : enrollment.status });
            }
          });
        }
        return vpObj;
      }

    } catch (e) {
      console.log('Error capturing VP DL object', e);
    }
    return undefined;
  }
}
