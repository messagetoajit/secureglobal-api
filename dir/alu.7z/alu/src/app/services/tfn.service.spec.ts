import { TestBed } from '@angular/core/testing';
import { TFNService } from './tfn.service';
import { CookieService } from './cookie.service';

describe('TFNService', () => {
  let service: TFNService;
  let cookieService: CookieService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TFNService,
        CookieService
      ]
    });
    service = TestBed.get(TFNService);
    cookieService = TestBed.get(CookieService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should not get AuthorTFN if it has less than 2 values', () => {
    spyOn(cookieService, 'getCookie').and.returnValue('1,2')
    var tfn = service.getAuthorTFN();
    expect(tfn).toEqual('');
  });

  it('should have get AuthorTFN if it has more than 2 values', () => {
    spyOn(cookieService, 'getCookie').and.returnValue('1,2,3')
    var tfn = service.getAuthorTFN();
    expect(tfn).toEqual('3');
  });
});
