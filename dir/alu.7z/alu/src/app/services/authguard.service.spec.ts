import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { AppConstants } from '../constants/app-constants';
import { AuthGuardService } from './authguard.service';
import { CookieService } from './cookie.service';

class RouterStub {
    navigate(params: any): any {}
}

class ActivatedRouteStub {
    get params(): Observable<any> {
      return of({ id: 0 });
    }
}

describe('AuthGuardService', () => {
    let service: AuthGuardService;
    let cookieService: CookieService;
    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [
            AuthGuardService,
            CookieService,
          { provide: Router, useClass: RouterStub },
          { provide: ActivatedRoute, useClass: ActivatedRouteStub }
        ]
      });
      service = TestBed.inject(AuthGuardService);
      cookieService = TestBed.inject(CookieService);
    });

    it('should create', () => {
      expect(service).toBeTruthy();
    });

    it('should return true when guest calls canActivate', () => {
        spyOn(cookieService, 'isGuestUser').and.returnValue(true);
        expect(service.canActivate()).toEqual(true);
    });

    it('should navigate to authenticated in case of an authenticated user',  fakeAsync(() => {
      const router = TestBed.inject(Router);
      const spy = spyOn(router, 'navigate');
      spyOn(cookieService, 'isGuestUser').and.returnValue(false);
      const result = service.canActivate();
      tick(100);
      expect(spy).toHaveBeenCalledWith(['authenticated'], AppConstants.navigationConfig);
      expect(result).toEqual(false);
    }));

  });
