import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { EmailConstants } from '../constants/email-constants';
import { UserDetails } from '../models/UserDetails';
import { SendEmailRequest } from '../models/SendEmailRequest';
import { UtilityService } from './utility.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class EmailService {

  constructor(
    private readonly httpClient: HttpClient,
    private readonly utilityService: UtilityService
  ) {}

  stopReminderEmail(userDetails: UserDetails, emailDeepLinkUrl: string) {
    if (userDetails) {
      this.sendEmail(userDetails, emailDeepLinkUrl).subscribe((response) => {
        // console.log(response);
      }, (error) => {
        console.log('Some error occurred while sending email.');
      });
    }
  }

  private sendEmail(userDetails: UserDetails, emailDeepLinkUrl: string) {
    const sendEmailRequest = this.generateSendEmailRequest(userDetails, emailDeepLinkUrl);
    /* console.log('Sending Email to stop reminders');
    console.log(sendEmailRequest); */

    const url = EmailConstants.baseURI + EmailConstants.stopReminderEmailURL;
    return this.httpClient.post<any>(url, sendEmailRequest, httpOptions);
  }

  private generateSendEmailRequest(userDetails: UserDetails, emailDeepLinkUrl: string) {
    const sendEmailRequest = new SendEmailRequest();

    if (userDetails) {
      sendEmailRequest.emailAddress   = userDetails.email;
      sendEmailRequest.firstName      = userDetails.firstName;
      sendEmailRequest.lastName       = userDetails.lastName;
      sendEmailRequest.mbi            = userDetails.mbi;
      sendEmailRequest.gender         = userDetails.gender;
      sendEmailRequest.dob            = this.utilityService.convertToDBDateFormat(userDetails.dob);
      sendEmailRequest.zip            = userDetails.zipCode;
      sendEmailRequest.siteId         = (userDetails.siteId && userDetails.siteId.indexOf('aarp') > -1) ? 'AARPM' : 'UHCM';
      sendEmailRequest.uhcstatus      = this.utilityService.getUhcStatusFromTelesalesProfileType(userDetails.telesalesProfileType);
      sendEmailRequest.deeplink       = emailDeepLinkUrl;
      sendEmailRequest.profileStatus  = 'A';
    }

    return sendEmailRequest;
  }

}
