import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';

import { UtilityService } from './utility.service';
import { StorageService } from './storage.service';
import { ShopperProfileService } from './shopper-profile.service';

import { OLE } from '../models/OLE';
import { Plan } from '../models/Plan';
import { AppData } from '../models/AppData';
import { PlanEnrollment } from '../models/PlanEnrollment';
import { AppConstants } from '../constants/app-constants';
import { DCEConstants } from '../constants/dce-constants';

declare var acqContextData: any;

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class OLEService {

  cnsInfo: any;
  dceCurrentYear = 1900;
  aepDate: Date;
  nextYearPlanEnrollStartDate: Date;

  constructor(
    private readonly http: HttpClient,
    private readonly storageService: StorageService,
    private readonly utilityService: UtilityService,
    private readonly shopperProfileService: ShopperProfileService
  ) {}

  setCnsInfo(cnsInfoList: any) {
    [...this.cnsInfo] = cnsInfoList;
  }

  getMonthlyPremiumNumericValue(value: string) {
    if (value) {
      value = value.replace(/\$/g, '');

      /* In case of range pick value after '-' */
      if (value.indexOf('-') > -1) {
        value = value.substring(value.indexOf('-') + 1).trim();
      }

      /* If value is zero then set it to decimal format */
      if (value === '0') {
        value = '0.00';
      }
    }
    return value;
  }

  setOleObj(savedPlan: any, searchPlansPlan: any, oleObj: OLE, appData: AppData): any {
    oleObj.planName = savedPlan.planName;
    oleObj.year = savedPlan.planYear;
    oleObj.zip = savedPlan.zipCode;
    oleObj.dental = false;
    oleObj.vision = false;
    oleObj.hearing = false;
    oleObj.fitness = false;
    oleObj.countyName = savedPlan.county.fipsCountyName;
    oleObj.premium = this.getMonthlyPremiumNumericValue(searchPlansPlan.monthlyPremiumFormatted);
    oleObj.planType = savedPlan.planType;
    oleObj.stateCode = savedPlan.county.stateCode;
    oleObj.fipsCode = savedPlan.county.fipsCountyCode;
    oleObj.HNumber = searchPlansPlan.compositePlanId.contractId;
    oleObj.PBPNumber = searchPlansPlan.compositePlanId.pbpNumber;
    oleObj.segmentId = searchPlansPlan.compositePlanId.segmentId;
    oleObj.riderFlag = searchPlansPlan.medicalBenefit && searchPlansPlan.medicalBenefit.riderBenefitList && searchPlansPlan.medicalBenefit.length > 1 ? true : false;
    oleObj.CMScode = savedPlan.county.cmsCountyCodes[0];
    oleObj.planCode = '';
    oleObj.lineOfBusiness = 'undefined';
    oleObj.clientProdCode = 'undefined';
    oleObj.planId = savedPlan.planId;
    oleObj.mapsPlanType = searchPlansPlan.mapsPlanType;
    oleObj.env = typeof(acqContextData) !== 'undefined' ? acqContextData.get('runmode') : 'prod';
    oleObj.isCNS = false;
    oleObj.isCSNP = appData.csnpList.indexOf(oleObj.planId) > -1 ? true : false;
    const dentalbenefitarray = ['16a1', '16a2', '16a3', '16a4', '16a5', '16b1', '16b2', '16b3', '16b5', '16b6', '16b7', '16b8'];
    if (searchPlansPlan.medicalBenefit) {
      oleObj.hearing = searchPlansPlan.medicalBenefit.medicalBenefitList.find((medicalBenefitType: any) =>
       (medicalBenefitType.medicalBenefitType.code === '18a1' &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMinAmount != null &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMaxAmount != null)
      ) ? true : false;
      oleObj.vision = searchPlansPlan.medicalBenefit.medicalBenefitList.find((medicalBenefitType: any) => {
        return (medicalBenefitType.medicalBenefitType.code === '17a1' &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMinAmount != null &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMaxAmount != null);
      }) ? true : false;
      oleObj.fitness = searchPlansPlan.medicalBenefit.medicalBenefitList.find((medicalBenefitType: any) => {
        return (medicalBenefitType.medicalBenefitType.code === '14a6' &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMinAmount != null &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMaxAmount != null);
      }) ? true : false;
      oleObj.dental = searchPlansPlan.medicalBenefit.medicalBenefitList.find((medicalBenefitType: any) => {
        return (dentalbenefitarray.indexOf(medicalBenefitType.medicalBenefitType.code) > -1 &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMinAmount != null &&
        medicalBenefitType.medicalBenefitTierByBenefitTypeList[0].costMaxAmount != null);
      }) ? true : false;
    }
    if (location.href.indexOf('uhcmedicaresolutions') > -1) {
      if (oleObj.planType === 'MA' || oleObj.planType === 'MAPD') {
        oleObj.url = '/health-plans/medicare-advantage-plans/medicare-enrollment/united-healthcare-medicare-advantage-online-application.html';
      } else if (oleObj.planType === 'PDP') {
        oleObj.url = '/health-plans/prescription-drug-plans/medicare-enrollment/medicare-prescription-drug-plans-online-application.html';
      } else if (oleObj.planType && oleObj.planType.indexOf('SNP') > -1) {
        oleObj.url = '/health-plans/special-needs-plans/medicare-enrollment/special-needs-plans-online-application.html';
      }
    } else {
      if (oleObj.planType === 'MA' || oleObj.planType === 'MAPD') {
        oleObj.url = '/health-plans/medicare-advantage-plans/medicare-enrollment/aarp-medicare-complete-online-application.html';
      } else if (oleObj.planType === 'PDP') {
        oleObj.url = '/health-plans/prescription-drug-plans/medicare-application/aarp-medicarerx-online-application.html';
      } else if (oleObj.planType && oleObj.planType.indexOf('SNP') > -1) {
        oleObj.url = '/health-plans/special-needs-plans/medicare-enrollment/special-needs-plans-online-application.html';
      }
    }
    let  cnsPlan;
    if (this.cnsInfo && this.cnsInfo.length > 0) {
      cnsPlan = this.cnsInfo.find(val => val.planId === oleObj.planId);
    }
    if (cnsPlan) {
      oleObj.isCNS = true;
      oleObj.planName = cnsPlan.planName || oleObj.planName;
      oleObj.lineOfBusiness = cnsPlan.lineOfBusiness || '';
      oleObj.clientProdCode = cnsPlan.clientProdCode || '';
    }
    const oleCookieString = `${oleObj.planName},${oleObj.year},${oleObj.zip},${oleObj.countyName},${oleObj.premium},${oleObj.planType},${oleObj.stateCode},` +
                            `${oleObj.fipsCode},${oleObj.HNumber},${oleObj.PBPNumber},${oleObj.riderFlag},${oleObj.CMScode},${oleObj.planId},${oleObj.planCode},` +
                            `${oleObj.mapsPlanType},${oleObj.env},${oleObj.isCNS},${oleObj.clientProdCode},${oleObj.lineOfBusiness},${oleObj.isCSNP},` +
                            `${oleObj.fitness},${oleObj.vision},${oleObj.hearing},${oleObj.dental},${oleObj.segmentId}`;

    return oleCookieString;
  }

  isEnrollmentsExists(appData: AppData): boolean {
    return appData.profileDetails.enrollmentsDetails && appData.profileDetails.enrollmentsDetails.enrollments && appData.profileDetails.enrollmentsDetails.enrollments.length > 0;
  }

  isPlansDataExists(appData: AppData): boolean {
    return appData.profileDetails.plansDetails && appData.profileDetails.plansDetails.plans && appData.profileDetails.plansDetails.plans.length > 0;
  }

  resetPlansEnrollmentStatus(appData: AppData) {
    if (this.isPlansDataExists(appData)) {
      appData?.maPlansList?.forEach(plan => plan.enrollmentStatus = null);
      appData?.pdpPlansList?.forEach(plan => plan.enrollmentStatus = null);
      appData?.snpPlansList?.forEach(plan => plan.enrollmentStatus = null);
    }
  }

  setEnrollmentDetails(appData: AppData, enrollmentDataExists: boolean): any {
    this.resetPlansEnrollmentStatus(appData);

    if (this.isEnrollmentsExists(appData)) {
      this.dceCurrentYear = appData.dceSystemDateTime.getFullYear();
      this.aepDate = new Date('Nov 30 ' + this.dceCurrentYear + ' 23:59:59');
      this.nextYearPlanEnrollStartDate = new Date('Oct 15 ' + this.dceCurrentYear + ' 00:00:00');

      appData.profileDetails.enrollmentsDetails.enrollments = appData.profileDetails.enrollmentsDetails.enrollments.filter((e: PlanEnrollment) => this.filterEnrollments(e, appData.dceSystemDateTime));

      if (this.isEnrollmentsExists(appData)) {
        enrollmentDataExists = true;

        this.evaluateAndSetPlanEnrollmentStatus(appData);
        this.getEnrollmentsMonthlyPremiumData(appData);

        if (appData?.medsuppPlansList?.length === 0) {
          this.getSubmittedOLEApplicationStatusFromGPS(appData);
        }

      } else {
        enrollmentDataExists = false;
      }

    } else {
      enrollmentDataExists = false;
    }
    return {appData, enrollmentDataExists};
  }

  filterEnrollments(enrollment: PlanEnrollment, dceSystemDate: Date): boolean {
    const enrollmentPlanYear = Number(enrollment.planYear);

    if ((enrollmentPlanYear < this.dceCurrentYear) ||
        (enrollmentPlanYear === this.dceCurrentYear && dceSystemDate > this.aepDate) ||
        (enrollmentPlanYear > this.dceCurrentYear && dceSystemDate < this.nextYearPlanEnrollStartDate) ||
        (enrollmentPlanYear > this.dceCurrentYear && enrollmentPlanYear !== (this.dceCurrentYear + 1))
    ) {
      return false;
    }
    return true;
  }

  evaluateAndSetPlanEnrollmentStatus(appData: AppData) {
    try {
      if (this.isPlansDataExists(appData)) {
        appData.profileDetails.enrollmentsDetails.enrollments.forEach((enrollment: PlanEnrollment) => {
          this.setFavAndPREPlanEnrollmentStatus(enrollment, appData);
        });
      }

    } catch (e) {
      console.log('Some error occurred while setting plan enrollments status');
    }
  }

  private setFavAndPREPlanEnrollmentStatus(enrollment: PlanEnrollment, appData: AppData) {
    if (enrollment.planType === 'MA' || enrollment.planType === 'MAPD') {
      this.setPlanEnrollmentStatus(appData.maPlansList, enrollment);

    } else if (enrollment.planType === 'PDP') {
      this.setPlanEnrollmentStatus(appData.pdpPlansList, enrollment);

    } else if (enrollment.planType && enrollment.planType.indexOf('SNP') > -1) {
      this.setPlanEnrollmentStatus(appData.snpPlansList, enrollment);
    }

    if (this.isPRENo1PlanExists(appData) && appData.preNo1RankedPlan.planId === enrollment.planId && appData.preNo1RankedPlan.planYear === enrollment.planYear) {
      appData.preNo1RankedPlan.enrollmentStatus = enrollment.isSubmitted ? AppConstants.submitted : AppConstants.continueEnrollment;
    }
  }

  isPRENo1PlanExists(appData: AppData): boolean {
    return appData.preRecommendationType === AppConstants.PRE_NO_1_RANKED_PLAN
      && appData.preNo1RankedPlan
      && appData.preNo1RankedPlan.planId
      && appData.preNo1RankedPlan.planYear;
  }

  setPlanEnrollmentStatus(plans: Plan[], enrollment: PlanEnrollment) {
    plans.filter((p: Plan) => p.planId === enrollment.planId && p.planYear === enrollment.planYear).forEach((plan: Plan) => {
      plan.enrollmentStatus = enrollment.isSubmitted ? AppConstants.submitted : AppConstants.continueEnrollment;
    });
  }

  getEnrollmentsMonthlyPremiumData(appData: AppData) {
    try {
      if (appData.fetchPlanDetails) {
        this.getEnrolledPlansDetails(appData.profileDetails.enrollmentsDetails.enrollments).subscribe((planDetailsArray: any) => {
          appData.fetchPlanDetails = false;

          planDetailsArray?.forEach((planDetails: any) => {
            if (planDetails?.data?.plans?.length > 0) {
              const plan = planDetails?.data?.plans[0];
              const enrollment = appData.profileDetails.enrollmentsDetails.enrollments.find((e: PlanEnrollment) => plan?.planId === e?.planId && plan?.compositePlanId?.planYear === e?.planYear);
              if (enrollment) {
                enrollment.monthlyPremium = this.utilityService.getMonthlyPremiumValue(plan, appData);

                appData.enrollmentsData[`${enrollment.planId}_${enrollment.planYear}_${enrollment.zipCode}`] = {
                  monthlyPremium : enrollment.monthlyPremium
                };
              }
            }
          });

        }, (error) => {
          appData.fetchPlanDetails = false;
          console.log('Some error occurred while fetching plan details');
          console.log(error);
        });

      } else if (appData?.enrollmentsData) {
        appData.profileDetails.enrollmentsDetails.enrollments.forEach((e: PlanEnrollment) => {
          e.monthlyPremium = appData.enrollmentsData[`${e.planId}_${e.planYear}_${e.zipCode}`]?.monthlyPremium;
        });
      }

    } catch (e) {
      console.log('Some error occurred while fetching enrollments monthly premium data.');
    }
  }

  getEnrolledPlansDetails(enrollments: PlanEnrollment[]): Observable<any[]> {
    const serviceCalls: any = [];

    enrollments?.forEach(e => {
      if (e?.planId && e?.planYear) {
        serviceCalls.push(this.utilityService.getPlanDetails(e?.planId, e?.planYear));
      }
    });

    return forkJoin(serviceCalls);
  }

  getSubmittedOLEApplicationStatusFromGPS(appData: AppData) {
    if (appData.fetchSubmittedEnrollmentStatus) {
      const submittedEnrollments = appData.profileDetails.enrollmentsDetails.enrollments?.filter(e => e.isSubmitted && e.confirmationNo);

      if (submittedEnrollments?.length > 0) {
        const applicantData = this.getApplicantDetails(submittedEnrollments);

        if (applicantData) {
          const deniedEnrollments = [];

          this.shopperProfileService.getOLEApplicationStatus(applicantData).subscribe((graphQLResponse: any) => {
            appData.fetchSubmittedEnrollmentStatus = false;

            /* graphQLResponse = {
              data : {
                applications: [
                  { imageIdentifier : 'WS37079461', applicationState: { code: '10' } },
                  { imageIdentifier : 'WS37079459', applicationState: { code: '11' } },
                  { imageIdentifier : 'WS37079455', applicationState: { code: '12' } },
                  { imageIdentifier : 'WS37079903', applicationState: { code: '13' } }
                ]
              }
            }; */

            if (graphQLResponse?.data?.applications?.length > 0) {
              graphQLResponse.data.applications.filter(this.isValidGPSEnrollment).forEach((application: any) => {
                const applicationStatusCode = application.applicationState.code.trim();
                const oleConfirmationNo     = application.imageIdentifier.trim().replace(AppConstants.GPS_OLE_CONFIRM_NO_PREFIX, '');
                const oleStatus             = AppConstants.submittedOLEStatus[applicationStatusCode]?.portal_status;
                const enrollmentStatus      = oleStatus ? oleStatus : AppConstants.submitted;
                const matchedEnrollment     = submittedEnrollments.find((e: PlanEnrollment) => e?.confirmationNo === oleConfirmationNo);

                if (matchedEnrollment) {
                  matchedEnrollment.status = enrollmentStatus;

                  /* Persist submitted enrollment status in application state */
                  if (appData.enrollmentsData[`${matchedEnrollment.planId}_${matchedEnrollment.planYear}_${matchedEnrollment.zipCode}`]) {
                    appData.enrollmentsData[`${matchedEnrollment.planId}_${matchedEnrollment.planYear}_${matchedEnrollment.zipCode}`].status = enrollmentStatus;

                  } else {
                    appData.enrollmentsData[`${matchedEnrollment.planId}_${matchedEnrollment.planYear}_${matchedEnrollment.zipCode}`] = {
                      status : enrollmentStatus
                    };
                  }

                  if (applicationStatusCode === '12') {
                    deniedEnrollments.push(matchedEnrollment);
                  }
                }
              });

              if (appData.fetchDeniedApplicationContact && deniedEnrollments.length > 0) {
                this.setDeniedEnrollmentPlanContact(appData, submittedEnrollments, deniedEnrollments);
              }
            }

          }, (error) => {
            appData.fetchSubmittedEnrollmentStatus = false;
            console.log('Some error occured while fetching OLE application status.');
          });

          if (appData.fetchDeniedApplicationContact && deniedEnrollments.length > 0) {
            this.setDeniedEnrollmentPlanContact(appData, submittedEnrollments, deniedEnrollments);
          }
        }
      }

    } else if (appData?.enrollmentsData) {
      appData.profileDetails.enrollmentsDetails.enrollments.forEach((e: PlanEnrollment) => {
        const enrollmentStatus = appData.enrollmentsData[`${e.planId}_${e.planYear}_${e.zipCode}`]?.status;

        if (enrollmentStatus) {
          e.status = enrollmentStatus;
        }

        e.tty = appData.enrollmentsData[`${e.planId}_${e.planYear}_${e.zipCode}`]?.tty;
        e.phoneNumber = appData.enrollmentsData[`${e.planId}_${e.planYear}_${e.zipCode}`]?.phoneNumber;
        e.hoursOfOperation = appData.enrollmentsData[`${e.planId}_${e.planYear}_${e.zipCode}`]?.hoursOfOperation;
      });
    }
  }

  isValidGPSEnrollment(gpsEnrollment: any) {
    return gpsEnrollment?.applicationState?.code
      && gpsEnrollment?.imageIdentifier?.length > 2
      && gpsEnrollment?.imageIdentifier?.trim().toUpperCase().substring(0, 2) === AppConstants.GPS_OLE_CONFIRM_NO_PREFIX;
  }

  setDeniedEnrollmentPlanContact(appData: AppData, submittedEnrollments: PlanEnrollment[], deniedEnrollments: PlanEnrollment[]) {
    this.getEnrollmentPlanContact(deniedEnrollments).subscribe((planContactResponseArray: any[]) => {
      appData.fetchDeniedApplicationContact = false;

      planContactResponseArray?.forEach((response: any, index: number) => {
        if (response?.success && response?.data?.phoneNumber) {
          const deniedEnrollment = deniedEnrollments[index];
          const enrollment = submittedEnrollments?.find((e: PlanEnrollment) => deniedEnrollment?.planId === e?.planId && deniedEnrollment?.planYear === e?.planYear);

          if (enrollment) {
            enrollment.phoneNumber = response.data.phoneNumber;
            enrollment.tty = response.data.tty;
            enrollment.hoursOfOperation = response.data.hoursOfOperation;

            /* Persist denied enrollment contact in application state */
            if (appData.enrollmentsData[`${enrollment.planId}_${enrollment.planYear}_${enrollment.zipCode}`]) {
              appData.enrollmentsData[`${enrollment.planId}_${enrollment.planYear}_${enrollment.zipCode}`].phoneNumber = response.data.phoneNumber;
              appData.enrollmentsData[`${enrollment.planId}_${enrollment.planYear}_${enrollment.zipCode}`].tty = response.data.tty;
              appData.enrollmentsData[`${enrollment.planId}_${enrollment.planYear}_${enrollment.zipCode}`].hoursOfOperation = response.data.hoursOfOperation;

            } else {
              appData.enrollmentsData[`${enrollment.planId}_${enrollment.planYear}_${enrollment.zipCode}`] = {
                phoneNumber : response.data.phoneNumber,
                tty : response.data.tty,
                hoursOfOperation : response.data.hoursOfOperation
              };
            }
          }
        }
      });

    }, (error) => {
      appData.fetchDeniedApplicationContact = false;
      console.log('Some error occured while fetching plan contact details.');
    });
  }

  getApplicantDetails(enrollments: PlanEnrollment[]): any {
    let applicantData = null;
    const formData = enrollments[0]?.formData ? JSON.parse(enrollments[0]?.formData) : [];

    if (formData?.length > 0) {
      let mbi: string;

      formData?.forEach((view: any) => {
        if (view?.data?.MedicareInsuranceInformation) {
          mbi = view.data.MedicareInsuranceInformation?.medicareClaimNumber;

          if (mbi) {
            mbi = mbi.trim().replace(/-/g, '');
          }
        }
      });

      applicantData = { mbi, pageSize: 100 };
    }
    return applicantData;
  }

  getEnrollmentPlanContact(enrollments: PlanEnrollment[]): Observable<any[]> {
    const serviceCalls: any = [];

    enrollments?.forEach(e => {
      if (e?.planId && e?.planYear) {
        serviceCalls.push(this.getIndividualPlanContact(e?.planId, e?.planYear));
      }
    });

    return forkJoin(serviceCalls);
  }

  getIndividualPlanContact(planId: string, planYear: string): Observable<any> {
    const url = DCEConstants.planBenefitsBaseURI + DCEConstants.individualPlanContacts
      + `/${planId?.substring(0, 5)}/${planId?.substring(5, 8)}/${planId?.substring(8)}/${planYear}`;
    return this.http.get(url);
  }

  setOLEFormData(enrollment: PlanEnrollment) {
    const formData = JSON.parse(enrollment.formData);
    const geotrackingZip = this.storageService.getItem_SS(AppConstants.geotrackingZip);
    const geotrackingState = this.storageService.getItem_SS(AppConstants.geotrackingState);

    // tslint:disable-next-line: no-string-literal
    formData[formData.length - 1]['origin'] = 'profile';

    this.storageService.clear_SS(false);

    this.storageService.setItem_SS(AppConstants.geotrackingZip, geotrackingZip);
    this.storageService.setItem_SS(AppConstants.geotrackingState, geotrackingState);
    this.storageService.setItem_SS(AppConstants.formDataKey, JSON.stringify(formData), false);
  }

}
