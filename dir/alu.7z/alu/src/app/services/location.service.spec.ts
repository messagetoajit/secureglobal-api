import { TestBed } from '@angular/core/testing';
import { AppConstants } from '../constants/app-constants';
import { LocationService } from './location.service';

describe('LocationService', () => {
    let service: LocationService;
    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [
            LocationService
        ]
      });
      service = TestBed.inject(LocationService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('test formatFipsCode function', () => {
        expect(service.formatFipsCode(1)).toBe('001');
        expect(service.formatFipsCode(12)).toBe('012');
        expect(service.formatFipsCode('123')).toBe('123');
    });

    it('test formatZipCode function', () => {
        expect(service.formatZipCode(1000)).toBe('01000');
        expect(service.formatZipCode('10001')).toBe('10001');
    });

    it('test isUSOtherTerritory function', () => {
        expect(service.isUSOtherTerritory('')).toBe(false);
        expect(service.isUSOtherTerritory(null)).toBe(false);
        expect(service.isUSOtherTerritory('GU')).toBe(true);
    });
});
