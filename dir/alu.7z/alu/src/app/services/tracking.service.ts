import { Injectable } from '@angular/core';
import { AppConstants } from '../constants/app-constants';

declare var customTracking: any;

@Injectable({
  providedIn: 'root'
})
export class TrackingService {

    siteId: string;
    isTrackingEnabled = false;

    constructor() {
        this.siteId = location.href.indexOf(AppConstants.aarpmedicareplans) > -1 ? AppConstants.AMP : AppConstants.UMS;
        this.isTrackingEnabled = (typeof customTracking !== 'undefined' && customTracking && typeof customTracking.startCustomTrackingV2 === 'function');
    }

    track(infoType: string, name: string, data: any, eventType: string) {
        if (this.isTrackingEnabled) {
            try {
                customTracking.startCustomTrackingV2(infoType, this.siteId + ' # profile - ' + name, data, eventType);
            } catch (e) {
                console.log('Some error occurred while doing custom Tracking');
                console.log(e);
            }
        }
    }

}
