import { TestBed } from '@angular/core/testing';
import { AppConstants } from '../constants/app-constants';
import { TrackingService } from './tracking.service';

describe('TrackingService', () => {
    let service: TrackingService;
    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [
            TrackingService
        ]
      });
      service = TestBed.inject(TrackingService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('test track function', () => {
        service.track('', '', '', '');
        expect(service.isTrackingEnabled).toEqual(false);
        expect(service.siteId).toEqual(AppConstants.UMS);
    });
});
