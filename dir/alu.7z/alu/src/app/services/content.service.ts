import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';

import { URIConstants } from '../constants/uri-constants';
import { DCEConstants } from '../constants/dce-constants';
import { AppConstants } from '../constants/app-constants';

@Injectable({
  providedIn: 'root'
})

export class ContentService {

  siteId: string;

  constructor(private readonly httpClient: HttpClient) {
    this.siteId = location.href.indexOf(AppConstants.aarpmedicareplans) > -1 ? AppConstants.aarp : AppConstants.uhc;
  }

  getBenefitsTable(): Observable<any> {
    const url = URIConstants.vppContentPath + '/aarp' + URIConstants.benefitsTableContentPath;
    return this.httpClient.get(url);
  }

  getLandroverContent(): Observable<any> {
    return this.httpClient.get(URIConstants.landroverContentPath);
  }

  getShopperDataImportContent(): Observable<any> {
    return this.httpClient.get(URIConstants.shopperDataImportContentPath);
  }

  getStateSpecificContent(): Observable<any> {
    return this.httpClient.get(URIConstants.stateSpecificContentPath);
  }

  getCnsPlans(): Observable<any> {
    return this.httpClient.get(URIConstants.vppContentPath + URIConstants.cnsInfoPath);
  }

  getMarketingBullets(url: string): Observable<any> {
    return this.httpClient.get(url);
  }

  getToolTips(): Observable<any> {
    const url = URIConstants.vppContentPath + URIConstants.tooltipPath;
    return this.httpClient.get(url);
  }

  getDCEServerDateTime(): Observable<any> {
    const url = DCEConstants.planBenefitsBaseURI + DCEConstants.serverDateURI + '/' + this.siteId;
    return this.httpClient.get(url);
  }

  getPlansContent(): Observable<any[]> {
    const serviceCalls: any[] = [];

    serviceCalls.push(this.getMarketingBullets(URIConstants.mapdMarketingBullets));
    serviceCalls.push(this.getMarketingBullets(URIConstants.pdpMarketingBullets));
    serviceCalls.push(this.getBenefitsTable());
    serviceCalls.push(this.getCnsPlans());
    serviceCalls.push(this.getToolTips());

    return forkJoin(serviceCalls);
  }

}
