import { ProviderService } from "./provider.service";
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Provider } from '../models/Provider';
import { AppData } from '../models/AppData';
import { AppConstants } from '../constants/app-constants';
import { StorageService } from './storage.service';
import { Plan } from '../models/Plan';
import { County } from '../models/County';
import { UserDetails } from '../models/UserDetails';


describe('ProviderService', () => {
    let service: ProviderService;
    let storageService: StorageService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
      TestBed.configureTestingModule({
          imports: [HttpClientTestingModule],
          providers: [ProviderService, StorageService]
      });
      service = TestBed.inject(ProviderService);
      storageService = TestBed.inject(StorageService);
      httpMock = TestBed.inject(HttpTestingController);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('subscriber func', () => {
        service.getProvidersDataLoadingNotification();
        service.getRallyProviderSearchNotification();
        service.resetRallyProviderSearchSubject();
        service.getProviders();
        service.getFipsStateCode('12345');
    });

    it('deleteProviderFromCookie - true', () => {
        var provider = new Provider();
        var appData = new AppData();
        var providerDatObj = {
            providerIdList: [
                {providerId: '1' }
            ]
        }
        spyOn(storageService, 'getItem_LS').and.returnValue(JSON.stringify(providerDatObj));
        spyOn(storageService, 'removeItem_LS');
        service.deleteProviderFromCookie(provider, appData);
        expect(storageService.removeItem_LS).toHaveBeenCalled();
    });

    it('deleteProviderFromCookie - false', () => {
        var provider = new Provider();
        provider.providerId = '1';
        provider.providerAddressId = '1';
        var appData = new AppData();
        var providerDatObj = {
            providerIdList: [
                { providerId: '1', providerAddressId: '1' },
                { providerId: '2', providerAddressId: '2' }
            ],
            Products: [{TotalProviders:1}]
        }
        spyOn(storageService, 'getItem_LS').and.returnValue(JSON.stringify(providerDatObj));
        service.deleteProviderFromCookie(provider, appData);
    });

    it('postProviderDataToRally', () => {
        var plan = new Plan();
        plan.county = new County();
        plan.county.fipsCountyCode= '23';
        
        var appData = new AppData();
        var provider = new Provider();
        provider.providerId = '1';
        provider.providerAddressId = '1';
        appData.profileDetails.providersDetails = {
            providerIdList: [ provider ],
            zipCode: '50002'
        }

        service.postProviderDataToRally(appData, plan);
    });

    it('setProvidersDataInBrowserStorage', () => {
        var appData = new AppData();
        var provider = new Provider();
        provider.providerId = '1';
        provider.providerAddressId = '1';
        appData.profileDetails.providersDetails = {
            providerIdList: [ provider ],
            zipCode: '50002'
        }
        service.setProvidersDataInBrowserStorage(appData);
    });

    it('refreshScopeListener', () => {
        var appData = new AppData();
        var provider = new Provider();
        provider.providerId = '1';
        provider.providerAddressId = '1';
        
        var rallyProvidersData = {
            providerIdList: [ provider ],
            zipCode: '50002'
        };
        spyOn(storageService, 'getItem_LS').and.returnValue(JSON.stringify(rallyProvidersData));

        service.refreshScopeListener(appData);
        expect(appData.profileDetails.providersDetails).toBeTruthy()
    });

    it('isZipCodeExists', () => {
        var appData = new AppData();
        var userDetails = new UserDetails();
        userDetails.zipCode = '50002';
        appData.profileDetails.userDetails = userDetails;
        expect(service.isZipCodeExists(appData)).toEqual('50002')
    });


})