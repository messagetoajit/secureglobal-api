import { Injectable } from '@angular/core';
import { AppConstants } from '../constants/app-constants';

declare var commonToolUtilityService: any;

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  keysWithoutUCPSuffix = [
    AppConstants.formDataKey,
    AppConstants.providerKey
  ];
  isCommonUtilityServiceExists = false;

  constructor() {
    if (typeof commonToolUtilityService !== 'undefined' && commonToolUtilityService) {
      console.log('Common Tool Utility Service found...');
      this.isCommonUtilityServiceExists = true;
    } else {
      console.log('Common Tool Utility Service NOT found, normal browser storage functions will be used !!');
    }
  }

  buildStorageKey(key: string): string {
    return this.keysWithoutUCPSuffix.indexOf(key) === -1 ? ('ucp_' + key) : key;
  }

  /**** Local Storage related functions ****/

  getItem_LS(key: string, useUtilityMethods = true): string {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      return commonToolUtilityService.getValueFromStorage(commonToolUtilityService.storageTypes.LOCALSTORAGE, key);
    } else {
      return localStorage.getItem(this.buildStorageKey(key));
    }
  }

  setItem_LS(key: string, value: string, useUtilityMethods = true) {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      commonToolUtilityService.setValueInStorage(commonToolUtilityService.storageTypes.LOCALSTORAGE, key, value);
    } else {
      localStorage.setItem(this.buildStorageKey(key), value);
    }
  }

  removeItem_LS(key: string, useUtilityMethods = true) {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      return commonToolUtilityService.clearValueFromStorage(commonToolUtilityService.storageTypes.LOCALSTORAGE, key);
    } else {
      localStorage.removeItem(this.buildStorageKey(key));
    }
  }

  clear_LS(useUtilityMethods = true): void {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      return commonToolUtilityService.clearEntireStorage(commonToolUtilityService.storageTypes.LOCALSTORAGE);
    } else {
      localStorage.clear();
    }
  }

  /**** Session Storage related functions ****/

  getItem_SS(key: string, useUtilityMethods = true): string {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      return commonToolUtilityService.getValueFromStorage(commonToolUtilityService.storageTypes.SESSIONSTORAGE, key);
    } else {
      return sessionStorage.getItem(this.buildStorageKey(key));
    }
  }

  setItem_SS(key: string, value: string, useUtilityMethods = true) {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      commonToolUtilityService.setValueInStorage(commonToolUtilityService.storageTypes.SESSIONSTORAGE, key, value);
    } else {
      sessionStorage.setItem(this.buildStorageKey(key), value);
    }
  }

  removeItem_SS(key: string, useUtilityMethods = true) {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      return commonToolUtilityService.clearValueFromStorage(commonToolUtilityService.storageTypes.SESSIONSTORAGE, key);
    } else {
      sessionStorage.removeItem(this.buildStorageKey(key));
    }
  }

  clear_SS(useUtilityMethods = true): void {
    if (this.isCommonUtilityServiceExists && useUtilityMethods) {
      return commonToolUtilityService.clearEntireStorage(commonToolUtilityService.storageTypes.SESSIONSTORAGE);
    } else {
      sessionStorage.clear();
    }
  }

}
