import { Injectable } from '@angular/core';

declare var $;

@Injectable({
  providedIn: 'root'
})
export class TooltipService {

  constructor() {}

  public svgiconfunction() {
    $('div:empty *:not(".form-progress-bar")').remove();
    $('p:empty, li:empty, h2:empty').remove();
    $('a[target=_blank] svg, a[target=_blank] span').remove();
    $('<span class="sr-only"> - Opens in a new window</span> <svg class="icon-external" style="width:13px;height:13px;fill:#003da1;margin-left:5px;"  xlink:href="#external-link" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="243 461 895.9 832" enable-background="new 0 0 512 512"><path d="M979 888c-17.7 0-32 14.3-32 32v277c0 17.7-14.3 32-32 32H339c-17.7 0-32-14.3-32-32V621c0-17.7 14.3-32 32-32h384l0 0c0.3 0 0.7 0 1 0 17.7 0 32-14.3 32-32s-14.3-32-32-32c-0.3 0-0.7 0-1 0l0 0H307c-35.3 0-64 28.7-64 64v640c0 35.3 28.7 64 64 64h640c35.3 0 64-28.7 64-64V920C1011 902.3 996.7 888 979 888zM1112 461H851c-17.7 0-21.9 10.1-9.4 22.6L945 587 613.9 918.1c-18.8 18.8-18.7 49.1 0 67.9 18.7 18.8 49.1 18.7 67.9 0l331.1-331.1 103.4 103.4c12.5 12.5 22.6 8.3 22.6-9.4V488C1139 470.3 1129.7 461 1112 461z"/></svg>').appendTo('a[target=_blank]');
  }

  public tooltipmessageservice() {
    // let targets: any = $( '[rel~=tooltip]' );
    let target: any = false;
    let tooltip: any = false;
    // let title: any = false;
    let tip: any;
    let tiphtml: any;
    const tooltipSel = 'div[id^="tooltip"]';

    // tslint:disable-next-line:object-literal-key-quotes
    $('span[rel=tooltip].inline').attr({'tabindex': '0', 'role': 'button', 'aria-labelledby': 'tooltip', 'style': 'text-decoration: none;float:left !important;'});

    // $("a[rel=tooltip].inline").html(" <svg style=\"width:18px;height:18px;fill:#003da1;\" id=\"icon-info\" xlink:href='#icon-info' xmlns:xlink='http://www.w3.org/1999/xlink' viewBox=\"0 0 512 512\" enable-background=\"new 0 0 512 512\"><path d=\"M230.4,384H281.6V230.4H230.4V384z M256,0C114.562,0,0,114.562,0,256s114.562,256,256,256s256-114.562,256-256  S397.438,0,256,0z M256,460.8C143.106,460.8,51.2,368.9,51.2,256c0-112.894,91.906-204.8,204.8-204.8  c112.9,0,204.8,91.906,204.8,204.8C460.8,368.9,368.9,460.8,256,460.8z M230.4,179.2H281.6V128H230.4V179.2z\"/></svg>");
    // $('span[rel=tooltip].inline').html('<i style="font-size:1.5em;font-weight:bold;">&#9432;</i>');

    // tslint:disable-next-line:only-arrow-functions
    $(document).on('click', '[rel~=tooltip]', function(e) {
      e.preventDefault();
    });

    $(document).on('mouseenter focus', 'span[rel~=tooltip].inline', function(e) {
      target = $( this );
      tiphtml = $( this ).attr( 'title' );
      if ((tiphtml !== null) && (tiphtml !== undefined)) {
        tip = tiphtml.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, ' \" ');
      }

      tooltip = $( '<div role="tooltip" id="tooltip"></div>' );
      if (!tip || tip === '') {
        return false;
      }

      target.removeAttr( 'title' );
      tooltip.css( 'opacity', 0 ).html( tip ).appendTo( 'body' );

      // tslint:disable-next-line:only-arrow-functions
      const initTooltip = function() {
        if ($(window).width() < 768) {
          tooltip.css( 'max-width', 240 );
        } else {
          tooltip.css( 'max-width', 260 );
        }

        const posLeft = target.offset().left + ( target.outerWidth() / 2) - ( tooltip.outerWidth() / 2 ) + 5;
        let posTop  = target.offset().top - tooltip.outerHeight() - 20;

        if (posTop - $(window).scrollTop() < 0) {
          posTop = target.offset().top + target.outerHeight();
          tooltip.addClass( 'top' );
        } else {
          tooltip.removeClass( 'top' );
        }

        tooltip.css( { left: posLeft, top: posTop } ).animate( { top: '+=10', opacity: 1 }, 50 );
      };

      initTooltip();
      $(window).on('resize', initTooltip);

      // tslint:disable-next-line:only-arrow-functions
      const removeTooltip = function() {
        const tooltipLength = $(this.tooltipSel).length;
        if (!isNaN(tooltipLength) && tooltipLength > 1) {
          $(this.tooltipSel).not(':last').remove();
        }

        tooltip.animate( { top: '-=10', opacity: 0 }, 50, function() { $( this ).remove(); });
        target.attr( 'title', tip );
        target.clone(true).insertAfter(target);
        target.remove();
      };
      target.on( 'mouseleave focusout', removeTooltip );

      // tslint:disable-next-line:only-arrow-functions
      $('*:not([rel~=tooltip])').on('touchstart', function() {
        removeTooltip();
      });

      // tslint:disable-next-line:only-arrow-functions
      $(document).on('keyup', function(event: any) {
        if (event.keyCode === 27) {
          removeTooltip();
        }
      });
    });

    // tslint:disable-next-line:only-arrow-functions
    $('span[rel=tooltip]').on('hover', function() {
      $(this.tooltipSel).remove();
    });

    return null;
  }

}
