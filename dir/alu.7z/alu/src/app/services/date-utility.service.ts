import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class DateUtilityService {

    constructor() {}

    isSeptember(month: number) {
        return (month + 1) === 9;
    }

    isOctober(month: number) {
        return (month + 1) === 10;
    }

    isAEPPeriod(month: number) {
        return (month + 1) >= 10;
    }

    isBetween_Jan01_Nov30(inputDate: Date) {
        try {
            if (inputDate) {
                const year      = inputDate.getFullYear();
                const startDate = new Date('Jan 1 ' + year);
                const endDate   = new Date('Dec 1 ' + year);

                if ((inputDate >= startDate) && (inputDate < endDate)) {
                    return true;
                }
            }
        } catch (e) {
            console.log('Some error occurred in isBetween_Jan01_Nov30()');
        }
        return false;
    }

    isBetween_Oct01_Oct14(inputDate: Date) {
        try {
            if (inputDate) {
                const year      = inputDate.getFullYear();
                const startDate = new Date('Oct 01 ' + year);
                const endDate   = new Date('Oct 15 ' + year);

                if ((inputDate >= startDate) && (inputDate < endDate)) {
                    return true;
                }
            }
        } catch (e) {
            console.log('Some error occurred in isBetween_Oct01_Oct14()');
        }
        return false;
    }

    isBetween_Oct15_Nov30(inputDate: Date) {
        try {
            if (inputDate) {
                const year      = inputDate.getFullYear();
                const startDate = new Date('Oct 15 ' + year);
                const endDate   = new Date('Dec 1 ' + year);

                if ((inputDate >= startDate) && (inputDate < endDate)) {
                    return true;
                }
            }
        } catch (e) {
            console.log('Some error occurred in isBetween_Oct15_Nov30()');
        }
        return false;
    }

    isBetween_Oct15_Dec31(inputDate: Date) {
        try {
            if (inputDate) {
                const year      = inputDate.getFullYear();
                const startDate = new Date('Oct 15 ' + year);
                const endDate   = new Date('Jan 1 ' + (year + 1));

                if ((inputDate >= startDate) && (inputDate < endDate)) {
                    return true;
                }
            }
        } catch (e) {
            console.log('Some error occurred in isBetween_Oct15_Dec31()');
        }
        return false;
    }

    isBetween_Dec01_Dec31(inputDate: Date) {
        try {
            if (inputDate) {
                const year      = inputDate.getFullYear();
                const startDate = new Date('Dec 1 ' + year);
                const endDate   = new Date('Jan 1 ' + (year + 1));

                if ((inputDate >= startDate) && (inputDate < endDate)) {
                    return true;
                }
            }
        } catch (e) {
            console.log('Some error occurred in isBetween_Dec01_Dec31()');
        }
        return false;
    }

}
