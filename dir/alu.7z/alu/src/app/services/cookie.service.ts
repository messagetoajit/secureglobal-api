import { Injectable } from '@angular/core';

import { AppConstants } from '../constants/app-constants';
import { County } from '../models/County';
import { Plan } from '../models/Plan';
import { LocationService } from './location.service';

@Injectable({
  providedIn: 'root'
})
export class CookieService {

  constructor(private readonly locationService: LocationService) {}

  getCookie(name: string) {
    const ca: Array<string> = document.cookie.split(';');
    const caLen: number = ca.length;
    const cookieName = `${name}=`;
    let c: string;

    for (let i = 0; i < caLen; i += 1) {
      c = ca[i].replace(/^\s+/g, '');
      if (c.indexOf(cookieName) === 0) {
        return decodeURIComponent(c.substring(cookieName.length, c.length));
      }
    }
    return '';
  }

  deleteCookie(name: string) {
      this.setCookie(name, '', -1);
  }

  setCookie(name: string, value: string, expireDays: number = 0, domainName: string = null, path: string = '/') {
    value = encodeURIComponent(value);

    if (expireDays === 0) {
      const cpath: string = path ? `; path=${path}` : '';
      const domain: string = domainName ? `; domain=${domainName}` : '';
      document.cookie = `${name}=${value}; ${cpath}${domain}`;

    } else {
      const d: Date = new Date();
      d.setTime(d.getTime() + expireDays * 24 * 60 * 60 * 1000);
      const expires = `expires=${d.toUTCString()}`;
      const cpath: string = path ? `; path=${path}` : '';
      const domain: string = domainName ? `; domain=${domainName}` : '';
      document.cookie = `${name}=${value}; ${expires}${cpath}${domain}`;
    }
  }

  getDcCookie(): any {
    const dcCookieString = this.getCookie(AppConstants.dcCookieName);
    if (dcCookieString) {
      try {
        return JSON.parse(dcCookieString);
      } catch (e) {
        console.error('Some error occurred while parsing ' + AppConstants.dcCookieName);
      }
    }
    return null;
  }

  getUuidFromCookie(): string {
    const dcCookieObject = this.getDcCookie();
    return dcCookieObject?.uuid ? dcCookieObject.uuid : '';
  }

  isAuthUser(): boolean {
    const dcCookieObject = this.getDcCookie();
    return dcCookieObject && dcCookieObject.isGuest === false;
  }

  isGuestUser(): boolean {
    return !this.isAuthUser();
  }

  setDcCookie(uuid: string, isGuest: boolean): void {
    const dcCookieObject = {
      uuid,
      isGuest
    };
    isGuest ? this.setCookie(AppConstants.dcCookieName, JSON.stringify(dcCookieObject), 90) : this.setCookie(AppConstants.dcCookieName, JSON.stringify(dcCookieObject));
  }
  setCSRDcCookie(uuid: string, isGuest: boolean, isWriteEnabledForCSR: boolean, isCSRLogin: boolean): void {
    const dcCookieObject = {
      uuid,
      isGuest,
      isWriteEnabledForCSR,
      isCSRLogin
    };
    isGuest ? this.setCookie(AppConstants.dcCookieName, JSON.stringify(dcCookieObject), 90) : this.setCookie(AppConstants.dcCookieName, JSON.stringify(dcCookieObject));
  }

  getCSRUUIDFromCookie(): string {
    const csrCookieString = this.getCookie(AppConstants.dgcCsrCookieName);
    let csruuid = '';

    if (csrCookieString) {
      try {
        const dgcCsrCookieObject = JSON.parse(csrCookieString);
        csruuid = dgcCsrCookieObject.uuid ? dgcCsrCookieObject.uuid : '';

      } catch (e) {
        console.log('Some error occurred while parsing dgccsrCookie');
        return '';
      }
    }
    return csruuid;
  }

  setLocationSessionCookie(countymodalobject: County, planYear: string, zipcode: string): void {
    let locationSessionCookie = '<zip_val>,<state_val>,<county_val>,FIPS,<county_name>,<cms_Code>,<cms_Name>,<cmsCodeList>,<plan_year>';

    let fipscode = countymodalobject ? countymodalobject.fipsCountyCode : '';
    if (fipscode && fipscode !== '') {
        fipscode = this.locationService.formatFipsCode(fipscode);
    }

    if (zipcode && zipcode !== '') {
        zipcode = this.locationService.formatZipCode(zipcode);
    }

    locationSessionCookie = locationSessionCookie.replace('<zip_val>', zipcode);
    locationSessionCookie = locationSessionCookie.replace('<state_val>', countymodalobject ? countymodalobject.stateCode : '');
    locationSessionCookie = locationSessionCookie.replace('<county_val>', fipscode);
    locationSessionCookie = locationSessionCookie.replace('<county_name>', countymodalobject ? countymodalobject.fipsCountyName : '');

    locationSessionCookie = locationSessionCookie.replace('<cms_Code>', countymodalobject ? countymodalobject.cmscode : '');
    locationSessionCookie = locationSessionCookie.replace('<cms_Name>', countymodalobject ? countymodalobject.cmsname : '');

    let cmscodelist = countymodalobject ? countymodalobject.cmsCountyCodes.toString() : '';

    if (countymodalobject && countymodalobject.cmsCountyCodes.length > 1 && typeof(cmscodelist) === 'object') {
      cmscodelist = countymodalobject.cmsCountyCodes[0];
    }

    locationSessionCookie = locationSessionCookie.replace('<cmsCodeList>', cmscodelist);
    locationSessionCookie = locationSessionCookie.replace('<plan_year>', planYear);

    this.setCookie(AppConstants.locationSessionCookie, locationSessionCookie);
  }

  getLocationSessionCookie(): any {
    const locationSessionCookieString = this.getCookie(AppConstants.locationSessionCookie);

    if (locationSessionCookieString && locationSessionCookieString !== '') {
      const zipcookieclass = locationSessionCookieString.split(',');
      return {
          zipcode     : zipcookieclass[0],
          statecode   : zipcookieclass[1],
          fipscode    : zipcookieclass[2],
          fipsname    : zipcookieclass[4],
          cmscode     : zipcookieclass[5],
          cmsname     : zipcookieclass[6],
          cmscodelist : zipcookieclass[7],
          planyear    : zipcookieclass[8]
      };
    }
    return null;
  }

  setDCEInitialCookie(siteCode: string, countymodalobject: any, planobject: Plan): void {
    let planInformationCookie = '<zipcode>,<statecode>,<fipcode>,<planyear>,<producttype>,<brandid>,<contractId>,<pbpNumber>,<toPage>,<cmscode>,<cmsname>,<cmscodelist>,<isUsOtherTerritories>';

    const toPageParam = 'toPage = default';
    let fipscode = countymodalobject ? countymodalobject.fipscode : '';

    if (fipscode && fipscode !== '') {
        fipscode = this.locationService.formatFipsCode(fipscode);
    }

    let zipcode = countymodalobject ? countymodalobject.zipcode : '';
    if (zipcode && zipcode !== '') {
        zipcode = this.locationService.formatZipCode(zipcode);
    }

    planInformationCookie = planInformationCookie.replace('<zipcode>', zipcode);
    planInformationCookie = planInformationCookie.replace('<statecode>', countymodalobject ? countymodalobject.statecode : '');
    planInformationCookie = planInformationCookie.replace('<fipcode>', fipscode);

    planInformationCookie = planInformationCookie.replace('<planyear>', planobject.planYear);
    planInformationCookie = planInformationCookie.replace('<producttype>', planobject.planType);
    planInformationCookie = planInformationCookie.replace('<contractId>', planobject.planId.substring(0, 5));

    planInformationCookie = planInformationCookie.replace('<brandid>', siteCode);
    planInformationCookie = planInformationCookie.replace('<pbpNumber>', planobject.planId.substring(5, 8));
    planInformationCookie = planInformationCookie.replace('<toPage>', toPageParam);

    planInformationCookie = planInformationCookie.replace('<cmscode>', countymodalobject ? countymodalobject.cmscode : '');
    planInformationCookie = planInformationCookie.replace('<cmsname>', countymodalobject ? countymodalobject.cmsname : '');
    planInformationCookie = planInformationCookie.replace('<cmscodelist>', countymodalobject ? countymodalobject.cmscodelist : '');
    planInformationCookie = planInformationCookie.replace('<isUsOtherTerritories>', this.locationService.isUSOtherTerritory(countymodalobject.statecode).toString());

    this.setCookie(AppConstants.planInformationCookie, planInformationCookie);
  }

  getRxVisitorCookie(): string {
    const visitorCookieString = this.getCookie(AppConstants.rxVisitor);
    if (visitorCookieString) {
      return visitorCookieString;
    }
    return '';
  }

}
