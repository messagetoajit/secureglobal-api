import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, ReplaySubject } from 'rxjs';

import { Provider } from '../models/Provider';
import { CookieService } from './cookie.service';
import { DTMService } from './dtm.service';
import { AppData } from '../models/AppData';
import { ProviderSearchJson } from '../models/ProviderSearchJson';
import { Plan } from '../models/Plan';
import { AppConstants } from '../constants/app-constants';
import { StorageService } from './storage.service';
import { DCEConstants } from '../constants/dce-constants';
import { ProvidersDetails } from '../models/ProvidersDetails';
import { UserProfile } from '../models/UserProfile';
import { UserinfoService } from './userinfo.service';

declare var setFlyoutContents: any;
declare var acqContextData: any;

const noCacheHttpOptions = {
  headers: new HttpHeaders({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    // tslint:disable-next-line:object-literal-key-quotes
    'Pragma': 'no-cache',
    // tslint:disable-next-line:object-literal-key-quotes
    'Expires': 'Sat, 01 Jan 2000 00:00:00 GMT',
    'If-Modified-Since': '0'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class ProviderService {

  private rallyProviderSearch = new ReplaySubject(2);
  private providersDataLoading = new ReplaySubject(2);
  private providerInterval;

  constructor(
    private readonly http: HttpClient,
    private readonly cookieService: CookieService,
    private readonly dtmService: DTMService,
    private readonly storageService: StorageService,
    private readonly userinfoService: UserinfoService
  ) { }

  getProvidersDataLoadingNotification(): Observable<any> {
    return this.providersDataLoading.asObservable();
  }

  getRallyProviderSearchNotification(): Observable<any> {
    return this.rallyProviderSearch.asObservable();
  }

  resetRallyProviderSearchSubject() {
    this.rallyProviderSearch = new ReplaySubject(2);
  }

  getProviders(): Observable<Provider[]> {
    const providersURL = 'content/dam/dashboard-data/providers.json';
    return this.http.get<Provider[]>(providersURL);
  }

  deleteProviderFromCookie(provider: Provider, appData: AppData) {
    try {
      const providerCookieString = this.storageService.getItem_LS(AppConstants.providerKey, false);

      if (providerCookieString) {
        const providerDataObj = JSON.parse(providerCookieString);
        let providerDeleted = false;

        if (providerDataObj && providerDataObj.providerIdList && providerDataObj.providerIdList.length > 0) {
          const providersListLength =  providerDataObj.providerIdList.length;

          providerDataObj.providerIdList = providerDataObj.providerIdList.filter((p: Provider) => (p.providerId !== provider.providerId && p.providerAddressId !== provider.providerAddressId));
          providerDeleted = providersListLength > providerDataObj.providerIdList.length ? true : false;

          if (providerDataObj.providerIdList.length === 0) {
            this.storageService.removeItem_LS(AppConstants.providerKey, false);

          } else if (providerDeleted) {
            providerDataObj.TotalProviders = providerDataObj.providerIdList.length;
            providerDataObj.ZipCode = appData.profileDetails.providersDetails.zipCode ? appData.profileDetails.providersDetails.zipCode  : appData.profileDetails.plansDetails.zipCode ? appData.profileDetails.plansDetails.zipCode : JSON.parse(providerCookieString).Zipcode;
            providerDataObj.Products.forEach(product => {
              product.ProviderCount = providerDataObj.TotalProviders;
            });

            this.storageService.setItem_LS(AppConstants.providerKey, JSON.stringify(providerDataObj), false);
          }
        }
      }

    } catch (e) {
      console.log('Some error occurred while deleting provider from cookie.');
    }
  }

  setProvidersDetails(appData: AppData, providersDataExists: boolean): any {
    if (appData.profileDetails.providersDetails
      && appData.profileDetails.providersDetails.providerIdList
      && appData.profileDetails.providersDetails.providerIdList.length > 0) {

      providersDataExists = true;
      const providerIdList = appData.profileDetails.providersDetails.providerIdList.map(p => p.providerId).join('|');
      this.dtmService.setDTMData({visitorProfile: {providers: providerIdList}});

      if (!appData.plansDataExists && typeof setFlyoutContents === 'function') {
        setFlyoutContents(true);
      }

      this.setProvidersDataInBrowserStorage(appData);

    } else {
      providersDataExists = false;
      this.dtmService.setDTMData({visitorProfile: {providers: ''}});

      if (!appData.plansDataExists && appData.drugsAndPharmacyDataExists && typeof setFlyoutContents === 'function') {
        setFlyoutContents(true);
      } else if (!appData.plansDataExists && !appData.drugsAndPharmacyDataExists && !appData.medSuppPlansDataExists && typeof setFlyoutContents === 'function') {
        setFlyoutContents(false);
      }
    }

    return {appData, providersDataExists};
  }

  getFipsStateCode(zipCode: string){
    const fipsStateCodeUrl = DCEConstants.geoLocationBaseURI + DCEConstants.geoLocationCountiesURI + '/' + zipCode;
    return this.http.get<any>(fipsStateCodeUrl, noCacheHttpOptions);
  }

  searchProvider(appData: AppData, plan: Plan) {
    this.resetRallyProviderSearchSubject();
    this.setProvidersDataInBrowserStorage(appData);
    this.storageService.removeItem_LS(AppConstants.providerKey, false);

    this.providerInterval = setInterval(() => { this.refreshScopeListener(appData); }, 2000);

    if (plan?.county?.fipsStateCode) {
      this.postProviderDataToRally(appData, plan);

    } else {
      this.getFipsStateCode(plan.zipCode).subscribe((response: any) => {
        if (response?.data?.counties[0]) {
          plan.county.fipsStateCode = response.data.counties[0].fipsStateCode;
          console.log('fipsStateCode :: [' + plan.county.fipsStateCode + ']');

          this.postProviderDataToRally(appData, plan);

        } else {
          console.log('No counties found for ');
        }

      }, (error) => {
        console.log('Some error occurred while fetching counties by zipcode');
        console.log(error);
      });
    }
  }

  postProviderDataToRally(appData: AppData, plan: Plan) {
    const providerjson =  new ProviderSearchJson();
    providerjson.client = 'UHCMS1';
    providerjson.userGroup = 'VPP';
    providerjson.targetURL = encodeURIComponent(`${location.origin}/ProviderSearchWAR/providersearch/rallyConnect`);
    providerjson.clientProdCode = `${plan.planId}`;
    providerjson.fipsCode = `${plan.county.fipsStateCode}${plan.county.fipsCountyCode}`;
    providerjson.psc = this.cookieService.getCookie('persistentCampaignIDCookie') || '';
    providerjson.year = plan.planYear;
    providerjson.zip = plan.zipCode;
    providerjson.ProviderIdList = [];

    if (this.isProviderDataExists(appData)) {
      providerjson.ProviderIdList = appData.profileDetails.providersDetails.providerIdList
        .filter(p => p.providerId && p.providerAddressId)
        .map(p => {
          return {providerId: p.providerId, providerAddressId: p.providerAddressId};
        });
    }

    console.log('Provider data sent to Rally -> ');
    console.log(providerjson);

    // "{"client":"UHCMS1","zip":"90210","fipsCode":"06037","year":"2019","clientProdCode":"H0543121002","userGroup":"VPP","psc":"810027","targetURL":"https%3A%2F%2Fwww.stage-aarpmedicareplans.uhc.com%2FMRRestWARAcq%2Frest%2FrallyConnect"}"
    let rallyDomain = 'https://connect.werally.com';
    if (typeof acqContextData === 'object') {
      rallyDomain = acqContextData.get('runmode') === 'prod' ? rallyDomain : 'https://connect.int.werally.in';
    }
    const form: any = document.createElement('FORM');
    form.method = 'POST';
    form.action = `${rallyDomain}/rest/user/v1/guest/acquisition/providerCoverage/`;
    const input: any = document.createElement('INPUT');
    input.name = 'json';
    input.type = 'hidden';
    form.target = '_blank';
    input.value = JSON.stringify(providerjson);
    form.appendChild(input);
    document.body.appendChild(form);
    form.submit();
  }

  setProvidersDataInBrowserStorage(appData: AppData) {
    try {
      if (this.isProviderDataExists(appData)) {
        const providerDataString = this.storageService.getItem_LS(AppConstants.providerKey, false);
        const zipcode = (appData.profileDetails.providersDetails && appData.profileDetails.providersDetails.zipCode) ? appData.profileDetails.providersDetails.zipCode :
                        (appData.profileDetails.plansDetails && appData.profileDetails.plansDetails.zipCode) ? appData.profileDetails.plansDetails.zipCode :
                        (providerDataString && JSON.parse(providerDataString)) ? JSON.parse(providerDataString).Zipcode : null;

        const products = appData.planSearchResultsList.filter( val => val.mapsPlanType !== 'PDP').map(val => {
          const count =  appData.profileDetails.providersDetails.providerIdList.reduce((accumulator, list) => accumulator += list.plansList.indexOf(val.planId) > -1 ? 1 : 0, 0);
          return {ClientProdCode: val.planId, ProviderCount: count.toString()};
        });

        const providerCookieobj = {
          ZipCode: zipcode,
          TotalProviders: (appData.profileDetails.providersDetails.providerIdList.length).toString(),
          providerIdList: appData.profileDetails.providersDetails.providerIdList,
          Products: products
        };

        // if (appData.profileDetails.plansDetails || this.isZipCodeExists(appData)) {
        this.storageService.setItem_LS(AppConstants.providerKey, JSON.stringify(providerCookieobj), false);
        // }

      } else {
        this.storageService.removeItem_LS(AppConstants.providerKey, false);
      }
      this.providersDataLoading.next({dataLoadComplete: true});

    } catch (e) {
      console.log('Some error occurred while setting providers data in browser storage.');
      this.providersDataLoading.next({dataLoadComplete: true});
    }
  }

  refreshScopeListener(appData: AppData) {
    console.log('Scanning for Rally provider(s) data...');

    const rallyProvidersDataString = this.storageService.getItem_LS(AppConstants.providerKey, false);

    if (rallyProvidersDataString) {
      try {
        clearInterval(this.providerInterval);

        console.log('Rally provider(s) data captured');

        const rallyProvidersData: any = JSON.parse(rallyProvidersDataString);
        const providersDetails: ProvidersDetails = {zipCode: null, providerIdList: null};

        console.log(rallyProvidersData);

        if (this.isProviderDataExists(appData) && rallyProvidersData && rallyProvidersData.providerIdList
          && rallyProvidersData.ZipCode && appData.profileDetails.providersDetails.zipCode === rallyProvidersData.ZipCode) {
          console.log('User exists & zipcode matched');
          /* If both Rally providers & remaining User providers exists, then assign Rally providers to user providers */
          appData.profileDetails.providersDetails.providerIdList = [...rallyProvidersData.providerIdList];

        } else {
          console.log('Either User Providers does not exists or zipcode not matched');
          /* Else, make users provider details empty */
          appData.profileDetails.providersDetails = {...providersDetails};
        }
        console.log(appData.profileDetails.providersDetails);

        /* If Rally Providers exists */
        if (this.isRallyProvidersExists(rallyProvidersData)) {
          console.log('Rally Providers exists block');
          appData.profileDetails.providersDetails.zipCode = rallyProvidersData.ZipCode;

          /* If user providers doesn't exists, then assign all rally providers to user */
          if (!this.isProviderDataExists(appData)) {
            console.log('User Providers does not exists');
            appData.profileDetails.providersDetails.providerIdList = [...rallyProvidersData.providerIdList];
          }
          console.log(appData.profileDetails.providersDetails);

          /* Set providersDataExists flag & set providers data in localStorage */
          appData.providersDataExists = appData.profileDetails.providersDetails && appData.profileDetails.providersDetails.providerIdList.length > 0 ? true : false;
          this.setProvidersDataInBrowserStorage(appData);

          /**** Store updated providers data in DB ****/
          this.userinfoService.updateProfileData(appData.profileDetails.uuid, 'providers', this.getUpdatedProvidersData(appData)).subscribe((response: any) => {
            this.userinfoService.getProfileData(appData.profileDetails.uuid, 'providers', '').subscribe((data: UserProfile) => {

              appData.profileDetails.providersDetails = data.providersDetails;
              this.rallyProviderSearch.next({providerSearchComplete: true});

            }, (error1) => console.log(error1));
          }, (error) => console.log(error));
        }

      } catch (e) {
        console.log('Error occurred in method listening to Rally window');
        console.log(e);
      }
    }
  }

  isProviderDataExists(appData: AppData): boolean {
    return appData?.profileDetails?.providersDetails?.providerIdList?.length > 0;
  }

  isRallyProvidersExists(rallyProvidersData: any): boolean {
    return rallyProvidersData?.providerIdList?.length > 0;
  }

  getUpdatedProvidersData(appData: AppData): any {
    const isGuestUser = this.cookieService.isGuestUser();
    return {
      providersDetails: appData.profileDetails.providersDetails,
      isGuest: isGuestUser
    };
  }

  isZipCodeExists(appData: AppData) {
    return appData?.profileDetails?.userDetails?.zipCode;
  }

  getCoveredProvidersCount(plan: Plan, providerIdList: any) {
    return providerIdList.reduce((accumulator, list) => accumulator += list.plansList.indexOf(plan.planId) > -1 ? 1 : 0, 0);
  }

}
