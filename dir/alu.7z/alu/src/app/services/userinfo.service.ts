import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { DigitalCheckoutConstants } from '../constants/digital-checkout-constants';
import { UserProfile } from '../models/UserProfile';
import { CookieService } from './cookie.service';
import { AppConstants } from '../constants/app-constants';
import { StorageService } from './storage.service';
import { UserDataContextService } from './user-data-context.service';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
  withCredentials: true
};

const noCacheHttpOptions = {
  headers: new HttpHeaders({
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    // tslint:disable-next-line:object-literal-key-quotes
    'Pragma': 'no-cache',
    // tslint:disable-next-line:object-literal-key-quotes
    'Expires': 'Sat, 01 Jan 2000 00:00:00 GMT',
    'If-Modified-Since': '0'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class UserinfoService {

  constructor(
    private readonly httpClient: HttpClient,
    private readonly cookieService: CookieService,
    private readonly storageService: StorageService,
    private readonly userDataContextService: UserDataContextService
  ) { }

  authValidate(authValidateInputRequestData: any) {
    const url = DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.authValidateURL;
    return this.httpClient.post<any>(url, authValidateInputRequestData, httpOptions);
  }

  getUserInfo() {
    const url = DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.userDetailsURL;
    return this.httpClient.get(url, noCacheHttpOptions);
  }

  getProfileData(uuid: string, entity: string, year: string, validateTempProfiles: boolean = false): Observable<UserProfile> {
    const csruuid = this.cookieService.getCSRUUIDFromCookie();
    const queryParams = (csruuid && csruuid !== '') ? ('?csrUUID=' + csruuid) : '';
    const checkTempProfiles = (entity && entity === 'all') ?  ('/' + validateTempProfiles) : '';
    const url =  DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.userDataURL + '/' + uuid + '/' + entity + '/' + year + checkTempProfiles + queryParams;
    return this.httpClient.get<UserProfile>(url, noCacheHttpOptions);
  }

  updateProfileData(uuid: string, entity: string, updatedData: any, year: string = '') {
    const url = DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.userDataURL + '/' + uuid + '/' + entity + '/' + year;
    return this.httpClient.post<any>(url, updatedData, httpOptions);
  }

  deleteProfileData(uuid: string, entity: string, year: string, id: string = '') {
    const url = DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.userDataURL + '/' + uuid + '/' + entity + '/' + year + '/' + id;
    return this.httpClient.delete<any>(url, httpOptions);
  }

  logout() {
    const url =  DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.logoutURL;
    return this.httpClient.delete(url, {withCredentials: true});
  }

  deleteBrowserStorage() {
    this.storageService.removeItem_LS(AppConstants.providerKey, false);
    this.storageService.removeItem_LS(this.storageService.getItem_SS(AppConstants.vppZipcode));
    this.storageService.removeItem_LS(this.storageService.getItem_SS(AppConstants.geotrackingZip));

    this.storageService.removeItem_SS(AppConstants.agentProfileData);
    this.storageService.removeItem_SS(AppConstants.vppZipcode);
    this.storageService.removeItem_SS(AppConstants.geotrackingZip);
    this.storageService.removeItem_SS(AppConstants.profileUserChatData);
    this.storageService.removeItem_SS(AppConstants.isProfileDataImported);
    this.userDataContextService.removeDrugStorage();

    this.cookieService.deleteCookie(AppConstants.dcCookieName);
    this.cookieService.deleteCookie(AppConstants.dgcCsrCookieName);
    this.cookieService.deleteCookie(AppConstants.tfnSessionCookie);
    this.cookieService.deleteCookie(AppConstants.vppSourceTFNInfo);
  }

  saveCSRUserActions(saveCsrActionRequest: any) {
    const url = DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.savecsrUserActionsURL;
    return this.httpClient.post<any>(url, saveCsrActionRequest, httpOptions);
  }

  updateProfile(requestData: any) {
    const url = DigitalCheckoutConstants.baseURI + DigitalCheckoutConstants.updateProfileURL;
    return this.httpClient.post<any>(url, requestData, httpOptions);
  }

}
