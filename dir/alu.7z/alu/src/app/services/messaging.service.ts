import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UUID } from 'angular2-uuid';

import { CookieService } from '../services/cookie.service';
import { UtilityService } from '../services/utility.service';

import { MessagingConstants } from '../constants/messaging-constants';
import { ShopperProfileConstants } from '../constants/shopper-profile-constants';
import { ProfileActionDetails } from '../models/ProfileActionDetails';
import { AppData } from '../models/AppData';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class MessagingService {

  constructor(
    private readonly httpClient: HttpClient,
    private readonly cookieService: CookieService,
    private readonly utilityService: UtilityService
  ) {}

  trackProfileActions(action: string, event: string): void {
    if (action && event) {
      const profileActionDetails = new ProfileActionDetails();

      profileActionDetails.event_name = 'AMP # optumIdProfile - ' + event;
      profileActionDetails.profile_action = action;

      this.sendProfileActionsToKafka(profileActionDetails, null).subscribe((response) => {
        console.log(response);
      }, (errorResponse) => {
        console.log('Some error occurred while sending data to Kafka Proxy.');
      });
    }
  }

  trackProfileItems(action: string, event: string, appData: AppData): void {
    try {
      const enrolledPlansCount = this.getEnrolledPlansCount(appData);
      const trackingData = {
        planCount                 : appData?.profileDetails?.plansDetails?.plans?.length ?? 0,
        drugCount                 : appData?.profileDetails?.drugsAndPharmacyDetails?.drugInfoDetails?.length ?? 0,
        providerCount             : appData?.profileDetails?.providersDetails?.providerIdList?.length ?? 0,
        pharmacy                  : appData?.profileDetails?.drugsAndPharmacyDetails?.pharmacyObj?.pharmacyNumber ? true : false,
        savedEnrollmentCount      : enrolledPlansCount ? enrolledPlansCount.savedEnrollments : null,
        submittedEnrollmentCount  : enrolledPlansCount ? enrolledPlansCount.submittedEnrollments : null,
        optumId                   : appData?.profileDetails?.userDetails?.optumId ? true : false
      };

      if (action && event) {
        const profileActionDetails = new ProfileActionDetails();
        profileActionDetails.event_name = 'AMP # shopperProfile - ' + event;
        profileActionDetails.profile_action = action;
        profileActionDetails.agent_name = appData?.agentUserName;

        this.sendProfileActionsToKafka(profileActionDetails, trackingData).subscribe((response) => {
          this.utilityService.goToVppPage();
        }, (errorResponse) => {
          console.log('Some error occurred while sending profile action to kafka in trackProfileItems()');
          this.utilityService.goToVppPage();
        });
      }
    } catch (e) {
      console.log('Some error occurred in trackProfileItems()');
      this.utilityService.goToVppPage();
    }
  }

  private sendProfileActionsToKafka(profileActionDetails: any, trackingData: any) {
    const requestData = this.buildKafkaProxyRequestData(profileActionDetails, trackingData);

    const url = ShopperProfileConstants.baseURI + ShopperProfileConstants.trackProfile;
    return this.httpClient.post<any>(url, JSON.stringify(requestData), httpOptions);
  }

  private getEnrolledPlansCount(appData: AppData) {
    let savedEnrollmentsCount = 0;
    let submittedEnrollmentsCount = 0;

    try {
      const enrollments = appData?.profileDetails?.enrollmentsDetails?.enrollments;
      if (enrollments && enrollments.length > 0) {
        enrollments.forEach((enrollment: any) => {
          (enrollment && enrollment.isSubmitted === true) ? submittedEnrollmentsCount++ : savedEnrollmentsCount++;
        });
      }
    } catch (e) {
      console.log('Some error occurred in getSavedSubmittedApps()');
    }
    return { savedEnrollments: savedEnrollmentsCount, submittedEnrollments: submittedEnrollmentsCount };
  }

  private buildKafkaProxyRequestData(profileActionDetails: any, trackingData: any): any{
    const env = this.getCurrentEnvironment();
    const topic = this.getKafkaTopicByEnvironment();

    const messageData: any = {
      event_type      : MessagingConstants.business_event,
      event_name      : profileActionDetails.event_name,
      event_timestamp : new Date().getTime(),
      event_uuid      : UUID.UUID(),                                      // system generated uuid for this event (not user uuid)
      app_name        : `${env} - ${location.host}`,
      data            : {
        user_tracking_system  : MessagingConstants.user_tracking_system,
        internalUserId        : this.cookieService.getRxVisitorCookie(),  // tracking system session id
        profile_action        : profileActionDetails.profile_action,
        ...{trackingData}
       }
    };
    if (trackingData ){
      messageData.data = {
        user_tracking_system  : MessagingConstants.user_tracking_system,
        internalUserId        : this.cookieService.getRxVisitorCookie(),
        agent_action          : profileActionDetails.profile_action,
        agent_name            : profileActionDetails.agent_name,
        ...trackingData
      };
    }

    return {
      message     : JSON.stringify(messageData),
      producerCn  : MessagingConstants.kafka_producer_cn,
      topic
    };
  }

  private getCurrentEnvironment(): string {
    if (location.host === 'www.aarpmedicareplans.com' || location.host === 'www.uhcmedicaresolutions.com') {
     return 'Online';
    } else if (location.host.indexOf('offline.') > -1) {
      return 'Offline';
    } else if (location.host.indexOf('offline-') > -1) {
      return 'Offline Stage';
    } else if (location.host.indexOf('stage') > -1) {
      return 'Stage';
    } else if (location.host.indexOf('.optum.com') > -1 || this.utilityService.isLocalHost()) {
      return 'Dev';
    }
    return '';
  }

  private getKafkaTopicByEnvironment(): string {
    if (location.host.indexOf('offline.') > -1 || location.host === 'www.aarpmedicareplans.com' || location.host === 'www.uhcmedicaresolutions.com') {
      return MessagingConstants.kafka_topic_prod;
    } else if (location.host.indexOf('stage') > -1) {
      return MessagingConstants.kafka_topic_stage;
    } else {
      return MessagingConstants.kafka_topic_test;
    }
    return '';
  }

  trackDataImportActions(profileActionDetails: ProfileActionDetails): void {
    if (profileActionDetails) {
      this.sendDataImportActionsToKafka(profileActionDetails).subscribe((response) => {
        console.log(response);
      }, (errorResponse) => {
        console.log('Some error occurred while sending data import actions to Kafka Proxy.');
      });
    }
  }

  private sendDataImportActionsToKafka(profileActionDetails: ProfileActionDetails) {
    const requestData = this.buildDataImportActionsKafkaRequest(profileActionDetails);
    const url = ShopperProfileConstants.baseURI + ShopperProfileConstants.trackProfile;

    return this.httpClient.post<any>(url, JSON.stringify(requestData), httpOptions);
  }

  private buildDataImportActionsKafkaRequest(profileActionDetails: ProfileActionDetails): any{
    const env = this.getCurrentEnvironment();
    const topic = this.getKafkaTopicByEnvironment();

    const messageData: any = {
      event_type      : MessagingConstants.business_event,
      event_name      : profileActionDetails.event_name,
      event_timestamp : new Date().getTime(),
      event_uuid      : UUID.UUID(),                                      // system generated uuid for this event (not user uuid)
      app_name        : `${env} - ${location.host}`,
      data            : {
        user_tracking_system  : MessagingConstants.user_tracking_system,
        internalUserId        : this.cookieService.getRxVisitorCookie(),  // tracking system session id
        user_uuid             : profileActionDetails.user_id,
        user_fullname         : profileActionDetails.user_fullname,
        profile_action        : profileActionDetails.profile_action,
        drugs_imported        : profileActionDetails.drugs_imported,
        providers_imported    : profileActionDetails.providers_imported
       }
    };

    return {
      message     : JSON.stringify(messageData),
      producerCn  : MessagingConstants.kafka_producer_cn,
      topic
    };
  }

  createAndSendDomoMessage(uuid: string, eventType: string) {
    const requestData = {
      uuid,
      eventType,
      eventTimestamp: new Date().getTime()
    };

    this.sendDomoMessage(requestData).subscribe((response) => {
      console.log('DOMO Response : ', response);
    }, (errorResponse) => {
      console.log('Some error occurred while sending DOMO Message.');
    });
  }

  sendDomoMessage(requestData: any) {
    const url = ShopperProfileConstants.baseURI + ShopperProfileConstants.domoMessagingURL;
    return this.httpClient.post<any>(url, JSON.stringify(requestData), httpOptions);
  }

}
