import { UserinfoService } from "./userinfo.service";
import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';


describe('UserInfoService', () => {
    let service: UserinfoService;
    let httpMock: HttpTestingController;

    beforeEach(() => {
      TestBed.configureTestingModule({
          imports: [HttpClientTestingModule],
          providers: [UserinfoService]
      });
      service = TestBed.inject(UserinfoService);
      httpMock = TestBed.inject(HttpTestingController);

    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('authValidate', () => {
        service.authValidate({});
    })

    it('getUserInfo', () => {
        service.getUserInfo();
    })

    it('getProfileData', () => {
        service.getProfileData('uuid','entity','2021');
    })

    it('updateProfileData', () => {
        service.updateProfileData('uuid','entity','updateData','2021');
    });

    it('deleteProfileData', () => {
        service.deleteProfileData('uuid','entity','2021');
    });

    it('logout', () => {
        service.logout();
    });

    it('deleteBrowserStorage', () => {
        service.deleteBrowserStorage();
    });

    it('saveCSRUserActions', () => {
        service.saveCSRUserActions({});
    });

    it('updateProfile', () => {
        service.updateProfile({});
    });





});