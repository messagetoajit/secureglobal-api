import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ShopperProfileConstants } from '../constants/shopper-profile-constants';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json',
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class ShopperProfileService {

  constructor(private readonly http: HttpClient) { }

  getOLEApplicationStatus(requestData: any): Observable<any> {
    const url = ShopperProfileConstants.baseURI + ShopperProfileConstants.oleApplicationsStatus;
    return this.http.post<any>(url, JSON.stringify(requestData), httpOptions);
  }

  importShopperItems(requestData: any) {
    const url = ShopperProfileConstants.baseURI + ShopperProfileConstants.importShopperItemsURL ;
    return this.http.post<any>(url, requestData, httpOptions);
  }

}
