import { TestBed } from "@angular/core/testing";
import { CookieService } from "./cookie.service";

describe('CookieService', () => {
    let service: CookieService;
  
    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [
          CookieService
        ]
      });
      service = TestBed.get(CookieService);
    });
  
    it('should be created', () => {
      expect(service).toBeTruthy();
    });

    it('get cookie', () => {
        document.cookie = 'test=123';
        var val = service.getCookie('test');
        expect(val).toEqual('123');
    })

    it('set cookie', () => {
        var val = service.setCookie('test', '123');
        expect(service.getCookie('test')).toEqual('123');
    })

    it('set cookie with expire', () => {
        var val = service.setCookie('test', '123', 200);
        expect(service.getCookie('test')).toEqual('123');
    })

    it('delete cookie', () => {
        var val = service.deleteCookie('test');
        expect(service.getCookie('test')).toEqual('');
    })

    it('get dccookie', () => {
        document.cookie = 'dcCookie={"uuid":"123"}';
        var val = service.getDcCookie();
        expect(val).toBeTruthy();
        expect(val.uuid).toEqual('123');
    })

    it('get uuid from cookie', () => {
        document.cookie = 'dcCookie={"uuid":"123"}';
        var val = service.getUuidFromCookie();
        expect(val).toEqual('123');
    })


});