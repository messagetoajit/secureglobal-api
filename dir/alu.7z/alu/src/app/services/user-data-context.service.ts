import { Injectable } from '@angular/core';

declare var UserContextService: any;

@Injectable({
  providedIn: 'root'
})
export class UserDataContextService {

  userContextServiceExists = false;

  constructor() {
    if (typeof UserContextService !== 'undefined' && UserContextService) {
      this.userContextServiceExists = true;
    } else {
      console.log('User context service not found');
    }
  }

  getDrugStorageData() {
    if (this.userContextServiceExists) {
      return UserContextService?.getData(UserContextService.DRUG_LIST);
    } else {
      console.log('User context service not found to get drugs data');
    }
  }

  setDrugStorageData(data: any) {
    if (this.userContextServiceExists) {
      return UserContextService?.setData(UserContextService.DRUG_LIST, data);
    } else {
      console.log('User context service not found to set drugs data');
    }
  }

  removeDrugStorage() {
    if (this.userContextServiceExists) {
      return UserContextService?.removeData(UserContextService.DRUG_LIST);
    } else {
      console.log('User context service not found to delete drugs storage');
    }
  }

}
