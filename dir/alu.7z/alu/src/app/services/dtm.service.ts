import {Injectable} from '@angular/core';
import _merge from 'lodash.merge';

@Injectable({
  providedIn: 'root'
})
export class DTMService {

  setDTMData(data: any) {
    // tslint:disable-next-line: no-string-literal
    if (window['DTMData'] === undefined) {
      // tslint:disable-next-line: no-string-literal
      window['DTMData'] = {};
    }
    // tslint:disable-next-line: no-string-literal
    _merge(window['DTMData'], data);
  }
}
