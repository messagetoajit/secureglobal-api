import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';

import { CookieService } from './cookie.service';
import { AppConstants } from '../constants/app-constants';

@Injectable()
export class AuthGuardService implements CanActivate {

  constructor(
    private readonly cookieService: CookieService,
    private readonly router: Router
  ) {}

  canActivate(): boolean {
    if (!this.cookieService.isGuestUser()) {
      setTimeout(() => { this.router.navigate(['authenticated'], AppConstants.navigationConfig); }, 100);
      return false;
    }
    return true;
  }

}
