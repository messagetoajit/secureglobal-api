import { Injectable } from '@angular/core';

import { CookieService } from './cookie.service';
import { AppConstants } from '../constants/app-constants';

@Injectable({
  providedIn: 'root'
})
export class TFNService {

  constructor(private readonly cookieService: CookieService) {}

  getAuthorTFN(): any {
    let tollfreenumber = '';
    const tfnSessionCookie = this.cookieService.getCookie(AppConstants.tfnSessionCookie);

    if (tfnSessionCookie) {
      const values = tfnSessionCookie.toString().split(',');
      tollfreenumber = (values.length >= 3) ? values[2] : '';
    }
    return tollfreenumber;
  }

}
