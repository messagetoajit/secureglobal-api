import { TestBed } from '@angular/core/testing';
import { PREService } from './pre.service';
import { AppData } from '../models/AppData';
import { UserProfile } from '../models/UserProfile';
import { PREData } from '../models/PREData';
import { AppConstants } from '../constants/app-constants';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { StorageService } from './storage.service';
import { UtilityService } from './utility.service';
import { Plan } from '../models/Plan';
import { Observable, of } from 'rxjs';

describe('PREService', () => {
  let service: PREService;
  let storageService: StorageService;
  let utilityService: UtilityService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ HttpClientTestingModule ],
      providers: [ PREService, StorageService, UtilityService ]
    });
    service = TestBed.inject(PREService);
    storageService = TestBed.inject(StorageService);
    utilityService = TestBed.inject(UtilityService);

  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  xit('test isDisplayNoOnePRERankedPlan', () => {

  });

  xit('test isPREDataExists', () => {
    let appData: AppData = null;
    expect(service.isPREDataExists(appData)).toEqual(undefined);
    appData = new AppData();
    expect(service.isPREDataExists(appData)).toEqual(undefined);
    appData.profileDetails = new UserProfile();
    expect(service.isPREDataExists(appData)).toEqual(undefined);
    appData.profileDetails.preData = new PREData();
    expect(service.isPREDataExists(appData)).toEqual(undefined);
    appData.profileDetails.preData.data = 'data';
    expect(service.isPREDataExists(appData)).toEqual('data');
  });

  it('test setPlanRecommendations', () => {
    const appData = new AppData();
    const preDataExists = false;
    expect(appData.preRecommendationType).toEqual(AppConstants.PRE_EMPTY);
    expect(service.setPlanRecommendations(appData, true)).toEqual({appData, preDataExists});
    appData.profileDetails = new UserProfile();
    appData.profileDetails.preData = new PREData();
    appData.profileDetails.preData.data = JSON.stringify({planRecommendationObj: null, planRecommendationResults: null});
    console.log = jasmine.createSpy('log');
    expect(service.setPlanRecommendations(appData, true)).toEqual({appData, preDataExists});
    expect(console.log).toHaveBeenCalledWith('PRE recommendationObj object not found.');
    expect(console.log).toHaveBeenCalledWith('PRE recommendationResults not found.');

    appData.profileDetails.preData.data = '{{}}';
    let result = service.setPlanRecommendations(appData, true);
    expect(console.log).toHaveBeenCalled();
    expect(result.preDataExists).toBeFalse();

    appData.preStorageData = {
      planRecommendationObj: 'planRecommendationObj',
      planRecommendationResults:
        [{priority: 3, planType: 'MA'},
        {priority: 1, planType: 'MA'},
        {priority: 2, planType: 'MS'}]};
    appData.profileDetails.preData.data = JSON.stringify(appData.preStorageData);
    result = service.setPlanRecommendations(appData, true);
    expect(result.appData.preRecommendationResults).toEqual([{priority: 1, planType: 'MA'}, {priority: 3, planType: 'MA'}]);
    expect(result.appData.preRecommendationType).toEqual(AppConstants.PRE_RANKED);
    expect(result.preDataExists).toBeTrue();
    expect(appData.preRecommendationObj).toEqual(appData.preStorageData.planRecommendationObj);
    expect(console.log).toHaveBeenCalled();

    spyOnProperty(service, 'isDisplayNoOnePRERankedPlan').and.returnValue(true);

  });

  it('test setPREObjectInAppData function', () => {
    const appData = new AppData();
    console.log = jasmine.createSpy('log');
    (service as any).setPREObjectInAppData(appData.preStorageData, appData, false);
    expect(console.log).toHaveBeenCalledWith('PRE recommendationObj object not found.');
    appData.preStorageData = { planRecommendationObj: 'planRecommendationObj'};
    (service as any).setPREObjectInAppData(appData.preStorageData, appData, false);
    expect(appData.preRecommendationObj).toEqual(appData.preStorageData.planRecommendationObj);
  });

  xit('test setPRENo1RankedPlanInAppData function', () => {

  });

  it('test isNo1RankedFederalPlan function', () => {
    let prePlan = null;
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toEqual(null);
    prePlan = {rank: null, planId: 'planId', planName: 'planName', compositePlanId: {planYear: 'planYear', planType: {name: 'MA'}}};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toBeFalse();
    prePlan = {rank: '1', planId: null, planName: 'planName', compositePlanId: {planYear: 'planYear', planType: {name: 'MA'}}};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toEqual(null);
    prePlan = {rank: '1', planId: 'planId', planName: null, compositePlanId: {planYear: 'planYear', planType: {name: 'MA'}}};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toEqual(null);
    prePlan = {rank: '1', planId: 'planId', planName: 'planName', compositePlanId: null};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toEqual(undefined);
    prePlan = {rank: '1', planId: 'planId', planName: 'planName', compositePlanId: {planYear: null, planType: {name: 'MA'}}};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toEqual(null);
    prePlan = {rank: '1', planId: 'planId', planName: 'planName', compositePlanId: {planYear: 'planYear', planType: {name: null}}};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toEqual(null);
    prePlan = {rank: '1', planId: 'planId', planName: 'planName', compositePlanId: {planYear: 'planYear', planType: {name: 'Name'}}};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toBeFalse();
    prePlan = {rank: '1', planId: 'planId', planName: 'planName', compositePlanId: {planYear: 'planYear', planType: {name: 'MA'}}};
    expect((service as any).isNo1RankedFederalPlan(prePlan)).toBeTrue();
  });

  it('test setPRETypeInAppData function', () => {
    const appData = new AppData();
    console.log = jasmine.createSpy('log');
    expect((service as any).setPRETypeInAppData(appData.preStorageData, appData, false)).toBeFalse();  appData.profileDetails = new UserProfile();
    expect(console.log).toHaveBeenCalledWith('PRE recommendationResults not found.');
    appData.profileDetails.preData = new PREData();
    appData.preStorageData = {
      planRecommendationObj: 'planRecommendationObj',
      planRecommendationResults:
        [{priority: 3, planType: 'MA'},
        {priority: 1, planType: 'MA'},
        {priority: 2, planType: 'MS'}]};
    expect((service as any).setPRETypeInAppData(appData.preStorageData, appData, false)).toBeTrue();
    expect(console.log).toHaveBeenCalledWith('Valid Recommendations');
    expect(console.log).toHaveBeenCalledWith([{priority: 1, planType: 'MA'}, {priority: 2, planType: 'MS'}, {priority: 3, planType: 'MA'}]);
  });

  it('test setOldPREScenarios function', () => {
    const appData = new AppData();
    let validRecommendations = [];
    (service as any).setOldPREScenarios(validRecommendations, appData);
    expect(appData.preRecommendationType).toEqual(AppConstants.PRE_NONE);

    validRecommendations =
        [{priority: 1, planType: 'MS'},
        {priority: 2, planType: 'MA'}];
    (service as any).setOldPREScenarios(validRecommendations, appData);
    expect(appData.preRecommendationResults).toEqual([{priority: 2, planType: 'MA'}]);
    expect(appData.preRecommendationType).toEqual(AppConstants.PRE_SINGLE_UNRANKED);

    validRecommendations =
        [{priority: 1, planType: 'MA'},
        {priority: 2, planType: 'MS'}];
    (service as any).setOldPREScenarios(validRecommendations, appData);
    expect(appData.preRecommendationType).toEqual(AppConstants.PRE_SINGLE);

    validRecommendations =
        [{priority: 1, planType: 'MA'},
        {priority: 2, planType: 'MS'},
        {priority: 3, planType: 'MA'}];
    (service as any).setOldPREScenarios(validRecommendations, appData);
    expect(appData.preRecommendationResults).toEqual([{priority: 1, planType: 'MA'}, {priority: 3, planType: 'MA'}]);
    expect(appData.preRecommendationType).toEqual(AppConstants.PRE_RANKED);

    validRecommendations =
        [{priority: 1, planType: 'MA'},
        {priority: 2, planType: 'MS'},
        {priority: 1, planType: 'MA'}];
    (service as any).setOldPREScenarios(validRecommendations, appData);
    expect(appData.preRecommendationResults).toEqual([{priority: 1, planType: 'MA'}, {priority: 1, planType: 'MA'}]);
    expect(appData.preRecommendationType).toEqual(AppConstants.PRE_EQUAL);
  });

  xit('test setPREDataInBrowserStorage function', () => {

  });

  it('test getPRENo1RankedPlanMonthlyPremium function', () => {
    const appData = new AppData();
    const preNo1RankedPlan = {planId: 2};
    appData.preNo1RankedPlan = new Plan();
    appData.planSearchResultsList = [{planId: 1}, {planId: 2}, {planId: 3}];
    spyOn(utilityService, 'getMonthlyPremiumValue').and.returnValue('$ 12345.0');
    service.getPRENo1RankedPlanMonthlyPremium(preNo1RankedPlan, appData);
    expect(appData.preNo1RankedPlan.details).toEqual(appData.planSearchResultsList[1]);
    expect(appData.preNo1RankedPlan.formattedMonthlyPremium).toEqual('$ 12345.0');
  });

});
