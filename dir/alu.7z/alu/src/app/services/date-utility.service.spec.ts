import { TestBed } from '@angular/core/testing';
import { DateUtilityService } from './date-utility.service';

describe('DateUtilityService', () => {
    let service: DateUtilityService;
    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [
            DateUtilityService
        ]
      });
      service = TestBed.inject(DateUtilityService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });

    it('test isSeptember function', () => {
        expect(service.isSeptember(8)).toBe(true);
        expect(service.isSeptember(7)).toBe(false);
    });

    it('test isOctober function', () => {
        expect(service.isOctober(9)).toBe(true);
        expect(service.isOctober(7)).toBe(false);
    });

    it('test isAEPPeriod function', () => {
        expect(service.isAEPPeriod(9)).toBe(true);
        expect(service.isAEPPeriod(7)).toBe(false);
    });

    it('test isBetween_Jan01_Nov30 function', () => {
        expect(service.isBetween_Jan01_Nov30(new Date('Jul 21 2020'))).toBe(true);
        expect(service.isBetween_Jan01_Nov30(new Date('Dec 3 2021'))).toBe(false);
        expect(service.isBetween_Jan01_Nov30(null)).toBe(false);
    });

    it('test isBetween_Oct15_Nov30 function', () => {
        expect(service.isBetween_Oct15_Nov30(null)).toBe(false);
        expect(service.isBetween_Oct15_Nov30(new Date('Oct 20 2020'))).toBe(true);
        expect(service.isBetween_Oct15_Nov30(new Date('Feb 23 2021'))).toBe(false);
    });

    it('test isBetween_Oct01_Oct14 function', () => {
        expect(service.isBetween_Oct01_Oct14(null)).toBe(false);
        expect(service.isBetween_Oct01_Oct14(new Date('Oct 10 2020'))).toBe(true);
        expect(service.isBetween_Oct01_Oct14(new Date('Feb 13 2021'))).toBe(false);
    });

    it('test isBetween_Oct15_Dec31 function', () => {
        expect(service.isBetween_Oct15_Dec31(null)).toBe(false);
        expect(service.isBetween_Oct15_Dec31(new Date('Oct 21 2020'))).toBe(true);
        expect(service.isBetween_Oct15_Dec31(new Date('Feb 3 2021'))).toBe(false);
    });

    it('test isBetween_Dec01_Dec31 function', () => {
        expect(service.isBetween_Dec01_Dec31(null)).toBe(false);
        expect(service.isBetween_Dec01_Dec31(new Date('Dec 21 2020'))).toBe(true);
        expect(service.isBetween_Dec01_Dec31(new Date('Feb 3 2021'))).toBe(false);
    });

});
