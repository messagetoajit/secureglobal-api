import { Injectable } from '@angular/core';
import { UUID } from 'angular2-uuid';

import { DL_EVENT_TYPE } from '../constants/datalayer-constants';
import { ProfilePage } from '../models/ProfilePage';
import { AppConstants } from '../constants/app-constants';

declare const appEventData: any;

@Injectable({
  providedIn: 'root'
})
export class DataLayerService {

  profilePage: ProfilePage = new ProfilePage();
  siteId: string;

  constructor() {
    this.siteId = location.href.indexOf(AppConstants.aarpmedicareplans) > -1 ? AppConstants.AMP : AppConstants.UMS;
  }

  setDLClickEvent(event: any, eventType: any, selectedOption?: any, assetContainer?: string) {
    try {
      const dtlClickContent = eventType === DL_EVENT_TYPE.BUTTON_CLICK
        ? this.profilePage?.containerbuttonjsondata
        : this.profilePage?.containerlinkjsondata;
      const dlObj = dtlClickContent ? JSON.parse(dtlClickContent) : undefined;

      if (appEventData && dlObj && dlObj?.enableAnalyticsData === 'true') {
        const dataStore = this.generateDLDataStoreFromEvent(event, dlObj, DL_EVENT_TYPE.LINK_CLICK, assetContainer);

        if (selectedOption) {
          dataStore['selectedOptions'] = selectedOption;
        }

        appEventData.push(dataStore);
      }

    } catch (ex) {
      console.log('DL Click Event :: Exception processing click event action', ex);
    }
  }

  setDLPageLoadEvent(profilePage: any, previousPage?: string, profileObject?: any) {
    try {
      this.profilePage = profilePage;
      const dtlPageLoadContent = this.profilePage?.containerpagejsondata;
      const dlObj = dtlPageLoadContent ? JSON.parse(dtlPageLoadContent) : undefined;

      if (appEventData && dlObj && dlObj?.enableAnalyticsData === 'true') {
        const dataStore = this.generateDLDataStore(undefined, undefined, dlObj, DL_EVENT_TYPE.PAGE_LOAD);
        if (previousPage) {
          dataStore['previousPage'] = previousPage;
        }
        if (profileObject) {
          dataStore['vpOptions'] = profileObject;
        }

        appEventData.push(dataStore);
      }

    } catch (ex) {
      console.log('DL Page Load Event :: Exception processing page load event action', ex);
    }
  }

  setDLModalDataEvent(assetId: any, modalName: string, event?: any, assetContainer?: string) {
    try {
      const dtlModalContent = this.profilePage?.containermodaljsondata;
      const dlObj = dtlModalContent ? JSON.parse(dtlModalContent) : undefined;

      if (appEventData && dlObj && dlObj?.enableAnalyticsData === 'true') {
        const dataStore = this.generateDLDataStore(event, assetId, dlObj, DL_EVENT_TYPE.DYNAMIC_CONTENT, assetContainer);
        dataStore['assetName'] = (dataStore['assetName'] + modalName).slice(0, 100);

        appEventData.push(dataStore);
      }

    } catch (ex) {
      console.log('DTL Dynamic Content Show :: Exception processing dynamic action', ex);
    }
  }

  setDLUIErrorEvent(errorFieldName: string) {
    try {
      const dtlUIErrorContent = this.profilePage?.containeruierrorjsondata;
      const dlObj = dtlUIErrorContent ? JSON.parse(dtlUIErrorContent) : undefined;

      if (appEventData && dlObj &&  dlObj?.enableAnalyticsData === 'true') {
        const dataStore = this.generateDLDataStore(undefined, undefined, dlObj, DL_EVENT_TYPE.UI_ERROR);
        dataStore['assetName'] = (dtlUIErrorContent.assetName + errorFieldName).slice(0, 100);

        appEventData.push(dataStore);
      }

    } catch (ex) {
      console.log('DTL UI Error event :: Exception processing UI error event', ex);
    }
  }

  setDLFormSubmitEvent(event: any, formName: string, keyword?: any) {
    try {
      const dtlFormContent = this.profilePage?.containerformjsondata;
      const dlObj = dtlFormContent ? JSON.parse(dtlFormContent) : undefined;

      if (appEventData && dlObj && dlObj?.enableAnalyticsData === 'true') {
        const dataStore = this.generateDLDataStore(event, undefined, dlObj, DL_EVENT_TYPE.FORM_SUBMIT);
        dataStore['assetName'] = dataStore['assetName'] + formName;
        dataStore['searchKeyword'] = keyword;

        appEventData.push(dataStore);
      }

    } catch (ex) {
      console.log('DL Form Submit Event :: Exception processing click event action', ex);
    }
  }

  setDLFormErrorEvent(event: any, formName: string, forErrorMsg: string) {
    try {
      const dtlFormErrorContent = this.profilePage?.containerformjsondata;
      const dlObj = dtlFormErrorContent ? JSON.parse(dtlFormErrorContent) : undefined;

      if (appEventData && dlObj && dlObj?.enableAnalyticsData === 'true') {
        const dataStore = this.generateDLDataStore(event, undefined, dlObj, DL_EVENT_TYPE.FORM_ERROR);
        dataStore['assetName'] = dataStore['assetName'] + formName;
        dataStore['formError'] = forErrorMsg;

        appEventData.push(dataStore);
      }

    } catch (ex) {
      console.log('DL Form Error Event :: Exception processing click event action', ex);
    }
  }

  private generateDLDataStoreFromEvent(event: any, aemDLObject: any, eventType: any, assetContainer?: string) {
    const dataStore = {
      event: eventType,
      assetid: UUID.UUID(),
      assetContainer: (assetContainer ? assetContainer + ':' : '') + aemDLObject.assetContainer,
      assetName: aemDLObject.assetName + (event.target?.innerText ? event.target.innerText : event.currentTarget?.innerText).substring(0, 100)
    };

    if (event && (event.currentTarget?.attributes?.dlassetid?.value || event.target?.attributes?.dlassetid?.value)) {
      dataStore['assetid'] = event.currentTarget?.attributes?.dlassetid?.value || event.target?.attributes?.dlassetid?.value;
    }

    let otherKeyValueObj;

    if (aemDLObject.otherKeyValue) {
      otherKeyValueObj = JSON.parse(aemDLObject.otherKeyValue);
    }

    for (const key in otherKeyValueObj) {
      if (key) {
        dataStore[key] = otherKeyValueObj[key];
      }
    }
    return dataStore;
  }

  private generateDLDataStore(event: any, assetId: string, aemDLObject: any, eventType: string, assetContainer?: string) {
    let dataStore;

    if (eventType === DL_EVENT_TYPE.PAGE_LOAD) {
      dataStore = {
        pageAssetId: aemDLObject.assetId,
        pageAssetName: aemDLObject.assetName,
        pageAssetContainer: aemDLObject.assetContainer,
        event: eventType,
        site: this.siteId,
        subsection: aemDLObject.assetSubSection,
        section: aemDLObject.assetSection
      };

    } else {
      dataStore = {
        assetid: UUID.UUID(),
        assetContainer: (assetContainer ? assetContainer + ':' : '') + aemDLObject.assetContainer,
        assetName: aemDLObject.assetName,
        event: eventType,
      };
    }

    if (assetId) {
      dataStore['assetid'] = assetId;

    } else if (event && (event.currentTarget?.attributes?.dlassetid?.value || event.target?.attributes?.dlassetid?.value)) {
      dataStore['assetid'] = event.currentTarget?.attributes?.dlassetid?.value || event.target?.attributes?.dlassetid?.value;
    }

    let otherKeyValueObj;

    if (aemDLObject.otherKeyValue) {
      otherKeyValueObj = JSON.parse(aemDLObject.otherKeyValue);
    }

    for (const key in otherKeyValueObj) {
      if (key) {
        dataStore[key] = otherKeyValueObj[key];
      }
    }
    return dataStore;
  }
}
