import { Injectable } from '@angular/core';
import { CurrencyPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';

import { DTMService } from './dtm.service';
import { OLEService } from './ole.service';
import { StorageService } from './storage.service';
import { UtilityService } from './utility.service';
import { DateUtilityService } from './date-utility.service';

import { Plan } from '../models/Plan';
import { AppData } from '../models/AppData';
import { Benefits } from '../models/Benefits';
import { DCEConstants } from '../constants/dce-constants';
import { AppConstants } from '../constants/app-constants';

declare var updateShoppingCart: any;

@Injectable({
  providedIn: 'root'
})
export class PlanService {

  constructor(
    private readonly http: HttpClient,
    private readonly dtmService: DTMService,
    private readonly oleService: OLEService,
    private readonly dateUtilService: DateUtilityService,
    private readonly storageService: StorageService,
    private readonly utilityService: UtilityService,
    private readonly currencyPipe: CurrencyPipe
  ) {}

  searchPlansByType(planType: string, plan: Plan) {
    const cmsCountyCodes = plan?.county?.cmsCountyCodes?.length > 0 ? plan.county.cmsCountyCodes.join(',') : '';
    planType = planType ? (planType.toUpperCase().indexOf('SNP') > -1 ? 'SNP' : planType.toUpperCase()) : planType;

    const searchPlansURL = DCEConstants.planBenefitsBaseURI + DCEConstants.searchPlansURI + '/' + planType + '/' + plan.zipCode +
      '/' + plan.planYear + '/' + plan?.county?.fipsCountyCode + '/' + plan?.county?.stateCode + '/' + cmsCountyCodes;
    return this.http.get(searchPlansURL);
  }

  getPlanBenefits(plan: Plan): Observable<any[]> {
    const serviceCalls: any = [];
    const planTypes = ['MA', 'PDP', 'SNP'];

    planTypes.forEach(type => {
      serviceCalls.push(this.searchPlansByType(type, plan));
    });

    return forkJoin(serviceCalls);
  }

  setPlansContentData(appData: AppData, cnsData: any[]): AppData {
    if (appData.planBenefitsContent) {
      if (appData.planBenefitsContent.mabenefits) {
        try {
          appData.planBenefitsContent.mabenefits = appData.planBenefitsContent.mabenefits.map(b => JSON.parse(b));
        } catch (e) {
          console.error('Some error occurred while setting MA / MAPD Plan benefits content');
          appData.planBenefitsContent.mabenefits = [];
        }
      }

      if (appData.planBenefitsContent.pdpbenefits) {
        try {
          appData.planBenefitsContent.pdpbenefits = appData.planBenefitsContent.pdpbenefits.map(b => JSON.parse(b));
        } catch (e) {
          console.error('Some error occurred while setting PDP Plan benefits content');
          appData.planBenefitsContent.pdpbenefits = [];
        }
      }

      if (appData.planBenefitsContent.snpbenefits) {
        try {
          appData.planBenefitsContent.snpbenefits = appData.planBenefitsContent.snpbenefits.map(b => JSON.parse(b));
        } catch (e) {
          console.error('Some error occurred while setting SNP Plan benefits content');
          appData.planBenefitsContent.snpbenefits = [];
        }
      }
    }

    try {
      [...appData.csnpList] =  (appData.planBenefitsContent && appData.planBenefitsContent.mnrCsnpPlanId) ? appData.planBenefitsContent.mnrCsnpPlanId : [];

      const cnsPlans: any = cnsData['jcr:content'].planParsys.cnsplans;

      appData.cnsInfo = cnsPlans.planID.map((id, i) => ({
          planId: id, clientProdCode: cnsPlans.clientProdCode[i],
          lineOfBusiness: cnsPlans.lineOfBusiness[i],
          planName: cnsPlans.planName[i]
        })
      );

      this.oleService.setCnsInfo(appData.cnsInfo);

    } catch (e) {
      console.log('Some error occurred while setting CNS information for OLE service.');
    }

    return appData;
  }

  deletePlanFromLocalStorage(zipCode: string, planCode: string) {
    try {
      let favPlans = this.storageService.getItem_LS(zipCode);

      if (favPlans && favPlans.indexOf(planCode) > -1) {

        favPlans = favPlans.replace(planCode, '');

        if (favPlans.indexOf(',,') > -1) {
          favPlans = favPlans.replace(',,', ',');
        }
        if (favPlans.charAt(0) === ',') {
          favPlans = favPlans.substring(1);
        }
        if (favPlans.charAt(favPlans.length - 1) === ',') {
          favPlans = favPlans.substring(0, favPlans.length - 1);
        }

        this.storageService.setItem_LS(zipCode, favPlans);
        this.storageService.removeItem_LS(AppConstants.lastSavedPlan, true);
      }

    } catch (e) {
      console.log('Some error occurred while deleting drug from local storage.');
    }
  }

  isPlansDataExists(appData: AppData): boolean {
    return appData
      && appData.profileDetails
      && appData.profileDetails.plansDetails
      && appData.profileDetails.plansDetails.plans
      && appData.profileDetails.plansDetails.plans.length > 0;
  }

  isFederalPlansExists(appData: AppData): boolean {
    return this.ifMAFederalPlansExists(appData) || this.ifPDPFederalPlansExists(appData) || this.ifSNPFederalPlansExists(appData);
  }

  ifMAFederalPlansExists(appData: AppData): boolean {
    return appData?.maPlansList?.length > 0;
  }

  ifPDPFederalPlansExists(appData: AppData): boolean {
    return appData?.pdpPlansList?.length > 0;
  }

  ifSNPFederalPlansExists(appData: AppData): boolean {
    return appData?.snpPlansList?.length > 0;
  }

  isAddDoctorEligibleForPlan(plan: Plan) {
    return !(plan?.planType?.indexOf('PDP') > -1 || plan?.planId === AppConstants.uhcDualCompHMODSNP2021Plan);
  }

  isAddDoctorSupported(appData: AppData) {
    return this.isFederalPlansExists(appData)
      ? (this.getFederalPlans(appData).filter(plan => this.isAddDoctorEligibleForPlan(plan)).length !== 0)
      : false;
  }

  isNonMemberProfile(appData: AppData): boolean {
    return appData
    && appData.profileDetails
    && appData.profileDetails.userDetails
    && appData.profileDetails.userDetails.createdBy === AppConstants.agent
    && appData.profileDetails.userDetails.email
    && appData.profileDetails.userDetails.firstName
    && appData.profileDetails.userDetails.lastName
    && appData.profileDetails.userDetails.dob
    && appData.profileDetails.userDetails.zipCode
    && !appData.profileDetails.userDetails.mbi;
  }

  getFederalPlans(appData: AppData): Plan[] {
    const plans = [];

    if (this.ifMAFederalPlansExists(appData)) {
      plans.push(...appData.maPlansList);
    }
    if (this.ifPDPFederalPlansExists(appData)) {
      plans.push(...appData.pdpPlansList);
    }
    if (this.ifSNPFederalPlansExists(appData)) {
      plans.push(...appData.snpPlansList);
    }
    return plans;
  }

  getAnyProviderEligibleFederalPlan(appData: AppData): Plan {
    return this.getFederalPlans(appData).find(plan => this.isAddDoctorEligibleForPlan(plan));
  }

  getFavPlans(plans: Plan[]): Plan[] {
    return plans.filter((p: Plan) => p.isEnrolled !== true);
  }

  getMemberEnrolledPlans(plans: Plan[]): Plan[] {
    return plans.filter((p: Plan) => p.isEnrolled === true);
  }

  filterPlans(plan: Plan, dceSystemDate: Date): boolean {
    const dceSystemYear = dceSystemDate.getFullYear();
    const dceSystemMonth = dceSystemDate.getMonth();
    const planYear = Number(plan.planYear);
    if (plan?.planId === AppConstants.uhcDualComp1HMODSNP2021Plan && plan?.planYear === '2021') {
      return false;
    }
    return (planYear === dceSystemYear) || (planYear === (dceSystemYear + 1) && this.dateUtilService.isAEPPeriod(dceSystemMonth));
  }

  setPlansDetails(appData: AppData): AppData {
    appData.maPlansList = [];
    appData.pdpPlansList = [];
    appData.snpPlansList = [];
    let zipCode = null;

    if (this.isNonMemberProfile(appData)) {
      console.log('Setting zipcode in Session Storage for non-member profile flow.');
      this.setZipcodeInSessionStorage(appData.profileDetails.userDetails.zipCode);
    }

    if (this.isPlansDataExists(appData)) {
      const memberEnrolledPlans = this.getMemberEnrolledPlans(appData.profileDetails.plansDetails.plans);
      appData.memberEnrolledPlans = memberEnrolledPlans;

      // console.log('memberEnrolledPlans :: ');
      // console.log(appData.memberEnrolledPlans);

      if (memberEnrolledPlans && memberEnrolledPlans.length > 0) {
        this.setZipcodeInSessionStorage(appData.profileDetails.plansDetails.zipCode);
      }

      appData.profileDetails.plansDetails.plans = this.getFavPlans(appData.profileDetails.plansDetails.plans);

      // console.log('favPlans :: ');
      // console.log(appData.profileDetails.plansDetails.plans);

    } else {
      appData.memberEnrolledPlans = [];
    }

    if (this.isPlansDataExists(appData)) {

      zipCode = appData.profileDetails.plansDetails.zipCode;
      this.setZipcodeInSessionStorage(zipCode);

      let plans = '';
      const plansList = [];

      appData.profileDetails.plansDetails.plans = appData.profileDetails.plansDetails.plans.filter((e: Plan) => this.filterPlans(e, appData.dceSystemDateTime));

      appData.profileDetails.plansDetails.plans.forEach((plan: Plan) => {
        plans += plan.planId + ' ' + plan.planYear + ' ' + (plan.planType === 'MAPD' ? 'MA' : plan.planType) + ',';
        plansList.push(plan.planId);
        plan.benefits = [];

        if (plan.planType === 'MA' || plan.planType === 'MAPD') {
          appData.maPlansList.push(plan);
        } else if (plan.planType === 'PDP') {
          appData.pdpPlansList.push(plan);
        } else if (plan.planType && plan.planType.indexOf('SNP') > -1) {
          appData.snpPlansList.push(plan);
        }
      });

      if (this.isMedSuppPlansExists(appData)) {
        const medSuppData = JSON.parse(appData.profileDetails.medsuppData);
        const medsuppZipCode = medSuppData && medSuppData.zipCode ? medSuppData.zipCode : null;

        if (medsuppZipCode && medsuppZipCode === zipCode) {
          medSuppData.savedPlanInformation.favoritedPlans.forEach((plan: any) => {
            const planData = plan.planCode + ' ' + (plan.planYear ? plan.planYear : appData?.dceSystemDateTime?.getFullYear()) + ' MS';
            plans += planData + ',';
            plansList.push(plan.planCode);

            if (appData.profileDetails.plansDetails.savedPlans) {
              appData.profileDetails.plansDetails.savedPlans += (',' + planData);
            } else {
              appData.profileDetails.plansDetails.savedPlans = planData;
            }
          });
        }
      }

      if (plans.charAt(plans.length - 1) === ',') {
        plans = plans.substring(0, plans.length - 1);
      }

      plans = appData?.profileDetails?.plansDetails?.savedPlans ? this.filterSavedPlans(appData.profileDetails.plansDetails.savedPlans, appData.dceSystemDateTime) : plans;

      // this.storageService.setItem_LS(zipCode, plans);
      appData.plansDataExists = true;

      this.setTotalPlansCount(plans, null, appData, zipCode);

      this.dtmService.setDTMData({visitorProfile: {plans: plansList.join('|')}});

      this.setHeroContainer();

    } else if (this.isMedSuppPlansExists(appData)) {
      const medSuppData = JSON.parse(appData.profileDetails.medsuppData);
      const medsuppZipCode = medSuppData && medSuppData.zipCode ? medSuppData.zipCode : null;

      if (medsuppZipCode) {
        this.setZipcodeInSessionStorage(medsuppZipCode);

        let medsuppPlans = '';
        const medsuppPlansList = [];

        medSuppData.savedPlanInformation.favoritedPlans.forEach((plan: any) => {
          const planData = plan.planCode + ' ' + (plan.planYear ? plan.planYear : appData?.dceSystemDateTime?.getFullYear()) + ' MS';
          medsuppPlans += planData + ',';
          medsuppPlansList.push(plan.planCode);
        });

        if (medsuppPlans.charAt(medsuppPlans.length - 1) === ',') {
          medsuppPlans = medsuppPlans.substring(0, medsuppPlans.length - 1);
        }

        medsuppPlans = medsuppPlans ? this.filterSavedPlans(medsuppPlans, appData.dceSystemDateTime) : medsuppPlans;

        // this.storageService.setItem_LS(medsuppZipCode, medsuppPlans);
        // appData.plansDataExists = true;
        appData.medSuppPlansDataExists = true;

        const remainingPlans = appData?.profileDetails?.plansDetails?.savedPlans ? this.filterSavedPlans(appData.profileDetails.plansDetails.savedPlans, appData.dceSystemDateTime) : null;
        this.setTotalPlansCount(remainingPlans, medsuppPlans, appData, medsuppZipCode);

        this.dtmService.setDTMData({visitorProfile: {plans: medsuppPlansList.join('|')}});

        this.setHeroContainer();
      }

    } else {
      if (appData?.profileDetails?.plansDetails?.savedPlans) {
        const remainingPlans = this.filterSavedPlans(appData.profileDetails.plansDetails.savedPlans, appData.dceSystemDateTime);
        this.setTotalPlansCount(remainingPlans, null, appData, appData?.profileDetails?.plansDetails?.zipCode);
      } else {
        appData.savedPlans = '';
        appData.savedPlansCount = 0;
      }

      appData.plansDataExists = false;
      this.dtmService.setDTMData({visitorProfile: {plans: ''}});
    }

    if (typeof updateShoppingCart === 'function') {
      updateShoppingCart(zipCode);
    }

    return appData;
  }

  setTotalPlansCount(savedPlans: string, medsuppPlans: string, appData: AppData, zipCode: string) {
    try {
      const allPlansList =  savedPlans ? savedPlans.split(',') : [];
      const allMedsuppPlansList =  medsuppPlans ? medsuppPlans.split(',') : [];

      allPlansList.push(...allMedsuppPlansList);

      appData.savedPlans = allPlansList?.length > 0 ? allPlansList.join(',') : '';
      appData.savedPlansCount = allPlansList.length;

      console.log('TOTAL PLANS (' + appData.savedPlansCount + ') : [' + appData.savedPlans + ']');

      if (zipCode) {
        this.storageService.setItem_LS(zipCode, appData.savedPlans);
      }

    } catch (e) {
      console.log('Some error occurred while setting total plans count');
    }
  }

  setZipcodeInSessionStorage(zipCode: string) {
    if (zipCode) {
      this.storageService.setItem_SS(AppConstants.vppZipcode, zipCode);
      this.storageService.setItem_SS(AppConstants.geotrackingZip, zipCode);
    }
  }

  setHeroContainer(): void {
    const heroContainer = document.getElementsByClassName('hero-container');
    if (heroContainer.length > 0) {
      const containerElement  = heroContainer[0] as HTMLScriptElement;
      const elementHeight = containerElement.getBoundingClientRect().top - 5;

      // tslint:disable-next-line:only-arrow-functions
      setTimeout(function() {
        window.scroll({top: elementHeight, left: 0, behavior : 'smooth'});
      }, 300);
    }
  }

  filterSavedPlans(savedPlans: string, dceSystemDateTime: Date): string {
    try {
      const dceSystemYear = dceSystemDateTime.getFullYear();
      const allowedYears = (this.dateUtilService.isAEPPeriod(dceSystemDateTime.getMonth()) ? [dceSystemYear, (dceSystemYear + 1)] : [dceSystemYear]).map(String);

      let plans = savedPlans ? savedPlans.split(',') : null;
      if (plans && plans.length > 0) {
        plans = plans.filter((plan: string) => {
          const planYear = plan && (plan.split(' ').length > 2) ? plan.split(' ')[1] : null;
          if (allowedYears && allowedYears.indexOf(planYear) > -1 && !(plan?.indexOf(AppConstants.uhcDualComp1HMODSNP2021Plan) > -1 && planYear === '2021')) {
            return true;
          }
          return false;
        });

        savedPlans = plans && (plans.length > 0) ? plans.join(',') : '';
      }

    } catch (e) {
      console.log('Some error occurred while filtering saved plans.');
    }

    return savedPlans;
  }

  chunkArray(myArray: any[], chunkSize: number) {
    const results = [];
    while (myArray.length) {
      results.push(myArray.splice(0, chunkSize));
    }
    return results;
  }

  getMarketingBulletsHTMLfromServiceData(planData: any): any {
    let markBullets: any;
    let marketingText: any;
    let marketingBulletsHTML: any;

    if (planData.why_enroll && planData.why_enroll.indexOf('&bull;') > -1) {
      markBullets = planData.why_enroll.split('&bull;');
      markBullets = markBullets.slice(1);

    } else if (planData.why_enroll) {
      if (planData.why_enroll.indexOf('@') > -1) {
        const data = planData.why_enroll.split('@');

        if (data && data[0]) {
          marketingText = data[0];
        }
        if (data && data[1]) {
          markBullets = data[1].split(';');
          markBullets.pop();
        }
      } else if (planData.why_enroll.indexOf(';') > -1) {
        markBullets = planData.why_enroll.split(';');
        markBullets.pop();
      }
    }

    if (marketingText) {
      marketingBulletsHTML = marketingBulletsHTML ? marketingBulletsHTML : '';
      marketingBulletsHTML += '<p>' + marketingText + '</p>';
    }

    if (markBullets && markBullets.length > 0) {
      if (!marketingBulletsHTML) {
        marketingBulletsHTML = '';
      }

      marketingBulletsHTML += '<ul class="marketing-bullets">';
      markBullets.forEach(bullet => {
        marketingBulletsHTML += bullet ? ('<li>' + bullet.trim() + '</li>') : '';
      });
      marketingBulletsHTML += '</ul>';

    }
    return marketingBulletsHTML;
  }

  getMarketingBulletsHTMLfromContentData(plan: Plan, marketingBullet: any, currentYear: string): any {
    let marketingBulletsHTML: any;

    if (plan.planYear === currentYear) {
      marketingBulletsHTML = marketingBullet.currentYearMarketingText ? (marketingBullet.currentYearMarketingText + marketingBullet.currentYearBullets) : marketingBullet.currentYearBullets;
    } else {
      marketingBulletsHTML = marketingBullet.nextYearMarketingText ? (marketingBullet.nextYearMarketingText + marketingBullet.nextYearBullets) : marketingBullet.nextYearBullets;
    }

    return marketingBulletsHTML;
  }

  setMarketingBullets(appData: AppData) {
    const currentYear = appData.activeYear.toString();

    /**** Setting marketing bullets from service data  ****/
    appData.maPlansList.forEach((plan: Plan) => {
      const planData = appData.planSearchResultsList.find(p => p.planId === plan.planId);
      if (planData) {
        plan.monthlyPremium = planData.monthlyPremium;
        plan.monthlyPremiumFormatted = this.utilityService.getMonthlyPremiumValue(planData, appData);
        plan.marketingBulletsHTML = this.getMarketingBulletsHTMLfromServiceData(planData);
      }
    });

    appData.pdpPlansList.forEach((plan: Plan) => {
      const planData = appData.planSearchResultsList.find(p => p.planId === plan.planId);
      if (planData) {
        plan.monthlyPremium = planData.monthlyPremium;
        plan.monthlyPremiumFormatted = this.utilityService.getMonthlyPremiumValue(planData, appData);
        plan.marketingBulletsHTML = this.getMarketingBulletsHTMLfromServiceData(planData);
      }
    });

    appData.snpPlansList.forEach((plan: Plan) => {
      const planData = appData.planSearchResultsList.find(p => p.planId === plan.planId);
      if (planData) {
        plan.monthlyPremium = planData.monthlyPremium;
        plan.monthlyPremiumFormatted = this.utilityService.getMonthlyPremiumValue(planData, appData);
        plan.marketingBulletsHTML = this.getMarketingBulletsHTMLfromServiceData(planData);
      }
    });

    /**** Setting PDP & Group MAPD plans marketing bullets from pdpMarketingBullets content data  ****/
    try {
      if (appData.pdpMarketingBullets.planMarketing) {

        Object.keys(appData.pdpMarketingBullets.planMarketing).forEach(key => {
          const marketingBullet = appData.pdpMarketingBullets.planMarketing[key];

          if (appData.pdpMarketingBullets.planMarketing.hasOwnProperty(key) && marketingBullet) {

            if (marketingBullet.plantitle) {
              appData.pdpPlansList.filter((p: Plan) => p.planName === marketingBullet.plantitle).forEach((plan: Plan) => {
                plan.marketingBulletsHTML = plan.planYear === currentYear ? marketingBullet.currentyear : marketingBullet.nextyear;
              });
            }

            if (marketingBullet.planId) {
              appData.maPlansList.filter((p: Plan) => (p.planType === 'MAPD' && p.planId === marketingBullet.planId)).forEach((plan: Plan) => {
                plan.marketingBulletsHTML = plan.planYear === currentYear ? marketingBullet.currentyear : marketingBullet.nextyear;
              });
            }
          }
        });
      }

    } catch (e) {
      console.error('Some error occurred while setting pdpMarketingBullets');
    }

    /**** Setting MAPD & SNP plans marketing bullets from mapdMarketingBullets content data  ****/
    try {
      if (appData.mapdMarketingBullets.mapdPlanMarketing) {

        Object.keys(appData.mapdMarketingBullets.mapdPlanMarketing).forEach(key => {
          const marketingBullet = appData.mapdMarketingBullets.mapdPlanMarketing[key];

          if (appData.mapdMarketingBullets.mapdPlanMarketing.hasOwnProperty(key) && marketingBullet && marketingBullet.planId) {

            appData.maPlansList.filter((p: Plan) => (p.planType === 'MAPD' && p.planId === marketingBullet.planId)).forEach((plan: Plan) => {
              plan.marketingBulletsHTML = this.getMarketingBulletsHTMLfromContentData(plan, marketingBullet, currentYear);
            });

            appData.snpPlansList.filter((p: Plan) => p.planId === marketingBullet.planId).forEach((plan: Plan) => {
              plan.marketingBulletsHTML = this.getMarketingBulletsHTMLfromContentData(plan, marketingBullet, currentYear);
            });
          }
        });
      }

    } catch (e) {
      console.error('Some error occurred while setting mapdMarketingBullets');
    }

    appData.maPlansList.forEach(this.setPlanMarketingDetailsHTML);
    appData.pdpPlansList.forEach(this.setPlanMarketingDetailsHTML);
    appData.snpPlansList.forEach(this.setPlanMarketingDetailsHTML);
  }

  setPlanMarketingDetailsHTML(plan: Plan) {
    try {
      const marketingBulletsHTML = plan?.marketingBulletsHTML;

      if (marketingBulletsHTML?.indexOf('<p>') > -1) {
        plan.planDescriptionHTML = marketingBulletsHTML.substring(0, marketingBulletsHTML.indexOf('</p>') + 4);
      }
      if (marketingBulletsHTML) {
        plan.planBenefitListHTML = marketingBulletsHTML.indexOf('<p>') > -1 ? marketingBulletsHTML.substring(marketingBulletsHTML.indexOf('</p>') + 4) : marketingBulletsHTML;
      }

    } catch (e) {
      console.log('Some errore occurred while setting marketing details of : [' + plan?.planName + ']');
    }
  }

  isDrugsAndPharmacyDataExists(appData: AppData) {
    return (appData.profileDetails.drugsAndPharmacyDetails && appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails && (appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length > 0)
      && appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj && appData.profileDetails.drugsAndPharmacyDetails.pharmacyObj.pharmacyNumber);
  }

  isDrugsDataExists(appData: AppData) {
    return (appData.profileDetails.drugsAndPharmacyDetails && appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails && (appData.profileDetails.drugsAndPharmacyDetails.drugInfoDetails.length > 0));
  }

  setPlanBenefits(appData: AppData) {
    if (appData.planBenefitsContent && appData.planSearchResultsList) {

      if (appData.planBenefitsContent.mabenefits) {
        appData.maPlansList.forEach((plan: Plan) => {
          plan.benefits = [];
          const savedPlanObj = appData.planSearchResultsList.find(p => plan.planId === p.planId);

          if (savedPlanObj) {
            this.setBenefitsData(savedPlanObj, plan);

            appData.planBenefitsContent.mabenefits.forEach((benefit: any) => {
              this.populateMAMAPDBenefitData(benefit, plan, savedPlanObj, appData);
            });

            if (this.isDrugsDataExists(appData) && savedPlanObj.compositePlanId.planType.name === 'MAPD') {
              plan.benefits.push({ label: appData.planBenefitsContent.estimateAnnualCost, value: this.getEstimatedAnnualDrugCostValue(plan) });
              plan.averageMonthlyDrugCost = this.getAverageMonthlyDrugCost(plan);
              plan.estimatedAnnualDrugCost = this.getEstimatedAnnualDrugCost(plan);
            }

          } else {
            console.log('[ ' + plan.planType + ' - ' + plan.planId + ' ] [' + plan.planName + '] ' + AppConstants.errBenefitsNotFound);
          }
        });
      }

      if (appData.planBenefitsContent.pdpbenefits) {
        appData.pdpPlansList.forEach((plan: Plan) => {
          plan.benefits = [];
          plan.annualDeductible = new Benefits();
          plan.prescriptionDrugsTier1 = new Benefits();
          const savedPdpPlanObj = appData.planSearchResultsList.find(pdpplan => plan.planId === pdpplan.planId);

          if (savedPdpPlanObj) {
            this.getAnnualDeductible(savedPdpPlanObj, plan);
            this.getPrescriptionDrugTier1(savedPdpPlanObj, plan);

            appData.planBenefitsContent.pdpbenefits.forEach((benefit: any) => {
              this.populatePDPBenefitData(benefit, plan, savedPdpPlanObj, appData);
            });

            if (this.isDrugsDataExists(appData)) {
              plan.benefits.push({ label: appData.planBenefitsContent.estimateAnnualCost, value: this.getEstimatedAnnualDrugCostValue(plan) });
              plan.averageMonthlyDrugCost = this.getAverageMonthlyDrugCost(plan);
              plan.estimatedAnnualDrugCost = this.getEstimatedAnnualDrugCost(plan);
            }

          } else {
            console.log('[ ' + plan.planType + ' - ' + plan.planId + ' ] [' + plan.planName + '] ' + AppConstants.errBenefitsNotFound);
          }
        });
      }

      if (appData.planBenefitsContent.snpbenefits) {
        appData.snpPlansList.forEach((plan: Plan) => {
          plan.benefits = [];
          const savedPlanObj = appData.planSearchResultsList.find(p => plan.planId === p.planId);

          if (savedPlanObj) {
            this.setBenefitsData(savedPlanObj, plan);

            appData.planBenefitsContent.snpbenefits.forEach((benefit: any) => {
              this.populateSNPBenefitData(benefit, plan, savedPlanObj, appData);
            });

            if (this.isDrugsDataExists(appData)) {
              plan.benefits.push({ label: appData.planBenefitsContent.estimateAnnualCost, value: this.getEstimatedAnnualDrugCostValue(plan) });
              plan.averageMonthlyDrugCost = this.getAverageMonthlyDrugCost(plan);
              plan.estimatedAnnualDrugCost = this.getEstimatedAnnualDrugCost(plan);
            }

          } else {
            console.log('[ ' + plan.planType + ' - ' + plan.planId + ' ] [' + plan.planName + '] ' + AppConstants.errBenefitsNotFound);
          }
        });
      }
    }
  }

  getEstimatedAnnualDrugCostValue(plan: Plan) {
    return `${plan?.annualDrugCost ? plan.annualDrugCost.toFixed(2) : 0}`;
  }

  getEstimatedAnnualDrugCost(plan: Plan) {
    let cost = this.getEstimatedAnnualDrugCostValue(plan);
    if (cost) {
      cost = cost.replace('.00', '');
      const transformedValue = this.currencyPipe.transform(cost, 'USD');
      return transformedValue ? transformedValue.replace('.00', '') : transformedValue;
    }
    return AppConstants.defaultCostValue;
  }

  getAverageMonthlyDrugCost(plan: Plan) {
    const cost = this.getEstimatedAnnualDrugCostValue(plan);
    if (cost) {
      const transformedValue = this.currencyPipe.transform((Number(cost) / 12).toFixed(2), 'USD');
      return transformedValue ? transformedValue.replace('.00', '') : transformedValue;
    }
    return AppConstants.defaultCostValue;
  }

  setBenefitLabel(benefitLabel: string): string {
    if (benefitLabel) {
      if (benefitLabel.indexOf('[[') > -1 && benefitLabel.indexOf(']]') > -1) {
        benefitLabel = benefitLabel.substring(0, benefitLabel.indexOf('[[')) + benefitLabel.substring(benefitLabel.indexOf(']]') + 2) + ':';
      } else if (benefitLabel.indexOf('<sup>') > -1 && benefitLabel.indexOf('</sup>') > -1) {
        benefitLabel = benefitLabel.substring(0, benefitLabel.indexOf('<sup>')) + benefitLabel.substring(benefitLabel.indexOf('</sup>') + 6) + ':';
      } else {
        benefitLabel = benefitLabel + ':';
      }
      benefitLabel = benefitLabel.replace('::', ':');
    }
    return benefitLabel;
  }

  setBenefitsData(restPlanObject: any, plan: Plan): any {
    plan.primaryCarePhysician = new Benefits();
    plan.specialist = new Benefits();
    plan.routinePhysical = new Benefits();
    plan.prescriptionDrugsTier1 = new Benefits();

    plan.referralRequired = 'No';

    if (restPlanObject.compositePlanId.planType.name === 'MAPD' || restPlanObject.compositePlanId.planType.name === 'SNP') {
      plan.subsidizedPartDLowIncomePremium25Percent = restPlanObject.subsidizedPartDLowIncomePremium25Percent + restPlanObject.medicalBenefit.monthlyMedicalPremium;
      plan.subsidizedPartDLowIncomePremium50Percent = restPlanObject.subsidizedPartDLowIncomePremium50Percent + restPlanObject.medicalBenefit.monthlyMedicalPremium;
      plan.subsidizedPartDLowIncomePremium75Percent = restPlanObject.subsidizedPartDLowIncomePremium75Percent + restPlanObject.medicalBenefit.monthlyMedicalPremium;
      plan.subsidizedPartDLowIncomePremium100Percent = restPlanObject.subsidizedPartDLowIncomePremium100Percent + restPlanObject.medicalBenefit.monthlyMedicalPremium;
    } else {
      plan.subsidizedPartDLowIncomePremium25Percent = restPlanObject.subsidizedPartDLowIncomePremium25Percent;
      plan.subsidizedPartDLowIncomePremium50Percent = restPlanObject.subsidizedPartDLowIncomePremium50Percent;
      plan.subsidizedPartDLowIncomePremium75Percent = restPlanObject.subsidizedPartDLowIncomePremium75Percent;
      plan.subsidizedPartDLowIncomePremium100Percent = restPlanObject.subsidizedPartDLowIncomePremium100Percent;
    }

    this.getPrescriptionDrugTier1(restPlanObject, plan);

    if (restPlanObject && restPlanObject.medicalBenefit && restPlanObject.medicalBenefit.medicalBenefitByBenefitTypeList) {
      /**** setting value for Primary care physician copay or coinsurance ****/
      const primaryCareObj = restPlanObject.medicalBenefit.medicalBenefitByBenefitTypeList.find(p => '7a' === p.medicalBenefitType.code);

      if (primaryCareObj) {
        if (primaryCareObj.medicalBenefitTierByBenefitTypeList[0].medicalBenefitTier.value !== '1' && primaryCareObj.medicalBenefitTierByBenefitTypeList[0].medicalBenefitTier.medicalBenefitTierType.code === 'Tier') {
          if (primaryCareObj.medicalBenefitTierByBenefitTypeList[1] != null) {
            this.getPcpValue(plan, primaryCareObj, 1);
          } else {
            this.getPcpValue(plan, primaryCareObj, 0);
          }
        } else {
          this.getPcpValue(plan, primaryCareObj, 0);
        }
      }

      /**** setting value for Specialist copay or coinsurance ****/
      const specialistObj = restPlanObject.medicalBenefit.medicalBenefitByBenefitTypeList.find(p => '7d' === p.medicalBenefitType.code);

      if (specialistObj) {
        if (specialistObj.isReferalRequired) {
          plan.referralRequired = 'Yes';
        }

        if (specialistObj.medicalBenefitTierByBenefitTypeList[0].medicalBenefitTier.value !== '1' && specialistObj.medicalBenefitTierByBenefitTypeList[0].medicalBenefitTier.medicalBenefitTierType.code === 'Tier') {
          if (specialistObj.medicalBenefitTierByBenefitTypeList[1] != null) {
            this.getSpecialistValue(plan, specialistObj, 1);
          } else {
            this.getSpecialistValue(plan, specialistObj, 0);
          }
        } else {
            this.getSpecialistValue(plan, specialistObj, 0);
        }
      }

      /**** setting value for rouitne physicals copay or coinsurance ****/
      const routinePhysicalObj = restPlanObject.medicalBenefit.medicalBenefitByBenefitTypeList.find(p => '14c1' === p.medicalBenefitType.code);

      if (routinePhysicalObj) {
        this.getRoutinePhysicals(plan, routinePhysicalObj);
      }
    }
  }

  getPcpValue(plan: any, primaryCareObj: any, tierIndex: any): any {
    // tslint:disable-next-line:triple-equals
    if (primaryCareObj.medicalBenefitTierByBenefitTypeList && primaryCareObj.medicalBenefitTierByBenefitTypeList[tierIndex].costType.costValue == '1' && primaryCareObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMinAmount != null) {
      plan.primaryCarePhysician.value = primaryCareObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMinAmount;
      plan.primaryCarePhysician.copay = true;

    // tslint:disable-next-line:triple-equals
    } else if (primaryCareObj.medicalBenefitTierByBenefitTypeList && primaryCareObj.medicalBenefitTierByBenefitTypeList[tierIndex].costType.costValue == '2' && primaryCareObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMinAmount != null) {
      plan.primaryCarePhysician.value = primaryCareObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMinAmount;
      plan.primaryCarePhysician.coins = true;
    }
  }

  getSpecialistValue(plan: any, specialistObj: any, tierIndex: any): any {
    // tslint:disable-next-line:triple-equals
    if (specialistObj.medicalBenefitTierByBenefitTypeList && specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costType.costValue == '1') {
      plan.specialist.copay = true;

    // tslint:disable-next-line:triple-equals
    } else if (specialistObj.medicalBenefitTierByBenefitTypeList && specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costType.costValue == '2') {
      plan.specialist.coins = true;
    }

    if (specialistObj.medicalBenefitTierByBenefitTypeList && specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMinAmount && specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMaxAmount != null) {
      plan.specialist.value = specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMinAmount;

    } else if (specialistObj.medicalBenefitTierByBenefitTypeList && specialistObj.medicalBenefitTierByBenefitTypeList.costMinAmount != null) {
      plan.specialist.value = specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMinAmount;

    } else if (specialistObj.medicalBenefitTierByBenefitTypeList && specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMaxAmount != null) {
      plan.specialist.value = specialistObj.medicalBenefitTierByBenefitTypeList[tierIndex].costMaxAmount;
    }
  }

  getRoutinePhysicals(plan: any, routinPhysicalObj: any): any {
    if (routinPhysicalObj.medicalBenefitTierByBenefitTypeList && routinPhysicalObj.medicalBenefitTierByBenefitTypeList[0].costMinAmount == null && routinPhysicalObj.medicalBenefitTierByBenefitTypeList[0].costMaxAmount == null) {
      plan.routinePhysical.covered = false;

    // tslint:disable-next-line:triple-equals
    } else if (routinPhysicalObj.medicalBenefitTierByBenefitTypeList && routinPhysicalObj.medicalBenefitTierByBenefitTypeList[0].costType.costValue == '1') {
      plan.routinePhysical.value = routinPhysicalObj.medicalBenefitTierByBenefitTypeList[0].costMinAmount;
      plan.routinePhysical.copay = true;

    // tslint:disable-next-line:triple-equals
    } else if (routinPhysicalObj.medicalBenefitTierByBenefitTypeList && routinPhysicalObj.medicalBenefitTierByBenefitTypeList[0].costType.costValue == '2') {
      plan.routinePhysical.value = routinPhysicalObj.medicalBenefitTierByBenefitTypeList[0].costMinAmount;
      plan.routinePhysical.coins = true;
    }
  }

  getPrescriptionDrugTier1(restPlanObject: any, plan: Plan): any {
    if (restPlanObject.drugBenefit && restPlanObject.drugBenefit.lowestCopay != null) {
      const prescriptionDrug = restPlanObject.drugBenefit.lowestCopay;

      if (prescriptionDrug.lastIndexOf('%') !== -1) {
        plan.prescriptionDrugsTier1.coins = true;
        plan.prescriptionDrugsTier1.value = prescriptionDrug.substring(0, prescriptionDrug.lastIndexOf('%'));

        if (restPlanObject.compositePlanId.contractId === 'R3444' && restPlanObject.compositePlanId.pbpNumber === '011') {
          plan.specialist.value = '$0 copay';
        }

        if (restPlanObject.compositePlanId.contractId === 'H0432' && restPlanObject.compositePlanId.pbpNumber === '009' || restPlanObject.compositePlanId.contractId === 'H0624' && restPlanObject.compositePlanId.pbpNumber === '001'
            || restPlanObject.compositePlanId.contractId === 'H2802' && restPlanObject.compositePlanId.pbpNumber === '044' || restPlanObject.compositePlanId.contractId === 'H5253' && restPlanObject.compositePlanId.pbpNumber === '041'
            || restPlanObject.compositePlanId.contractId === 'R3444' && restPlanObject.compositePlanId.pbpNumber === '011' || restPlanObject.compositePlanId.contractId === 'R6801' && restPlanObject.compositePlanId.pbpNumber === '011'
            || restPlanObject.compositePlanId.contractId === 'R7444' && restPlanObject.compositePlanId.pbpNumber === '011' || restPlanObject.compositePlanId.contractId === 'H0271' && restPlanObject.compositePlanId.pbpNumber === '005'
            || restPlanObject.compositePlanId.contractId === 'H0271' && restPlanObject.compositePlanId.pbpNumber === '006' || restPlanObject.compositePlanId.contractId === 'H0271' && restPlanObject.compositePlanId.pbpNumber === '013'
            || restPlanObject.compositePlanId.contractId === 'H0271' && restPlanObject.compositePlanId.pbpNumber === '014' ) {

          if (Number(plan.planYear) > 2020) {
            plan.prescriptionDrugsTier1.value = '$0, $1.30, $3.70 copay, or 15';
          } else {
            plan.prescriptionDrugsTier1.value = '$0, $1.25, $3.40 copay, or 15';
          }
          // plan.PrescriptionDrugsFlag = true;

        } else {
          plan.prescriptionDrugsTier1.value = (parseFloat(plan.prescriptionDrugsTier1.value) % 1 === 0) ? (parseFloat(plan.prescriptionDrugsTier1.value).toFixed(0)) : (parseFloat(plan.prescriptionDrugsTier1.value).toFixed(2));
          // plan.PrescriptionDrugsFlag = false;
        }

      } else {
        plan.prescriptionDrugsTier1.copay = true;
        plan.prescriptionDrugsTier1.value = restPlanObject.drugBenefit.lowestCopay;
      }

    } else {
      // plan.prescriptionDrugsTier1.displayPresDrug=false;
      plan.prescriptionDrugsTier1.value = null;
    }

    const plansIdList = ['H5253024000', 'H3794002000', 'H3379022000', 'H3113010000', 'H4527015000', 'H5008010000', 'H5008011000', 'H5322029000', 'H5322030000', 'H5322026000'];

    if (plansIdList.indexOf(plan.planId) > -1) {
      if (!plan.prescriptionDrugsTier1.value) {
        plan.prescriptionDrugsTier1.value = '';
      }
    }
  }

  getAnnualDeductible(restPlanObject: any, plan: Plan) {
    plan.subsidizedPartDLowIncomePremium25Percent = restPlanObject.subsidizedPartDLowIncomePremium25Percent;
    plan.subsidizedPartDLowIncomePremium50Percent = restPlanObject.subsidizedPartDLowIncomePremium50Percent;
    plan.subsidizedPartDLowIncomePremium75Percent = restPlanObject.subsidizedPartDLowIncomePremium75Percent;
    plan.subsidizedPartDLowIncomePremium100Percent = restPlanObject.subsidizedPartDLowIncomePremium100Percent;

    if (restPlanObject.isSplitTierPlan && restPlanObject.drugBenefit && restPlanObject.drugBenefit.planCopayDetailsList != null) {
      let drugBeneList: any;
      const netwrokid2Obj = restPlanObject.drugBenefit.planCopayDetailsList.find(p => '2' === p.pharmacyNetworkId && p.tierCopayList[0].tierDeductible != null);
      const netwrokid1Obj = restPlanObject.drugBenefit.planCopayDetailsList.find(p => '1' === p.pharmacyNetworkId );

      if (netwrokid2Obj) {
        drugBeneList = netwrokid2Obj.tierCopayList;
      } else if (netwrokid1Obj) {
        drugBeneList = netwrokid1Obj.tierCopayList;
      }

      const tierArray = [];
      const finalObj = {};

      drugBeneList.forEach((benefit: any) => {
        if (tierArray.length === 0) {
          tierArray.push(benefit.tierDeductible);
          finalObj[benefit.tierDeductible] = benefit.tierDescription;

        } else {
          const annualDeductable = benefit.tierDeductible;

          if (tierArray.indexOf(annualDeductable) === -1) {
            tierArray.push(benefit.tierDeductible);
            finalObj[benefit.tierDeductible] = benefit.tierDescription;

          } else {
            const index = benefit.tierDeductible;
            finalObj[benefit.tierDeductible] = finalObj[index] + benefit.tierDescription;
          }
        }
      });

      let isFirstIndex = true;
      let annualDeductiableTier = '';

      Object.keys(finalObj).forEach(key => {
        let tierValues = finalObj[key];

        for (let i = 1; i <= 4; i++) {
          if (tierValues.length - 1 !== tierValues.lastIndexOf(i)) {
            tierValues = tierValues.replace(i, i + ', ');
          }
        }

        if (isNaN(parseFloat(key))) {
          key = key.substring(1, key.length);
        }

        const abc = parseFloat(key);

        if (abc % 1 === 0) {
          key = abc.toFixed(0);
        } else {
          key = abc.toFixed(2);
        }

        if (isFirstIndex) {
          annualDeductiableTier = annualDeductiableTier + '$' + key + ' for ' + tierValues;
          isFirstIndex = false;

        } else {
          annualDeductiableTier = annualDeductiableTier + '; ' + '$' + key + ' for ' + tierValues;
        }
      });

      plan.annualDeductible.value = annualDeductiableTier;

    } else {
      plan.annualDeductible.value = '$' + restPlanObject.annualDeductible;
    }
  }

  populateMAMAPDBenefitData(benefit: any, plan: Plan, savedPlanObj: any, appData: AppData) {
    try {
      if (benefit.benefitLabel.indexOf('Monthly') > -1) {
        // Adding check for DualLookalike Plan for plan limit

        if (this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData) && savedPlanObj.monthlyPremium > 0 ) {
          // tslint:disable-next-line:triple-equals
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 - $${savedPlanObj.monthlyPremium == 0 ? savedPlanObj.monthlyPremium : savedPlanObj.monthlyPremium.toFixed(2)}` });
        } else {
          // tslint:disable-next-line:triple-equals
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${savedPlanObj.monthlyPremium == 0 ? savedPlanObj.monthlyPremium : savedPlanObj.monthlyPremium.toFixed(2)}` });
        }

      } else if (benefit.benefitLabel.indexOf('Pocket') > -1) {

        if (this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData)) {
          if (savedPlanObj?.medicalBenefit?.inNetWorkOOPMaxText?.replace('$', '') > '0') {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 - ${savedPlanObj.medicalBenefit.inNetWorkOOPMaxText.replace('.00', '')}`});
          }
          // tslint:disable-next-line:triple-equals
          if (savedPlanObj?.medicalBenefit?.inNetWorkOOPMaxText?.replace('$', '') == '0') {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value : `$0`});
          }

        } else {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value : `${savedPlanObj.medicalBenefit.inNetWorkOOPMaxText == null ? '$0' : savedPlanObj.medicalBenefit.inNetWorkOOPMaxText }`});
        }

      } else if (benefit.benefitLabel.indexOf('Primary') > -1) {

        if (this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData)) {
          if (plan.primaryCarePhysician.coins) {
            if (plan.primaryCarePhysician.value && parseFloat(plan.primaryCarePhysician.value) > 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - ${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            }
            // tslint:disable-next-line:triple-equals
            if (plan.primaryCarePhysician.value && parseFloat(plan.primaryCarePhysician.value) == 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            }
          }

          if (plan.primaryCarePhysician.copay) {
            if (plan.primaryCarePhysician.value && parseFloat(plan.primaryCarePhysician.value) > 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - $${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.copayEnding}` });
            }
            // tslint:disable-next-line:triple-equals
            if (plan.primaryCarePhysician.value && parseFloat(plan.primaryCarePhysician.value) == 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.copayEnding}` });
            }
          }
        } else {
          if (plan.primaryCarePhysician.copay) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.copayEnding}` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.primaryCarePhysician.value}${appData.planBenefitsContent.coinsuranceEnding}` });
          }
        }
      } else if (benefit.benefitLabel.indexOf('Specialist') > -1) {

        if (this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData)) {
          if (plan.specialist.coins) {
            if (plan.specialist.value && parseFloat(plan.specialist.value) > 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - ${plan.specialist.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            }
            // tslint:disable-next-line:triple-equals
            if (plan.specialist.value && parseFloat(plan.specialist.value) == 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.specialist.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            }
          }

          if (plan.specialist.copay) {
            if (plan.specialist.value && parseFloat(plan.specialist.value) > 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - $${plan.specialist.value} ${appData.planBenefitsContent.copayEnding}` });
            }
            // tslint:disable-next-line:triple-equals
            if (plan.specialist.value && parseFloat(plan.specialist.value) == 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.specialist.value} ${appData.planBenefitsContent.copayEnding}` });
            }
          }
        } else {
          if (plan.specialist.copay) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.specialist.value} ${appData.planBenefitsContent.copayEnding}` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.specialist.value}${appData.planBenefitsContent.coinsuranceEnding}` });
          }
        }

      } else if (benefit.benefitLabel.indexOf('Referral') > -1) {
        plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.referralRequired}` });

      } else if (benefit.benefitLabel.indexOf('Prescription') > -1) {
        const aarpMAChoicePlans = ['H1278005000', 'H2228076000', 'H2577001001', 'H2577001002', 'H2577003001', 'H2577003002', 'H8768016000'];
        const walgreensList = (appData.planBenefitsContent && appData.planBenefitsContent.walgreensList) ? appData.planBenefitsContent.walgreensList : [];

        plan.prescriptionDrugsTier1.value = plan.prescriptionDrugsTier1.value && plan.prescriptionDrugsTier1.copay ? '$' + parseInt(plan.prescriptionDrugsTier1.value.replace('$', ''), 10).toFixed(0) : plan.prescriptionDrugsTier1.value;

        if (savedPlanObj.compositePlanId.planType.name === 'MA') {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${appData.planBenefitsContent.noDrugCoverage}` });

        } else {
          if (walgreensList?.length > 0 && walgreensList.find((p) => p === plan.planId) && !(aarpMAChoicePlans.indexOf(plan.planId) > -1 && Number(plan.planYear) > 2020)) {
            plan.prescriptionDrugsTier1.value = '$0';
          }

          if (this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData)) {
            if (plan.prescriptionDrugsTier1.coins) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            }
            if (plan.prescriptionDrugsTier1.copay) {
              if (plan.prescriptionDrugsTier1.value && parseFloat(plan.prescriptionDrugsTier1.value) > 0) {
                plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - $${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.copayEnding}` });
              }
              // tslint:disable-next-line:triple-equals
              if (plan.prescriptionDrugsTier1.value && parseFloat(plan.prescriptionDrugsTier1.value) == 0) {
                plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.copayEnding}` });
              }
            }
          } else {
            if (plan.prescriptionDrugsTier1.copay) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.copayEnding}` });

            } else if (plan.prescriptionDrugsTier1.coins) {
              if (plan.prescriptionDrugsTier1.value.indexOf('coinsurance') > -1) {
                plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value}` });

              } else {
                plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
              }
            }
          }
        }

      } else if (benefit.benefitLabel.indexOf('Routine') > -1) {
        if (plan.routinePhysical.copay) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.routinePhysical.value} ${appData.planBenefitsContent.copayEnding}` });
        } else {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.routinePhysical.value}${appData.planBenefitsContent.coinsuranceEnding}` });
        }
      }

    } catch (e) {
      console.log('Some error occurred while populating MA/MAPD Benefit : [ ' + this.setBenefitLabel(benefit.benefitLabel) + ' ]');
      console.log(e);
    }
  }

  populatePDPBenefitData(benefit: any, plan: Plan, savedPlanObj: any, appData: AppData) {
    try {
      if (benefit.benefitLabel.indexOf('Monthly') > -1) {
        // tslint:disable-next-line:triple-equals
        plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${savedPlanObj.monthlyPremium == 0 ? savedPlanObj.monthlyPremium : savedPlanObj.monthlyPremium.toFixed(2)}` });

      } else if (benefit.benefitLabel.indexOf('Prescription Drugs') > -1) {
        plan.prescriptionDrugsTier1.value = plan.prescriptionDrugsTier1.value && plan.prescriptionDrugsTier1.copay ? '$' + parseInt(plan.prescriptionDrugsTier1.value.replace('$', ''), 10).toFixed(0) : plan.prescriptionDrugsTier1.value;

        if (plan.prescriptionDrugsTier1.copay) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.copayEnding}` });

        } else if (plan.prescriptionDrugsTier1.coins) {
          if (plan.prescriptionDrugsTier1.value.indexOf('coinsurance') > -1) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value}` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
          }
        }

      } else if (benefit.benefitLabel.indexOf('Annual Deductible') > -1) {
        plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.annualDeductible.value}` });
      }

    } catch (e) {
      console.log('Some error occurred while populating PDP Benefit : [ ' + this.setBenefitLabel(benefit.benefitLabel) + ' ]');
      console.log(e);
    }
  }

  populateSNPBenefitData(benefit: any, plan: Plan, savedPlanObj: any, appData: AppData) {
    try {
      if (benefit.benefitLabel.indexOf('Monthly') > -1) {

        if (!savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          if (savedPlanObj.monthlyPremium > 0) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 - $${savedPlanObj.monthlyPremium}` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${savedPlanObj.monthlyPremium}` });
          }
        }

        if (savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0` });

        } else if (!savedPlanObj.isSpecialSNPPlan && !(this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${savedPlanObj.monthlyPremium}` });
        }

      } else if (benefit.benefitLabel.indexOf('Pocket') > -1) {

        if (!savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          if (!this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData) && savedPlanObj?.medicalBenefit?.inNetWorkOOPMaxText?.replace('$', '') > '0' ) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 - ${savedPlanObj.medicalBenefit.inNetWorkOOPMaxText}` });
          }

          if (this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData) && savedPlanObj?.medicalBenefit?.inNetWorkOOPMaxText?.replace('$', '') > '0') {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 - ${savedPlanObj.medicalBenefit.inNetWorkOOPMaxText.replace('.00', '')}` });
          }

          if (savedPlanObj?.medicalBenefit?.inNetWorkOOPMaxText?.replace('$', '') === '0') {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0` });
          }
        }

        if (savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0` });
        }

        if (!savedPlanObj.isSpecialSNPPlan && !(this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${savedPlanObj.medicalBenefit.inNetWorkOOPMaxText == null ? '$0' : savedPlanObj.medicalBenefit.inNetWorkOOPMaxText}` });
        }

      } else if (benefit.benefitLabel.indexOf('Primary') > -1) {

        if (savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          if (plan.primaryCarePhysician.coins) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 ${appData.planBenefitsContent.copayEnding}` });
          }
        }

        if (!savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {

          if (plan.primaryCarePhysician.coins) {
            if (parseFloat(plan.primaryCarePhysician.value) > 0 ) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - ${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            } else {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            }
          }

          if (plan.primaryCarePhysician.copay) {
            if (parseFloat(plan.primaryCarePhysician.value) > 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - $${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.copayEnding}` });
            } else {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.copayEnding}` });
            }
          }

        } else if (!savedPlanObj.isSpecialSNPPlan && !(this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          if (plan.primaryCarePhysician.copay) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.primaryCarePhysician.value} ${appData.planBenefitsContent.copayEnding}` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.primaryCarePhysician.value}${appData.planBenefitsContent.coinsuranceEnding}` });
          }
        }

      } else if (benefit.benefitLabel.indexOf('Specialist') > -1) {

        if (savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          if (plan.specialist.coins) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 ${appData.planBenefitsContent.copayEnding}` });
          }
        }

        if (!savedPlanObj.isSpecialSNPPlan && (this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {

          if (plan.specialist.coins) {
            if (parseFloat(plan.specialist.value) > 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - ${plan.specialist.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            } else {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.specialist.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
            }
          }

          if (plan.specialist.copay) {
            if (parseFloat(plan.primaryCarePhysician.value) > 0) {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$0 copay - $${plan.specialist.value} ${appData.planBenefitsContent.copayEnding}` });
            } else {
              plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.specialist.value} ${appData.planBenefitsContent.copayEnding}` });
            }
          }

        } else if (!savedPlanObj.isSpecialSNPPlan && !(this.utilityService.is_DSNP_plan(plan, appData) || this.utilityService.is_CNS_plan(plan, appData) || this.utilityService.is_DualLookAlike_plan(savedPlanObj, appData))) {
          if (plan.specialist.copay) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.specialist.value} ${appData.planBenefitsContent.copayEnding}` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.specialist.value}${appData.planBenefitsContent.coinsuranceEnding}` });
          }
        }

      } else if (benefit.benefitLabel.indexOf('Referral') > -1) {
        plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.referralRequired}` });

      } else if (benefit.benefitLabel.indexOf('Prescription') > -1) {
        plan.prescriptionDrugsTier1.value = plan.prescriptionDrugsTier1.value && plan.prescriptionDrugsTier1.copay ? '$' + parseInt(plan.prescriptionDrugsTier1.value.replace('$', ''), 10).toFixed(0) : plan.prescriptionDrugsTier1.value;

        // if ((savedPlanObj?.productFocus?.indexOf('LIS Buydown') === -1 && Number(plan.planYear) >= 2021) || Number(plan.planYear) <= 2020) {
        if (plan.prescriptionDrugsTier1.copay) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.copayEnding}` });

        } else if (plan.prescriptionDrugsTier1.coins) {
          if (plan.prescriptionDrugsTier1.value.indexOf('coinsurance') > -1) {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value}` });
          } else {
            plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.prescriptionDrugsTier1.value} ${appData.planBenefitsContent.coinsuranceEnding}` });
          }
        }
        // }

      } else if (benefit.benefitLabel.indexOf('Routine') > -1) {
        if (plan.routinePhysical.copay) {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `$${plan.routinePhysical.value} ${appData.planBenefitsContent.copayEnding}` });
        } else {
          plan.benefits.push({ label: this.setBenefitLabel(benefit.benefitLabel), value: `${plan.routinePhysical.value}${appData.planBenefitsContent.coinsuranceEnding}` });
        }
      }

    } catch (e) {
      console.log('Some error occurred while populating SNP Benefit : [ ' + this.setBenefitLabel(benefit.benefitLabel) + ' ]');
      console.log(e);
    }
  }

  isMedSuppDataExists(appData: AppData): boolean {
    return appData && appData.profileDetails && appData.profileDetails.medsuppData ? true : false;
  }

  isMedSuppPlansExists(appData: AppData): boolean {
    let isPlansExists = false;

    if (this.isMedSuppDataExists(appData)) {
      try {
        const medsuppDataObject: any = JSON.parse(appData.profileDetails.medsuppData);

        if (medsuppDataObject.savedPlanInformation && medsuppDataObject.savedPlanInformation.favoritedPlans && medsuppDataObject.savedPlanInformation.favoritedPlans.length > 0) {
          isPlansExists = true;
        }

      } catch (e) {
        console.log('Some error occurred while parsing MedSupp data in isMedSuppPlansExists()');
      }
    }
    return isPlansExists;
  }

  buildMedsuppPlansData(appData: AppData): any[] {
    let medsuppPlans: any[] = [];

    if (this.isMedSuppDataExists(appData)) {
      try {
        const medsuppDataObject: any = JSON.parse(appData.profileDetails.medsuppData);

        if (medsuppDataObject.savedPlanInformation && medsuppDataObject.savedPlanInformation.favoritedPlans && medsuppDataObject.savedPlanInformation.favoritedPlans.length > 0) {
          medsuppPlans = medsuppDataObject.savedPlanInformation.favoritedPlans;
        }

      } catch (e) {
        console.log('Some error occurred while parsing MedSupp data in buildMedsuppPlansData()');
      }
    }
    return medsuppPlans;
  }

}
