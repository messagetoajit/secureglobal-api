import { TestBed } from '@angular/core/testing';
import { AppConstants } from '../constants/app-constants';
import { TrackingService } from './tracking.service';
import { DataLayerService } from './datalayer.service';
import { ProfilePage } from '../models/ProfilePage';

describe('DataLayerService', () => {
  let service: DataLayerService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [
        TrackingService
      ]
    });
    service = TestBed.inject(DataLayerService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('test service initialization', () => {
    expect(service.profilePage).toEqual(new ProfilePage());
    expect(service.siteId).toEqual(AppConstants.UMS);
  });

  it('test datalayer JSON values from AEM initialization', () => {
    expect(service.profilePage).toEqual(new ProfilePage());
    expect(service.siteId).toEqual(AppConstants.UMS);
  });
});
