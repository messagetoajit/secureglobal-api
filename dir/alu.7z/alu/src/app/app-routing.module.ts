import { NgModule } from '@angular/core';
import { Routes, RouterModule, PreloadAllModules } from '@angular/router';
import { AuthGuardService as AuthGuard } from './services/authguard.service';
import { DashboardComponent } from './components/dashboard/dashboard.component';

const routes: Routes = [
  {path: '', redirectTo: 'guest', pathMatch: 'full'},
  {path: 'guest', component : DashboardComponent, canActivate: [AuthGuard]},
  {path: 'authenticated', component : DashboardComponent},
  {path: '**', redirectTo: 'guest', pathMatch: 'full'}
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {preloadingStrategy: PreloadAllModules})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
