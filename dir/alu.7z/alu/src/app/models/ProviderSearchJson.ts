import {Provider} from './Provider';

export class ProviderSearchJson {

  client: string;
  clientProdCode: string;
  fipsCode: string;
  psc: string;
  targetURL: string;
  userGroup: string;
  year: string;
  zip: string;
  ProviderIdList: any[];

}
