import { PlanEnrollment } from './PlanEnrollment';

export class EnrollmentsDetails {

    enrollments: PlanEnrollment[];

}
