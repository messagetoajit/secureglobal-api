import { Drug } from './Drug';
import { Pharmacy } from './Pharmacy';

export class DrugsAndPharmacy {

    drugInfoDetails: Drug[];
    pharmacyObj: Pharmacy;
    estimateCost = true;
    zipcode: string;

}
