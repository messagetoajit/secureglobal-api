export class ProfileActionDetails {

    user_id: string;
    profile_action: string;
    event_name: string;
    agent_name: string;

    user_fullname?: string;
    drugs_imported?: number;
    providers_imported?: number;

}
