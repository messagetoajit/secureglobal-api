import { UserProfile } from './UserProfile';
import { Plan } from './Plan';
import { AppConstants } from '../constants/app-constants';

export class AppData {

    profileDetails: UserProfile = new UserProfile();

    maPlansList: Plan[] = [];
    pdpPlansList: Plan[] = [];
    snpPlansList: Plan[] = [];
    medsuppPlansList: any[] = [];
    memberEnrolledPlans: any[] = [];

    plansDataExists = false;
    providersDataExists = false;
    drugsAndPharmacyDataExists = false;
    enrollmentDataExists = false;
    medSuppPlansDataExists = false;
    preDataExists = false;

    preRecommendationType = AppConstants.PRE_EMPTY;
    preRecommendationObj: any;
    preRecommendationResults: any[];
    preNo1RankedPlan: any;
    preStorageData: any = {};

    cnsInfo = [];
    csnpList = [];
    planSearchResultsList = [];

    estimateFlag = false;
    tooltips: any = {};
    pdpMarketingBullets: any = {};
    mapdMarketingBullets: any = {};
    planBenefitsContent: any = {};

    activeYear = new Date().getFullYear();
    dceSystemDateTime: Date;

    isWriteEnabledForCSR = true;
    isCSRLogin = false;

    savedPlans: string;
    savedPlansCount = 0;

    fetchPlanDetails = true;
    fetchSubmittedEnrollmentStatus = true;
    fetchDeniedApplicationContact = true;
    enrollmentsData: any = {};

    agentUserName = null;

    isDisplayNoOnePRERankedPlan = false;

}
