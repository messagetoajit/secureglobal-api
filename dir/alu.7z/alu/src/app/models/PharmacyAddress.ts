export class PharmacyAddress {

    addressLine1: string;
    addressLine2: string;
    city: string;
    state: string;
    zipCode: string;
    phoneNumber: string;
    tty: string;

}
