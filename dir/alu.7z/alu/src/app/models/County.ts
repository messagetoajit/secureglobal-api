export class County {

    cmsCountyCodes: string[];
    fipsCountyCode: string;
    fipsCountyName: string;
    fipsStateCode: string;
    stateCode: string;
    cmscode: string;
    cmsname: string;

    zipcode: string;

}
