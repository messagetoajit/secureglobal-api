export class Provider {

    providerId: string;
    providerAddressId: string;
    providerName: string;
    plansList: string[];
    gender: string;
    isPcpQualifiedId: boolean;
    specialities: string[];
    providerAddress: string;
    PCPId: string;
    providerUniqueId: string;
    providerType: string;

}
