export class Drug {

    drugId: string;
    drugPackageName: string;
    drugPackageSize: string;
    drugPackageQuantity: string;
    isGeneric: boolean;
    drugName: string;
    drugDosage: string;
    drugQuantity: number;
    drugFrequency: string;
    drugSupplyLength: string;
    nationalDrugCode: string;
    refillText?: string;
    legacyRefillText?: string;

}
