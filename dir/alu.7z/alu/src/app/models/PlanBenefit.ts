export class PlansBenefit {

    label: any;
    value: any;

}
