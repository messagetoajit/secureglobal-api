import { Plan } from './Plan';

export class PlansDetails {

    zipCode: string;
    plans: Plan[];
    savedPlans: string;

}
