export class AppContent {

    /**** Header Content ****/
    closeIconPath?: string;
    importYourInformation?: string;
    helpUsPersonalizeYourCostEstimates?: string;
    helpUsPersonalizeYourCostEstimatesBasedOnItems?: string;

    /**** Fill Details ****/

    Weneedafewdetails?: string;
    iconlock?: string;
    keepthisinformationsecure?: string;
    YourName?: string;
    YourGender?: string;
    Male?: string;
    Female?: string;
    GenderError?: string;
    YourDateofBirth?: string;
    DateFormat?: string;
    DobError?: string;
    ValidDOB?: string;
    YourZIPCode?: string;
    ZipcodeError?: string;
    ViewYourDrugsandDoctors?: string;
    YourMedicareNumber?: string;
    WherecanIfindthis?: string;
    MedicareHealthInsurancecard?: string;
    InsurancecardImage?: string;
    mbiError?: string;
    ValidMBI?: string;

    /**** Do you currently have Medicare insurance ****/

    Helpuspersonalize?: string;
    DoyouhaveMedicareinsurance?: string;
    Whethermemberornot?: string;
    YesIcurrentlyhaveMedicareinsurance?: string;
    No?: string;
    Answertocontinue?: string;
    Previous?: string;
    Next?: string;

    /**** start Import Step ****/

    Wecanimportyourdrugsanddoctors?: string;
    wewonthaveaccessto?: string;

    /**** Non member Agreement Step ****/

    weneedyourconsent?: string;
    Doyouagreetothefollowing?: string;
    Forthepurposesofselectingaplan?: string;
    Typeyournameifyouagree?: string;
    Enteryourname?: string;

    /**** Sign In Step ****/

    nextStep?: string;
    signInHeading?: string;
    toSecurelyImportText?: string;
    signInLinkText?: string;
    SignInButton?: string;
    Cancel?: string;
    toyourProfilusingOneHealthcareID?: string;
    WhatisaProfile?: string;
    AProfileallowsUnitedHealthcaretosecurely?: string;
    IfyouarenewtoUnitedHealthcare?: string;
    createanewProfile?: string;
    illustrationComputerHeart?: string;

    /**** Get Started ****/

    personalizeyourcost?: string;
    Medicareclaimshistory?: string;
    iconPiggybank?: string;
    PersonalizedCostEstimates?: string;
    Seewhichplanscoveryourdrugsanddoctors?: string;
    iconClock?: string;
    TimeSavings?: string;
    Skipthetimeandeffort?: string;
    GetStarted?: string;
    Howdoesthiswork?: string;
    DoIneedtobeamember?: string;
    UnitedHealthcarememberornot?: string;
    Willmyinformationbesecure?: string;
    YesWithyourauthorization?: string;
    arrowForwardIcon?: string;
    arrowUpIcon?: string;

    /**** Import Failure Step ****/

    unabletofindyourclaimhistory?: string;
    Whilewedidnotfind?: string;
    Simply?: string;
    tobegin?: string;
    returntoyourprofilepage?: string;
    AddDrugs?: string;
    AddDoctors?: string;
    closethiswindow?: string;
    NeedHelp?: string;
    TTY?: string;
    ContactUnitedHealthcare?: string;
    Ouragentscanhelpyou?: string;

    constructor(data: AppContent = {}) {

        /**** Header Content ****/

        this.closeIconPath = data.closeIconPath;
        this.importYourInformation = data.importYourInformation;
        this.helpUsPersonalizeYourCostEstimates = data.helpUsPersonalizeYourCostEstimates;
        this.helpUsPersonalizeYourCostEstimatesBasedOnItems = data.helpUsPersonalizeYourCostEstimatesBasedOnItems;

        /**** Fill Details ****/

        this.Weneedafewdetails = data.Weneedafewdetails;
        this.iconlock = data.iconlock;
        this.keepthisinformationsecure = data.keepthisinformationsecure;
        this.YourName = data.YourName;
        this.YourGender = data.YourGender;
        this.Male = data.Male;
        this.Female = data.Female;
        this.GenderError = data.GenderError;
        this.YourDateofBirth = data.YourDateofBirth;
        this.DateFormat = data.DateFormat;
        this.DobError = data.DobError;
        this.ValidDOB = data.ValidDOB;
        this.YourZIPCode = data.YourZIPCode;
        this.ZipcodeError = data.ZipcodeError;
        this.ViewYourDrugsandDoctors = data.ViewYourDrugsandDoctors;
        this.YourMedicareNumber = data.YourMedicareNumber;
        this.WherecanIfindthis = data.WherecanIfindthis;
        this.MedicareHealthInsurancecard = data.MedicareHealthInsurancecard;
        this.InsurancecardImage = data.InsurancecardImage;
        this.mbiError = data.mbiError;
        this.ValidMBI = data.ValidMBI;

        /**** Do you currently have Medicare insurance ****/

        this.Helpuspersonalize = data.Helpuspersonalize;
        this.DoyouhaveMedicareinsurance = data.DoyouhaveMedicareinsurance;
        this.Whethermemberornot = data.Whethermemberornot;
        this.YesIcurrentlyhaveMedicareinsurance = data.YesIcurrentlyhaveMedicareinsurance;
        this.No = data.No;
        this.Answertocontinue = data.Answertocontinue;
        this.Previous = data.Previous;
        this.Next = data.Next;

        /**** start Import Step ****/

        this.Wecanimportyourdrugsanddoctors = data.Wecanimportyourdrugsanddoctors;
        this.wewonthaveaccessto = data.wewonthaveaccessto;

        /**** Non member Agreement Step ****/

        this.weneedyourconsent = data.weneedyourconsent;
        this.Doyouagreetothefollowing = data.Doyouagreetothefollowing;
        this.Forthepurposesofselectingaplan = data.Forthepurposesofselectingaplan;
        this.Typeyournameifyouagree = data.Typeyournameifyouagree;
        this.Enteryourname = data.Enteryourname;

        /**** Get Started ****/

        this.personalizeyourcost = data.personalizeyourcost;
        this.Medicareclaimshistory = data.Medicareclaimshistory;
        this.iconPiggybank = data.iconPiggybank;
        this.PersonalizedCostEstimates = data.PersonalizedCostEstimates;
        this.Seewhichplanscoveryourdrugsanddoctors = data.Seewhichplanscoveryourdrugsanddoctors;
        this.iconClock = data.iconClock;
        this.TimeSavings = data.TimeSavings;
        this.Skipthetimeandeffort = data.Skipthetimeandeffort;
        this.GetStarted = data.GetStarted;
        this.Howdoesthiswork = data.Howdoesthiswork;
        this.DoIneedtobeamember = data.DoIneedtobeamember;
        this.UnitedHealthcarememberornot = data.UnitedHealthcarememberornot;
        this.Willmyinformationbesecure = data.Willmyinformationbesecure;
        this.YesWithyourauthorization = data.YesWithyourauthorization;
        this.arrowForwardIcon = data.arrowForwardIcon;
        this.arrowUpIcon = data.arrowUpIcon;

        /**** Sign In Step ****/

        this.nextStep = data.nextStep;
        this.signInHeading = data.signInHeading;
        this.toSecurelyImportText = data.toSecurelyImportText;
        this.signInLinkText = data.signInLinkText;
        this.SignInButton = data.SignInButton;
        this.Cancel = data.Cancel;
        this.toyourProfilusingOneHealthcareID = data.toyourProfilusingOneHealthcareID;
        this.WhatisaProfile = data.WhatisaProfile;
        this.AProfileallowsUnitedHealthcaretosecurely = data.AProfileallowsUnitedHealthcaretosecurely;
        this.IfyouarenewtoUnitedHealthcare = data.IfyouarenewtoUnitedHealthcare;
        this.createanewProfile = data.createanewProfile;
        this.illustrationComputerHeart = data.illustrationComputerHeart;

        /**** Import Failure Step ****/

        this.unabletofindyourclaimhistory = data.unabletofindyourclaimhistory;
        this.Whilewedidnotfind = data.Whilewedidnotfind;
        this.Simply = data.Simply;
        this.tobegin = data.tobegin;
        this.returntoyourprofilepage = data.returntoyourprofilepage;
        this.AddDrugs = data.AddDrugs;
        this.AddDoctors = data.AddDoctors;
        this.closethiswindow = data.closethiswindow;
        this.NeedHelp = data.NeedHelp;
        this.TTY = data.TTY;
        this.ContactUnitedHealthcare = data.ContactUnitedHealthcare;
        this.Ouragentscanhelpyou = data.Ouragentscanhelpyou;
    }

}
