import { Product } from './Product';
import { Provider } from './Provider';

export class ProvidersDetails {

    zipCode: string;
    providerIdList: Provider[];

}
