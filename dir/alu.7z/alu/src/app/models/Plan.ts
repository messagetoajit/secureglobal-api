import { County } from './County';
import { OLE } from './OLE';
import { DCELaunchData } from './DCELaunchData';
import {Benefits} from './Benefits';
import { PlansBenefit } from './PlanBenefit';

export class Plan {

    isEnrolled: boolean;
    planId: string;
    planName: string;
    planType: string;
    planYear: string;
    zipCode: string;
    county: County;
    preferredNetwork: boolean;
    pharmacySaver: boolean;
    dceLaunchData: DCELaunchData;
    oleLaunchData: OLE;
    coveredDrugsCount = 0;
    monthlyPremium = 0;
    annualDrugCost = 0;
    estimatedAnnualDrugCost: string;
    averageMonthlyDrugCost: string;
    network: boolean;
    coveredDrugs: string[] = [];
    costsDuringInitialCoveragePeriod: any = {};
    planDescriptionHTML: string;
    planBenefitListHTML: string;
    marketingBulletsHTML: string;
    primaryCarePhysician: Benefits;
    specialist: Benefits;
    routinePhysical: Benefits;
    referralRequired: string;
    prescriptionDrugsTier1: Benefits;
    annualDeductible: Benefits;

    subsidizedPartDLowIncomePremium100Percent = 0;
    subsidizedPartDLowIncomePremium75Percent = 0;
    subsidizedPartDLowIncomePremium50Percent = 0;
    subsidizedPartDLowIncomePremium25Percent = 0;

    benefits: PlansBenefit[];
    enrollmentStatus: string;
    monthlyPremiumFormatted: string;

}
