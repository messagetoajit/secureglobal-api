export class Benefits {

    value: string;
    copay: boolean;
    coins: boolean;

}
