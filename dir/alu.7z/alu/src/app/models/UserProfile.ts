import { PlansDetails } from './PlansDetails';
import { DrugsAndPharmacy } from './DrugsAndPharmacy';
import { ProvidersDetails } from './ProvidersDetails';
import { UserDetails } from './UserDetails';
import { EnrollmentsDetails } from './EnrollmentsDetails';
import { MacraData } from './MacraData';
import { PREData } from './PREData';

export class UserProfile {

    uuid: string;
    plansDetails: PlansDetails;
    memberEnrolledPlans: PlansDetails;
    drugsAndPharmacyDetails: DrugsAndPharmacy;
    providersDetails: ProvidersDetails;
    enrollmentsDetails: EnrollmentsDetails;
    userDetails: UserDetails;
    macraData: MacraData;
    medsuppData: string;
    preData: PREData;

}
