import { PharmacyAddress } from './PharmacyAddress';

export class Pharmacy {

    pharmacyName: string;
    pharmacyNumber: string;
    preferredNetwork: boolean;
    pharmacySaver: boolean;
    mailOrder: boolean;
    pharmacyAddress: PharmacyAddress;

}
