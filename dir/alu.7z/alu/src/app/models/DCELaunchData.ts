import { County } from './County';

export class DCELaunchData {

    brandId: string;
    contractId: string;
    county: any;
    dceView: string;
    fipsCode: string;
    monthlyPremium: number;
    pbpNumber: string;
    planId: string;
    planName: string;
    planType: string;
    planYear: string;
    isPreferred: boolean;
    isSaver: boolean;
    segmentId: string;
    stateCode: string;
    isUsOtherTerritories: boolean;
    vppView: string;
    zipCode: string;

}
