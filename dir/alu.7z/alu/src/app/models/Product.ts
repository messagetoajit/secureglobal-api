export class Product {

    clientProdCode: string;
    providerCount: number;

}
