export class UserDetails {

    email: string;
    firstName: string;
    fullName: string;
    lastName: string;
    nickName: string;
    optumId: string;
    uuid: string;
    siteId: string;
    dob: string;
    mbi: string;
    createdBy: string;
    zipCode: string;
    gender: string;
    consent: string;
    profileType: string;
    telesalesProfileType: string;
    profileStatus: string;

}
