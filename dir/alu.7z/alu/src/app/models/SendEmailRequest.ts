export class SendEmailRequest {

    emailAddress: string;
    firstName: string;
    lastName: string;
    mbi: string;
    gender: string;
    dob: string;
    zip: string;
    siteId: string;
    uhcstatus: string;
    deeplink: string;
    profileStatus: string;

}
