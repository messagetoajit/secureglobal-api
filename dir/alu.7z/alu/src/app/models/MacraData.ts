export class MacraData {

    zipCode: string;
    dateOfBirth: string;
    medicarePartBDate: string;
    medicarePartADate: string;
    genderCode: string;
    tobaccoUser: string;
    desiredPlanStartDate: string;

}
