import { County } from './County';

export class PlanEnrollment {

    planId: string;
    planName: string;
    planYear: string;
    planType: string;
    status: string;
    lastSaved: string;
    formData: string;
    zipCode: string;
    confirmationNo: string;
    county: County;
    isSubmitted = false;
    monthlyPremium: string;
    tty: string;
    phoneNumber: string;
    hoursOfOperation: string;

}
