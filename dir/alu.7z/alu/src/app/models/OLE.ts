export class OLE {

  planName: string;
  year: string;
  zip: string;
  countyName: string;
  premium: string;
  planType: string;
  stateCode: string;
  fipsCode: string;
  HNumber: string;
  PBPNumber: string;
  segmentId: string;
  riderFlag: boolean;
  CMScode: string;
  planId: string;
  planCode: string;
  mapsPlanType: string;
  env: string;
  hearing: boolean;
  fitness: boolean;
  dental: boolean;
  vision: boolean;
  url: string;
  isCNS: boolean;
  isCSNP: boolean;
  clientProdCode: string;
  lineOfBusiness: string;

}
