export class PREData {

    data?: string;
    createdBy?: string;
    creationDate?: string;
    lastModifiedBy?: string;
    lastModifiedDate?: string;

}
