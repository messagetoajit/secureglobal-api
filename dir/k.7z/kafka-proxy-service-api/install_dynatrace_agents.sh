#!/bin/bash

# install dynatrace agents for both stage and prod.
#
# NOTE : $DT_HOME must be set in entrypoint.sh before running the dynatrace-agent64.sh
#
# install stage agent

DT_PAAS_URL="https://dtsaas-sgw-test.uhc.com/e/6b493156-990f-4109-a233-0e2361597b6c/api"
DT_PAAS_TOKEN="IOjr-IgtToWjb9r61WkEr"
DT_ONEAGENT_OPTIONS="flavor=default&include=java"
DT_HOME="/opt/dynatrace/oneagent_stage"

echo "$DT_PAAS_URL/v1/deployment/installer/agent/unix/paas/latest?Api-Token=$DT_PAAS_TOKEN&$DT_ONEAGENT_OPTIONS"
mkdir -p "$DT_HOME"
curl -v -k -o "$DT_HOME/oneagent.zip" "$DT_PAAS_URL/v1/deployment/installer/agent/unix/paas/latest?Api-Token=$DT_PAAS_TOKEN&$DT_ONEAGENT_OPTIONS"
ls -l /opt/dynatrace/oneagent_stage/oneagent.zip
unzip -d "$DT_HOME" "$DT_HOME/oneagent.zip"
rm "$DT_HOME/oneagent.zip"

# install prod agent

DT_PAAS_URL="https://dtsaas-sgw.uhc.com/e/97fa2012-079e-4466-a82f-15cecc698314/api"
DT_PAAS_TOKEN="1Oz1aEPSRl6F3PECgXq5e"
DT_ONEAGENT_OPTIONS="flavor=default&include=java"
DT_HOME="/opt/dynatrace/oneagent_prod"

echo "$DT_PAAS_URL/v1/deployment/installer/agent/unix/paas/latest?Api-Token=$DT_PAAS_TOKEN&$DT_ONEAGENT_OPTIONS"
mkdir -p "$DT_HOME"
curl -v -k -o "$DT_HOME/oneagent.zip" "$DT_PAAS_URL/v1/deployment/installer/agent/unix/paas/latest?Api-Token=$DT_PAAS_TOKEN&$DT_ONEAGENT_OPTIONS"
ls -l /opt/dynatrace/oneagent_prod/oneagent.zip
unzip -d "$DT_HOME" "$DT_HOME/oneagent.zip"
rm "$DT_HOME/oneagent.zip"