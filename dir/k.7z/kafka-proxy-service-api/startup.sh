#!/bin/sh
java -jar -Dspring.active.profiles=$1 /opt/kafka-proxy-service-api/kafka-proxy-service-api.jar