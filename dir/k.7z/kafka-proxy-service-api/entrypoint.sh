#!/bin/bash

echo "Running entrypoint.sh"
echo Your env is: "${spring_profiles_active}"

if [ "${spring_profiles_active}" = "stage" ] ; then
    echo "Running Stage Dynatrace"
	export DT_HOME=/opt/dynatrace/oneagent_stage
	source /opt/dynatrace/oneagent_stage/dynatrace-agent64.sh

elif [ "${spring_profiles_active}" = "prod" ] ; then
    echo "Running Prod Dynatrace"
	export DT_HOME"/opt/dynatrace/oneagent_prod"
	soure /opt/dynatrace/oneagent_prod/dynatrace-agent64.sh 
else
	echo "Not starting dynatrace agent"
fi
# Splunk agent 

LOGNAME=kafka-proxy-service-api

cat > /opt/splunk/splunkforwarder/etc/system/local/inputs.conf <<EOF
[monitor:///var/log/${LOGNAME}/*.log]
disabled = false  
index = cba_gpd
sourcetype = gpd:${LOGNAME}*.log
ignoreOlderThan = 7d  
EOF

ls -lrRt /opt/splunk/splunkforwarder

if [ "${spring_profiles_active}" = "stage" ] ; then
	cd /opt/splunk/splunkforwarder/etc/apps
	tar xvzf /opt/splunk/optum_npe_ose_outputs.tgz
	/opt/splunk/splunkforwarder/bin/splunk start --accept-license 

elif [ "${spring_profiles_active}" = "prod" ] ; then
     cd /opt/splunk/splunkforwarder/etc/apps
     tar xvzf /opt/splunk/optum_phi_ose_outputs.tgz  
	 /opt/splunk/splunkforwarder/bin/splunk start --accept-license 
else
	echo "Not starting splunk agent" 
fi
set +x
env
exec java -Dcom.sun.management.jmxremote -noverify -Dspring.profiles.active=${spring_profiles_active} -jar /opt/kafka-proxy-service-api/kafka-proxy-service-api.jar