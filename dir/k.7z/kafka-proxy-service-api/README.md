# M & R Kafka Proxy Service Processor
Kafka proxy Service API acts as proxy to POST messages to a topic in Kafka from M & R Applications residing in DMZ and Kafka Cluster that resides in Core. Kafka Cluster is only available in Core network.

It's decided best to leverage this cluster maintained by Data Externalization team rather than creating and maintaining a cluster in DMZ

## Topic Creation
 - Work with Data Externalization team to create your topic with in the Kafka Cluster. Follow instructions posted here https://github.optum.com/Kafka/kaas-alpha and https://github.optum.com/Kafka/kaas-prod
 - They will provide you with a zip file that contains Truststore/Keystore JKS and Password file to the Kafka Cluster.
 
## Configure Kafka Proxy Service API
 - Unzip the cert provided by the data externalization team
 - Add the cert as a Secret to OpenShift and mount it to the kafka-proxy-service-api application with mount path convention /portal/conf/kafka-proxy-service-api/cert/{your.producer.cn}
 - Make sure it is set with permission for read
 - There are two ways to route a message to the proxy:
   1. POST application/json message to /api/mnr/kafkaproxy/route using the JSON payload template below
   2. POST any type of message not just JSON message in the body to /api/mnr/kafkaproxy/route/{producerCn}/{topic}

### Kafka Proxy Service URL
 - Test: http://kafka-proxy-service-api-team-e.ocp-elr-core-nonprod.optum.com/
 - Prod: TBD
 
```json
{
   "message": "PAYLOAD TO BE PUSHED ONTO TOPIC OF KAFKA CLUSTER",
   "producerCn": "producer-cn you provided when creating the Kafka Cluster",
   "topic": "Topic to push the message to on the Cluster"
}
``` 