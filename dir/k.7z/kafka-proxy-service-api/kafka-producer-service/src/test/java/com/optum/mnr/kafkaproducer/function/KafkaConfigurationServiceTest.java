package com.optum.mnr.kafkaproducer.function;

import com.optum.mnr.kafkaproducer.repository.KafkaConfigurationRepository;
import com.optum.mnr.kafkaproducer.repository.domain.KafkaConfiguration;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.kafka.core.KafkaTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class KafkaConfigurationServiceTest {

    private KafkaConfigurationService kafkaConfigurationService;
    private KafkaTemplate kafkaTemplate = mock(KafkaTemplate.class);
    private KafkaConfigurationRepository kafkaConfigurationRepository = mock(KafkaConfigurationRepository.class);

    private KafkaProperties kafkaProperties = new KafkaProperties();

    @Test
    void initWithNullConfiguration() {
        kafkaConfigurationService = new KafkaConfigurationService(kafkaConfigurationRepository, kafkaProperties);
        kafkaConfigurationService.init();
        Map<String, KafkaTemplate<String, String>> kafkaTemplateMap = (Map<String, KafkaTemplate<String, String>>) kafkaConfigurationService.getKAFKA_CONFIGURATIONS();
        assertTrue(kafkaTemplateMap.isEmpty());
    }

    @Test
    void initWithEmptyConfiguration() {
        kafkaConfigurationService = new KafkaConfigurationService(kafkaConfigurationRepository, kafkaProperties);
        kafkaConfigurationService.init();
        Map<String, KafkaTemplate<String, String>> kafkaTemplateMap = (Map<String, KafkaTemplate<String, String>>) kafkaConfigurationService.getKAFKA_CONFIGURATIONS();
        assertTrue(kafkaTemplateMap.isEmpty());
    }

    @Test
    void initWithOneConfiguration() {
        Map<String, Object> buildProducerProperties = kafkaProperties.buildProducerProperties();
        buildProducerProperties.put("retries", 1);
        buildProducerProperties.put("acks", "1");
        kafkaConfigurationService = new KafkaConfigurationService(kafkaConfigurationRepository, kafkaProperties);
        List<KafkaConfiguration> kafkaConfigurationList = new ArrayList<>();
        KafkaConfiguration kafkaConfiguration = new KafkaConfiguration();
        kafkaConfiguration.setProducerCn("producerCn");
        kafkaConfigurationList.add(kafkaConfiguration);
        when(kafkaConfigurationRepository.findAll()).thenReturn(kafkaConfigurationList);
        kafkaConfigurationService.init();
        Map<String, KafkaTemplate<String, String>> kafkaTemplateMap = (Map<String, KafkaTemplate<String, String>>) kafkaConfigurationService.getKAFKA_CONFIGURATIONS();
        assertFalse(kafkaTemplateMap.isEmpty());
    }

    @Test
    void findByIdWithAvailableKafkaTemplateInMap()  {
        kafkaConfigurationService = new KafkaConfigurationService(kafkaConfigurationRepository, kafkaProperties);
        when(kafkaConfigurationRepository.findByProducerCN(Mockito.anyString())).thenReturn(null);
        Map<String, KafkaTemplate<String, String>> kafkaTemplateMap = new HashMap<>();
        kafkaTemplateMap.put("1", kafkaTemplate);
        kafkaConfigurationService.getKAFKA_CONFIGURATIONS().put("1", kafkaTemplate);
        KafkaTemplate<String, String> kafkaTemplateResult = kafkaConfigurationService.findById("1");
        assertEquals(kafkaTemplateResult, kafkaTemplate);
        verify(kafkaConfigurationRepository, never()).findByProducerCN("1");
    }

    @Test
    void findByIdWithNoAvailableKafkaTemplateInMap()  {
        kafkaConfigurationService = new KafkaConfigurationService(kafkaConfigurationRepository, kafkaProperties);
        KafkaConfiguration kafkaConfiguration = new KafkaConfiguration();
        kafkaConfiguration.setProducerCn("producerCn");
        kafkaConfiguration.setKeystorePass("keystorepass");
        kafkaConfiguration.setKeystorePath("keystorePath");
        kafkaConfiguration.setTruststorePass("truststorePass");
        kafkaConfiguration.setTruststorePath("truststorePath");
        when(kafkaConfigurationRepository.findByProducerCN("1")).thenReturn(kafkaConfiguration);
        KafkaTemplate<String, String> kafkaTemplateResult = kafkaConfigurationService.findById("1");
        assertNotEquals(kafkaTemplateResult.hashCode(), kafkaTemplate.hashCode());
        Map<String, KafkaTemplate<String, String>> kafkaTemplateMap = (Map<String, KafkaTemplate<String, String>>) kafkaConfigurationService.getKAFKA_CONFIGURATIONS();
        assertTrue(kafkaTemplateMap.containsKey("1"));
    }
}