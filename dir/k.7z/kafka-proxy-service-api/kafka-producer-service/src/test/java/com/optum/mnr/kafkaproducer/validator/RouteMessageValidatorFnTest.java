package com.optum.mnr.kafkaproducer.validator;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.server.ResponseStatusException;

import com.optum.mnr.kafkaproducer.function.KafkaConfigurationService;
import com.optum.mnr.kafkaproducer.domain.RouteMessageRequest;

class RouteMessageValidatorFnTest {

    @Mock
    private KafkaConfigurationService kafkaConfigurationService = mock(KafkaConfigurationService.class);

    @Mock
    private KafkaTemplate kafkaTemplate = mock(KafkaTemplate.class);

    @Test
    void applySuccessful() {
        RouteMessageValidatorFn routeMessageValidatorFn = new RouteMessageValidatorFn(kafkaConfigurationService);
        RouteMessageRequest routeMessageRequest = new RouteMessageRequest();
        routeMessageRequest.setMessage("message");
        routeMessageRequest.setProducerCn("producerCn");
        routeMessageRequest.setTopic("topic");

        Mockito.when(kafkaConfigurationService.findById(Mockito.anyString())).thenReturn(kafkaTemplate);
        assertEquals(routeMessageValidatorFn.apply(routeMessageRequest), routeMessageRequest);
    }

    @Test
    void applyMissingMessage() {
        RouteMessageValidatorFn routeMessageValidatorFn = new RouteMessageValidatorFn(kafkaConfigurationService);
        RouteMessageRequest routeMessageRequest = new RouteMessageRequest();
        routeMessageRequest.setProducerCn("producerCn");
        routeMessageRequest.setTopic("topic");
        assertThrows(ResponseStatusException.class, () -> routeMessageValidatorFn.apply(routeMessageRequest));
    }

    @Test
    void applyMissingProducerCN() {
        RouteMessageValidatorFn routeMessageValidatorFn = new RouteMessageValidatorFn(kafkaConfigurationService);
        RouteMessageRequest routeMessageRequest = new RouteMessageRequest();
        routeMessageRequest.setTopic("topic");
        routeMessageRequest.setMessage("message");
        assertThrows(ResponseStatusException.class, () -> routeMessageValidatorFn.apply(routeMessageRequest));
    }

    @Test
    void applyMissingTopic() {
        RouteMessageValidatorFn routeMessageValidatorFn = new RouteMessageValidatorFn(kafkaConfigurationService);
        RouteMessageRequest routeMessageRequest = new RouteMessageRequest();
        routeMessageRequest.setMessage("message");
        routeMessageRequest.setProducerCn("producerCn");
        assertThrows(ResponseStatusException.class, () -> routeMessageValidatorFn.apply(routeMessageRequest));
    }

    @Test
    void applyNullKafkaTemplate() {
        RouteMessageValidatorFn routeMessageValidatorFn = new RouteMessageValidatorFn(kafkaConfigurationService);
        RouteMessageRequest routeMessageRequest = new RouteMessageRequest();
        routeMessageRequest.setMessage("message");
        routeMessageRequest.setProducerCn("producerCn");
        routeMessageRequest.setTopic("topic");

        Mockito.when(kafkaConfigurationService.findById(Mockito.anyString())).thenReturn(null);
        assertThrows(ResponseStatusException.class, () -> routeMessageValidatorFn.apply(routeMessageRequest));
    }

    @Test
    void supportsSuccessful() {
        RouteMessageValidatorFn routeMessageValidatorFn = new RouteMessageValidatorFn(kafkaConfigurationService);
        routeMessageValidatorFn.supports(RouteMessageRequest.class);
    }
}