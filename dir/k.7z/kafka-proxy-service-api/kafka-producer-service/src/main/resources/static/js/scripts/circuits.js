if(message) {
	$("#snackbar").html(message);
	
	var className = "";
	
	if(message.indexOf("fail") != -1) className = "failure-show";
	else if(message.indexOf("success") != -1) className = "success-show";

	$("#snackbar").addClass(className);
	
	setTimeout(function(){ 
		$("#snackbar").removeClass(className);
	}, 3000);
}

$(window).resize(function(){
	resizeDiv();
});

$(document).ready(function(){
	if(changedCircuit && changedCircuit != '') {
		var container = $('div.content-div');
	    var scrollTo = $("div.content-div table tbody tr."+changedCircuit);
		container.animate({
		    scrollTop: scrollTo.offset().top - container.offset().top + container.scrollTop()-100
		});
		scrollTo.addClass('row-hover');
		setTimeout(function(){ scrollTo.removeClass('row-hover'); },2000);
	}
});

function resizeDiv() {
	var navHeight = $("nav.navbar").height()+35;
	$(".container-fluid").css("margin-top",navHeight+"px");
	
	var height = $(window).height();
	var pageHeadingHeight = $(".pageHeading").height();
	var infoDivHeight = $(".alert").height();
	var tableMaxHeight = height-(navHeight+pageHeadingHeight+infoDivHeight+110);
	
	$(".content-div").css("max-height", tableMaxHeight+"px");
}

resizeDiv();
