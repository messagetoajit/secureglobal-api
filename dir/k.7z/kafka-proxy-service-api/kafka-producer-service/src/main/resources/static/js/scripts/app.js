if(viewPage.indexOf("/") != -1) {
	var tempArray = viewPage.split("/");
	viewPage = tempArray[tempArray.length-1];
}

$("a.nav-link").removeClass("active un-clickable");
$("a."+viewPage+"-link").addClass("active un-clickable");