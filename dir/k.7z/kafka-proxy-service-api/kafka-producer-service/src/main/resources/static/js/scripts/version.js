$(window).resize(function(){
	resizeDiv();
});

function resizeDiv() {
	var navHeight = $("nav.navbar").height()+35;
	$(".container-fluid").css("margin-top",navHeight+"px");
}

resizeDiv();