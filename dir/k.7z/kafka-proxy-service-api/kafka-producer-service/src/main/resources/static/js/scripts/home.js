$(window).resize(function(){
	resizeDiv();
});

function resizeDiv() {
	var navHeight = $("nav.navbar").height()+35;
	$(".container").css("margin-top",navHeight+"px");
}

resizeDiv();