package com.optum.mnr.kafkaproducer.repository;

import com.optum.mnr.kafkaproducer.repository.domain.KafkaConfiguration;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface KafkaConfigurationRepository  {

    List<KafkaConfiguration> findAll();

    KafkaConfiguration findByProducerCN(String id);

}
