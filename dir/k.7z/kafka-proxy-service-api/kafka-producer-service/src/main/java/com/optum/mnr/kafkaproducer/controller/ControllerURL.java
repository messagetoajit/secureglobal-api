package com.optum.mnr.kafkaproducer.controller;

public class ControllerURL {
	
	private ControllerURL() {}

	public static final String FAVICON 					= "favicon.ico";

	public static final String HOME 					= "/";
	public static final String VERSION 					= "/version";
	public static final String CIRCUITS 				= "/circuits";
	
}
