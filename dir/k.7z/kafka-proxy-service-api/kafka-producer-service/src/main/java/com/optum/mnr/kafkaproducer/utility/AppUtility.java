package com.optum.mnr.kafkaproducer.utility;

import com.optum.mnr.kafkaproducer.exception.ErrorDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TimeZone;

public class AppUtility {

    private static final Logger logger = LoggerFactory.getLogger(AppUtility.class);

    public static String getUTCDateString(Object dateObject) {
        String utcDateString = null;
        if(dateObject != null) {
            try {
                Date timestamp = (Date) dateObject;
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss a z");
                sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
                utcDateString = sdf.format(timestamp);

            } catch (Exception e) {
                logger.error("Exception occurred while converting date object to UTC String");
            }
        }
        return utcDateString;
    }

    public static ErrorDetails buildErrorObject(Map<String, Object> errorAttributes) {
        ErrorDetails errorDetails = ErrorDetails.builder().build();
        if(errorAttributes != null) {
            try {
                errorDetails.setTimestamp(AppUtility.getUTCDateString(errorAttributes.get("timestamp")));
                errorDetails.setPath((String) errorAttributes.get("path"));
                errorDetails.setStatus((Integer) errorAttributes.get("status"));
                errorDetails.setError((String) errorAttributes.get("error"));
                errorDetails.setMessage((String) errorAttributes.get("message"));
            } catch (Exception e) {
                logger.error("Exception occurred while building error object");
                errorDetails.setMessage("Exception occurred while building error object");
            }
        }
        return errorDetails;
    }
}
