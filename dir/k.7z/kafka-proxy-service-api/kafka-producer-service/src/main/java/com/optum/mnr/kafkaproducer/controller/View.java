package com.optum.mnr.kafkaproducer.controller;

public enum View {

	TEMPLATE("common/template", "Template page for the application"),
	HOME("content/home", "Home page."),
	CIRCUIT_BREAKER_UI("content/circuits", "Page to display circuits."),
	VERSION("content/version", "Page to display versions.");

    private final String viewName;
    private final String description;

    View(final String viewName, final String description) {
        this.viewName = viewName;
        this.description = description;
    }

	public String getViewName() {
		return viewName;
	}

	public String getDescription() {
		return description;
	}

}
