package com.optum.mnr.kafkaproducer.repository.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class KafkaConfiguration {

    private String producerCn;
    private String keystorePath;
    private String keystorePass;
    private String truststorePath;
    private String truststorePass;

}
