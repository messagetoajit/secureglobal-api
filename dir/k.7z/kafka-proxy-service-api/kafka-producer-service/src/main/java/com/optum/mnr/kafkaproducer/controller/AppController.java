package com.optum.mnr.kafkaproducer.controller;

import com.netflix.config.ConfigurationManager;
import com.optum.mnr.kafkaproducer.configuration.HystrixConfig;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequiredArgsConstructor
public class AppController {

	private static final Logger logger = LoggerFactory.getLogger(AppController.class);

	private final HystrixConfig hystrixConfig;

	@Value("${spring.application.base-package}")
	private String basePackage;

	@Value("${spring.application.title}")
	private String appTitle;

	@Value("${spring.application.status}")
	private String appStatus;

	@Value("${git.commit.time}")
	private String timeStamp;

	@Value("${git.build.version}")
	private String buildVersion;

	@Value("${git.remote.origin.url}")
	private String gitUrl;

	@Value("${git.branch}")
	private String gitBranch;

	@Value("${spring.application.name}")
	private String appName;

	@Value("${endpoint.app.monitoring}")
	private String monitoringAppUrl;
	
	final String[] DISALLOWED_FIELDS = null;

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.setDisallowedFields(DISALLOWED_FIELDS);
	}

	private String setCommonViewData(final Model model, String viewName) {
		model.addAttribute("viewPage", viewName);
		model.addAttribute("title", appTitle);
		model.addAttribute("appName", appTitle);
		model.addAttribute("monitoringAppUrl", monitoringAppUrl);

		if(View.HOME.getViewName().equalsIgnoreCase(viewName)) {
			model.addAttribute("message", appStatus);
		}

		return View.TEMPLATE.getViewName();
	}

	@GetMapping(ControllerURL.FAVICON)
	@ResponseBody
	void returnNoFavicon() { }

	@GetMapping(ControllerURL.HOME)
	public String home(final Model model) {
		return setCommonViewData(model, View.HOME.getViewName());
	}

	@GetMapping(ControllerURL.VERSION)
	public String version(final Model model) {
		model.addAttribute("timeStamp", timeStamp);
		model.addAttribute("buildVersion", buildVersion);
		model.addAttribute("gitUrl", gitUrl);
		model.addAttribute("gitBranch", gitBranch);
		model.addAttribute("basePackage", basePackage);

		model.addAttribute("isTraceEnabled", LogManager.getLogger(basePackage).isTraceEnabled());
		model.addAttribute("isDebugEnabled", LogManager.getLogger(basePackage).isDebugEnabled());
		model.addAttribute("isInfoEnabled", LogManager.getLogger(basePackage).isInfoEnabled());

		return setCommonViewData(model, View.VERSION.getViewName());
	}

	@GetMapping(ControllerURL.CIRCUITS)
	public String circuits(final Model model) {
		setCommonCircuitsData(model);
		return setCommonViewData(model, View.CIRCUIT_BREAKER_UI.getViewName());
	}

	private void setCommonCircuitsData(final Model model) {
		model.addAttribute("circuits", HystrixConfig.getCircuits());
		model.addAttribute("serviceCall_timeoutDuration", (hystrixConfig.getServiceExecTimeOutInMillis()/1000)+" seconds");
		model.addAttribute("serviceCall_failureRateThreshold", hystrixConfig.getServiceErrorThresholdPercentage()+"%");
		model.addAttribute("serviceCall_circuitSleepingWindow", (hystrixConfig.getServiceSleepWindowInMillis()/1000)+" seconds");
	}

	@PostMapping(ControllerURL.CIRCUITS)
	public String changeCircuitState(final Model model, Circuit circuit) {
		try {
			String circuitName = circuit.getName();
			boolean forceOpenFlag = circuit.isCircuitOpen();

			if (StringUtils.isNotBlank(circuitName)) {

				HystrixConfig.storeHystrixCommand(circuitName, forceOpenFlag);
				String commandKeyProperty = "hystrix.command."+circuitName+".circuitBreaker.forceOpen";
				ConfigurationManager.getConfigInstance().setProperty(commandKeyProperty, forceOpenFlag);

				if(forceOpenFlag) {
					model.addAttribute("message", "Circuit opened successfully");
				} else {
					model.addAttribute("message", "Circuit closed successfully");
				}

				model.addAttribute("changedCircuit", circuitName);

			} else {
				model.addAttribute("message", "Circuit state changing failed");
			}

		} catch (Exception e) {
			model.addAttribute("message", "Circuit state changing failed");
			logger.error("{"+appName+"} -{"+this.getClass().getSimpleName()+"} - {"+new Exception().getStackTrace()[0].getMethodName()+"()} - Circuit state changing failed : "+e);
		}

		setCommonCircuitsData(model);

		return setCommonViewData(model, View.CIRCUIT_BREAKER_UI.getViewName());
	}

}
