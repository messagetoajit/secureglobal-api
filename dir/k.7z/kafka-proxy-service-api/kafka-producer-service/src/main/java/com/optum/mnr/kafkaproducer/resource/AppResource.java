package com.optum.mnr.kafkaproducer.resource;

import com.optum.mnr.kafkaconsumer.function.RouteToConsumeMessageProcessorFn;
import com.optum.mnr.kafkaproducer.common.AppConstant;
import com.optum.mnr.kafkaproducer.domain.RouteMessageRequest;
import com.optum.mnr.kafkaproducer.domain.RouteMessageResponse;
import com.optum.mnr.kafkaproducer.exception.ErrorDetails;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

@RestController
@Tag(name = "Kafka endpoints", description = "Kafka endpoints")
public class AppResource {

    private static final Logger logger = LoggerFactory.getLogger(AppResource.class);
    final String[] DISALLOWED_FIELDS = null;
    private final Function<RouteMessageRequest, Mono<RouteMessageResponse>> messageProcessorFunction;
    private final Function<RouteMessageRequest, RouteMessageRequest> messageValidationFunction;
    private final RouteToConsumeMessageProcessorFn consumeMessageProcessorFunction;
    public AppResource(
        Function<RouteMessageRequest, Mono<RouteMessageResponse>> messageProcessorFunction,
        Function<RouteMessageRequest, RouteMessageRequest> messageValidationFunction,
        RouteToConsumeMessageProcessorFn consumeMessageProcessorFunction
    ) {
        this.messageProcessorFunction = messageProcessorFunction;
        this.messageValidationFunction = messageValidationFunction;
        this.consumeMessageProcessorFunction = consumeMessageProcessorFunction;
    }
    
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		binder.setDisallowedFields(DISALLOWED_FIELDS);
	}
    @Operation(summary = "Post to kafka topic", description = "Post to kafka topic", tags = { "AppResource" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "200", description = "Success"),
        @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = ErrorDetails.class)))
    })
    @PostMapping(value = AppConstant.POST_TO_KAFKA_TOPIC, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<RouteMessageResponse> route(@RequestBody RouteMessageRequest request) {
        return Mono.just(request)
                .map(messageValidationFunction)
                .flatMap(messageProcessorFunction);
    }

    @Operation(summary = "Post to kafka topic with path parameters", description = "Post to kafka topic with path parameters", tags = { "AppResource" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Resource created"),
        @ApiResponse(responseCode = "400", description = "Bad Request - Request data Validation Failure", content = @Content(schema = @Schema(implementation = ErrorDetails.class))),
        @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = ErrorDetails.class)))
    })
    @PostMapping(value = AppConstant.POST_TO_KAFKA_TOPIC_WITH_PATH_PARAM, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<RouteMessageResponse> routeWithParam(
        @PathVariable(required = true) String topic,
        @PathVariable(required = true) String producerCn,
        @RequestBody String body
    ) {
        return Mono.just(body)
        		.map(p -> {
    				RouteMessageRequest routeMessageRequest = new RouteMessageRequest();
    				routeMessageRequest.setProducerCn(producerCn);
    				routeMessageRequest.setTopic(topic);
    				routeMessageRequest.setMessage(p);
    				return routeMessageRequest;
        		})
        		.map(messageValidationFunction)
                .flatMap(messageProcessorFunction);
    }

    @Operation(summary = "Get from kafka topic", description = "Get from kafka topic", tags = { "AppResource" })
    @ApiResponses(value = {
        @ApiResponse(responseCode = "201", description = "Resource created"),
        @ApiResponse(responseCode = "400", description = "Bad Request - Request data Validation Failure", content = @Content(schema = @Schema(implementation = ErrorDetails.class))),
        @ApiResponse(responseCode = "500", description = "Internal Server Error", content = @Content(schema = @Schema(implementation = ErrorDetails.class)))
    })
    @GetMapping(value = AppConstant.GET_FROM_KAFKA_TOPIC, produces = MediaType.APPLICATION_JSON_VALUE)
    public Mono<com.optum.mnr.kafkaconsumer.domain.RouteMessageResponse> routeToConsumeMessage(
            @PathVariable(required = true) String topic,
            @PathVariable(required = true) String consumerCn
    ) {
        Map<String, String> requestItems = new HashMap<>();
        requestItems.put("topic", topic);
        requestItems.put("consumerCn", consumerCn);

        return Mono.justOrEmpty(requestItems)
                .flatMap(consumeMessageProcessorFunction);
    }

}
