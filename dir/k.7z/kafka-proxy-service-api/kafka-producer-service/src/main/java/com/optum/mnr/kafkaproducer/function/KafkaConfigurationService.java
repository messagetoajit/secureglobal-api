package com.optum.mnr.kafkaproducer.function;

import com.optum.mnr.kafkaproducer.repository.KafkaConfigurationRepository;
import com.optum.mnr.kafkaproducer.repository.domain.KafkaConfiguration;

import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;

import java.util.*;

@Service
public class KafkaConfigurationService {

    private final KafkaConfigurationRepository kafkaConfigurationRepository;
    private final Map<String, KafkaTemplate<String, String>> KAFKA_CONFIGURATIONS = new HashMap<>();
    private final KafkaProperties kafkaProperties;
    public KafkaConfigurationService(
        KafkaConfigurationRepository kafkaConfigurationRepository,
        KafkaProperties kafkaProperties
    ) {
        this.kafkaConfigurationRepository = kafkaConfigurationRepository;
        this.kafkaProperties = kafkaProperties;
    }

    @PostConstruct
    public void init() {
        List<KafkaConfiguration> kafkaConfigurationList = this.kafkaConfigurationRepository.findAll();
        if (kafkaConfigurationList != null) {
            kafkaConfigurationList.forEach(kafkaConfiguration -> {
                KAFKA_CONFIGURATIONS.put(kafkaConfiguration.getProducerCn(), createKafkaTemplate(kafkaConfiguration));
            });
        }
    }

    @Value("${spring.application.name}")
    private String appName = "Kafka Proxy Service API";

    protected KafkaTemplate<String, String> createKafkaTemplate(KafkaConfiguration kafkaConfiguration) {
    	System.out.println("appName:" + appName);
        Map<String, Object> senderProps = senderProps();
        senderProps.put(ProducerConfig.CLIENT_ID_CONFIG, appName);
        senderProps.put("security.protocol", "SSL");
        senderProps.put("ssl.truststore.location", kafkaConfiguration.getTruststorePath());
        senderProps.put("ssl.truststore.password", kafkaConfiguration.getTruststorePass());
        senderProps.put("ssl.keystore.password", kafkaConfiguration.getKeystorePass());
        senderProps.put("ssl.keystore.location", kafkaConfiguration.getKeystorePath());
        return new KafkaTemplate<String, String>(new DefaultKafkaProducerFactory<>(senderProps));
    }

    public KafkaTemplate<String, String> findById(String id) {
        if (KAFKA_CONFIGURATIONS.containsKey(id)) {
            return KAFKA_CONFIGURATIONS.get(id);
        }

        KafkaConfiguration configuration = this.kafkaConfigurationRepository.findByProducerCN(id);
        if (configuration != null) {
            KafkaTemplate<String, String> kafkaTemplate = createKafkaTemplate(configuration);
            KAFKA_CONFIGURATIONS.put(id, kafkaTemplate);
            return kafkaTemplate;
        }

        return null;
    }

    protected Map<String, Object> senderProps() {
        Map<String, Object> props = new HashMap<>();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, this.kafkaProperties.getBootstrapServers());
        props.put(ProducerConfig.RETRIES_CONFIG, kafkaProperties.getProducer().getRetries());
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        props.put(ProducerConfig.ACKS_CONFIG, this.kafkaProperties.getProducer().getAcks());
        return props;
    }

    protected Map<String, KafkaTemplate<String, String>> getKAFKA_CONFIGURATIONS() {
        return KAFKA_CONFIGURATIONS;
    }
}
