package com.optum.mnr.kafkaproducer.exception;

import com.optum.mnr.kafkaproducer.common.AppConstant;
import com.optum.mnr.kafkaproducer.utility.AppUtility;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.web.ResourceProperties;
import org.springframework.boot.autoconfigure.web.reactive.error.AbstractErrorWebExceptionHandler;
import org.springframework.boot.web.reactive.error.ErrorAttributes;
import org.springframework.context.ApplicationContext;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.codec.ServerCodecConfigurer;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.server.*;
import reactor.core.publisher.Mono;

import java.util.Map;

@Component
@Order(-5)
public class GlobalExceptionHandler extends AbstractErrorWebExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    public GlobalExceptionHandler(ErrorAttributes errorAttributes, ServerCodecConfigurer serverCodecConfigurer, ApplicationContext applicationContext) {
        super(errorAttributes, new ResourceProperties(), applicationContext);
        super.setMessageWriters(serverCodecConfigurer.getWriters());
        super.setMessageReaders(serverCodecConfigurer.getReaders());
    }

    @Override
    protected RouterFunction<ServerResponse> getRoutingFunction(ErrorAttributes errorAttributes) {
        return RouterFunctions.route(RequestPredicates.all(), this::renderErrorResponse);
    }

    /**
     * Error handler for all exceptions
     * @param serverRequest - request that generated the error
     * @return - Error response
     */
    private Mono<ServerResponse> renderErrorResponse(ServerRequest serverRequest) {
        if (serverRequest.path().equals(AppConstant.POST_TO_KAFKA_TOPIC)) {
            return getErrorResponseForPostToKafkaTopic(serverRequest);
        }

        Map<String, Object> errorAttributes = getErrorAttributes(serverRequest, true);
        logger.error("GlobalExceptionHandler : Error Details : {}", errorAttributes);

        ErrorDetails errorDetails = AppUtility.buildErrorObject(errorAttributes);
        int statusCode = errorDetails.getStatus() != null ? errorDetails.getStatus() : 500;

        return ServerResponse.status(statusCode)
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(errorDetails));
    }

    private Mono<ServerResponse> getErrorResponseForPostToKafkaTopic(ServerRequest serverRequest) {
        Map<String, Object> errorAttributes = getErrorAttributes(serverRequest, false);
        logger.error("GlobalExceptionHandler : getErrorResponseForPostToKafkaTopic() : Error Details : {}", errorAttributes);

        ErrorDetails errorDetails = AppUtility.buildErrorObject(errorAttributes);
        errorDetails.setStatus(400);

        return ServerResponse.status(HttpStatus.BAD_REQUEST)
                .contentType(MediaType.APPLICATION_JSON)
                .body(BodyInserters.fromValue(errorDetails));
    }
}
