package com.optum.mnr.kafkaproducer.validator;

import com.optum.mnr.kafkaproducer.domain.RouteMessageRequest;
import com.optum.mnr.kafkaproducer.function.KafkaConfigurationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.validation.BeanPropertyBindingResult;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;
import org.springframework.web.server.ResponseStatusException;

import java.util.function.Function;

@Component
public class RouteMessageValidatorFn implements Function<RouteMessageRequest, RouteMessageRequest>, Validator {

    private static Logger logger = LoggerFactory.getLogger(RouteMessageValidatorFn.class);

    private final KafkaConfigurationService kafkaConfigurationService;
    public RouteMessageValidatorFn(KafkaConfigurationService kafkaConfigurationService) {
        this.kafkaConfigurationService = kafkaConfigurationService;
    }

    @Override
    public RouteMessageRequest apply(RouteMessageRequest routeMessageRequest) {
        logger.info("Validating message to {}", routeMessageRequest);

        Errors errors = new BeanPropertyBindingResult(routeMessageRequest, RouteMessageRequest.class.getName());
        this.validate(routeMessageRequest, errors);

        if (!errors.getAllErrors().isEmpty()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, errors.getAllErrors().toString());
        }
        logger.info("Completed message validation for {} successfully", routeMessageRequest);
        return routeMessageRequest;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return RouteMessageRequest.class.isAssignableFrom(aClass);
    }

    @Override
    public void validate(Object o, Errors errors) {
        RouteMessageRequest routeMessageRequest = (RouteMessageRequest) o;

        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "message", "field.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "producerCn", "field.required");
        ValidationUtils.rejectIfEmptyOrWhitespace(errors, "topic", "field.required");

        boolean isKafkaTopicConfigured = kafkaConfigurationService.findById(routeMessageRequest.getProducerCn()) != null;

        if(!isKafkaTopicConfigured) {
            errors.rejectValue("producerCn", "Producer not setup in Kafka Proxy Service");
        }
    }

}
