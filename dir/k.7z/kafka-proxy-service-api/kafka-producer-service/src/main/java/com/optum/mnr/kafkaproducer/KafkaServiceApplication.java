package com.optum.mnr.kafkaproducer;

import com.optum.mnr.kafkaconsumer.KafkaConsumerProperties;
import com.optum.mnr.kafkaproducer.common.AppConstant;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.PropertySource;

@Import(KafkaConsumerProperties.class)
@EnableHystrix
@EnableCircuitBreaker
@SpringBootApplication
@PropertySource(value=AppConstant.GENERATED_GIT_PROPERTIES_FILE, ignoreResourceNotFound=true)
public class KafkaServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(KafkaServiceApplication.class, args);
    }

}
