package com.optum.mnr.kafkaproducer.configuration;

import com.optum.mnr.kafkaproducer.controller.Circuit;
import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.annotation.WriteOperation;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@Configuration
@Endpoint(id="circuitbreakerstate")
public class CircuitBreakersEndpoint {
    @ReadOperation
    public List<Circuit> getCircuits(){
        return HystrixConfig.getCircuits();
    }
    @WriteOperation
    public Circuit resetCircuitStates(@Selector String circuitName, @Selector String status){
        if (HystrixConfig.getCommandData().get(circuitName) == null) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Invalid circuit");
        }
        if (("open").equals(status)) {
            HystrixConfig.forceOpenCircuit(circuitName);
        } else {
            HystrixConfig.closeCircuit(circuitName);
        }
        return HystrixConfig.getCircuit(circuitName);
    }
}
