package com.optum.mnr.kafkaproducer.repository;

import com.optum.mnr.kafkaproducer.repository.domain.KafkaConfiguration;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

@Repository
public class KafkaConfigurationRepositoryImpl implements KafkaConfigurationRepository {

    @Value("${kafka.producer.cert.file.path}")
    private String kafkaCertFilePath;

    @Value("${kafka.cert.file.keystore.pattern}")
    private String kafkaCertKeystoreFilePattern;

    @Value("${kafka.cert.file.keystore-pass.pattern}")
    private String kafkaCertKeystorePassFilePattern;

    @Value("${kafka.cert.file.truststore.pattern}")
    private String kafkaCertTruststoreFilePattern;

    @Value("${kafka.cert.file.truststore-pass.pattern}")
    private String kafkaCertTruststorePassFilePattern;

    @Override
    public List<KafkaConfiguration> findAll() {
       List<KafkaConfiguration> kafkaConfigurations = new ArrayList<>();
       File[] directories = new File(kafkaCertFilePath).listFiles(File::isDirectory);
       if (directories != null && directories.length > 0){
            for (File file : directories) {
                KafkaConfiguration kafkaConfiguration = getKafkaConfiguration(file);
                kafkaConfigurations.add(kafkaConfiguration);
            }
        }
        return kafkaConfigurations;
    }

    private KafkaConfiguration getKafkaConfiguration(File file)  {
        String name = file.getName();
        String keystoreJksFile = String.format(kafkaCertFilePath+kafkaCertKeystoreFilePattern, name, name);
        String keystorePassFile = String.format(kafkaCertFilePath+kafkaCertKeystorePassFilePattern, name, name);
        String truststoreJksFile = String.format(kafkaCertFilePath+kafkaCertTruststoreFilePattern, name);
        String truststorePassFile = String.format(kafkaCertFilePath+kafkaCertTruststorePassFilePattern, name);
        String keystorePass;
        String truststorePass;
        try {
            keystorePass = FileUtils.readFileToString(new File(keystorePassFile), StandardCharsets.UTF_8);
            truststorePass = FileUtils.readFileToString(new File(truststorePassFile), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new IllegalArgumentException("Keystore pass file can not be read");
        }
        return new KafkaConfiguration(name, keystoreJksFile,
                keystorePass.replace("\n", "").replace("\r", ""),
                truststoreJksFile,
                truststorePass.replace("\n", "").replace("\r", ""));
    }

    @Override
    public KafkaConfiguration findByProducerCN(String id) {
        File file = new File(kafkaCertFilePath + "/" + id);

        KafkaConfiguration kafkaConfiguration = null;
        if (file.exists() && file.isDirectory()) {
            kafkaConfiguration = getKafkaConfiguration(file);
        }

        return kafkaConfiguration;
    }
}
