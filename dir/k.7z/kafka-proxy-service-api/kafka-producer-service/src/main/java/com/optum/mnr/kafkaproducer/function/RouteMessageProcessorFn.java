package com.optum.mnr.kafkaproducer.function;

import com.optum.mnr.kafkaproducer.configuration.HystrixConfig;
import com.optum.mnr.kafkaproducer.domain.RouteMessageRequest;
import com.optum.mnr.kafkaproducer.domain.RouteMessageResponse;

import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.netflix.hystrix.HystrixCommands;
import org.springframework.http.HttpStatus;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import javax.annotation.PostConstruct;
import java.util.function.Function;

@Service
public class RouteMessageProcessorFn implements Function<RouteMessageRequest, Mono<RouteMessageResponse>> {

	private Logger logger = LoggerFactory.getLogger(RouteMessageProcessorFn.class);

	private final HystrixConfig hystrixConfig;
	private final KafkaConfigurationService kafkaConfigurationService;
	public RouteMessageProcessorFn(HystrixConfig hystrixConfig, KafkaConfigurationService kafkaConfigurationService) {
		this.hystrixConfig = hystrixConfig;
		this.kafkaConfigurationService = kafkaConfigurationService;
	}

	@PostConstruct
	public void init() {
		HystrixConfig.storeHystrixCommands(
			new String[] {
				"send-ucee-data"
			}, false
		);
	}

	@Override
	public Mono<RouteMessageResponse> apply(RouteMessageRequest routeMessageRequest) {
		logger.info("Processing message {}", routeMessageRequest);

		RouteMessageResponse routeMessageResponse = new RouteMessageResponse();
		routeMessageResponse.setStatus(HttpStatus.FAILED_DEPENDENCY.value());

		try {
			KafkaTemplate<String, String> kafkaTemplate = this.kafkaConfigurationService.findById(routeMessageRequest.getProducerCn());

			if (kafkaTemplate == null) {
				logger.info("KafkaTemplate is null due to CN has not been setup properly.");
				routeMessageResponse.setError("Kafka Template is not setup for this topic");
				return Mono.just(routeMessageResponse);
			}
			ProducerRecord<String,String> record =new ProducerRecord<String,String>(routeMessageRequest.getTopic(),routeMessageRequest.getMessage());
			if(routeMessageRequest.getRetry() != null) record.headers().add(new RecordHeader("retry",routeMessageRequest.getRetry().getBytes()));
			return HystrixCommands
					.from(
						Mono.fromFuture(kafkaTemplate.send(record).completable())
							.map(result -> {
								logger.info("Message successfully routed to kafka topic.");

								routeMessageResponse.setMessage("Message successfully routed to kafka topic"+ result.getRecordMetadata().topic());
								routeMessageResponse.setStatus(HttpStatus.OK.value());

								return routeMessageResponse;
							})
							.switchIfEmpty(Mono.just(routeMessageResponse))
					)
					.groupName("send-data")
					.commandName("send-ucee-data")
					.commandProperties(hystrixConfig::getServiceCallSettings)
					.fallback(throwable -> {
						logger.info("Error while sending kafka message to kafka topic.");

						routeMessageResponse.setMessage(null);
						routeMessageResponse.setStatus(HttpStatus.FAILED_DEPENDENCY.value());
						routeMessageResponse.setError("Error while sending kafka message " +throwable.getMessage());

						return Mono.just(routeMessageResponse);
					})
					.toMono();

		} catch (Exception ex) {
			logger.error("Unable to send message to topic : {}", ex);

			routeMessageResponse.setStatus(HttpStatus.FAILED_DEPENDENCY.value());
			routeMessageResponse.setError("Unable to send message to topic : " + ex.getMessage());

			return Mono.just(routeMessageResponse);
		}
	}

}
