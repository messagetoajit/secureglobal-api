package com.optum.mnr.kafkaproducer.common;

public interface AppConstant {

    /********************************** ENDPOINTS **********************************/
    String CIRCUITS_ENDPOINT					    = "/api/mnr/circuits";
    String POST_TO_KAFKA_TOPIC                      = "/api/mnr/route";
    String POST_TO_KAFKA_TOPIC_WITH_PATH_PARAM      = "/api/mnr/route/{producerCn}/{topic}";
    String GET_FROM_KAFKA_TOPIC                     = "/api/mnr/route/{consumerCn}/{topic}";

    /******************************** STRING CONSTANTS ****************************/
    String GENERATED_GIT_PROPERTIES_FILE		    = "classpath:git.properties";

}
