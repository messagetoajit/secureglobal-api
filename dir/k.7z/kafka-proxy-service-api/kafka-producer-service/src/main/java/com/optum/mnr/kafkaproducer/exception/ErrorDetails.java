package com.optum.mnr.kafkaproducer.exception;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ErrorDetails {

    private String timestamp;
    private String path;
    private Integer status;
    private String error;
    private String message;

}
