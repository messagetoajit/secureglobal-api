package com.optum.mnr.kafkaproducer.configuration;

import com.netflix.config.ConfigurationManager;
import com.netflix.hystrix.HystrixCommandProperties;
import com.optum.mnr.kafkaproducer.controller.Circuit;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

@Component
@Data
@NoArgsConstructor
@AllArgsConstructor
public class HystrixConfig {

    /****************** Service call configurations *************/

    @Value("${hystrix.execution.service.timeoutInMilliseconds}")
    private int serviceExecTimeOutInMillis;

    @Value("${hystrix.circuitBreaker.service.requestVolumeThreshold}")
    private int serviceRequestVolumeThreshold;

    @Value("${hystrix.circuitBreaker.service.errorThresholdPercentage}")
    private int serviceErrorThresholdPercentage;

    @Value("${hystrix.circuitBreaker.service.sleepWindowInMilliseconds}")
    private int serviceSleepWindowInMillis;

    @Value("${hystrix.metrics.service.rollingStats.timeInMilliseconds}")
    private int serviceRollingStatsTimeInMillis;

    @Value("${hystrix.execution.service.semaphore.max.concurrent.requests}")
    private int serviceMaxConcurrentRequests;

    @Value("${hystrix.fallback.service.semaphore.max.concurrent.requests}")
    private int serviceMaxFallbackConcurrentRequests;

    public HystrixCommandProperties.Setter getServiceCallSettings(HystrixCommandProperties.Setter setter) {
        return setter
                .withCircuitBreakerEnabled(true)
                .withExecutionTimeoutEnabled(true)
                .withExecutionTimeoutInMilliseconds(this.serviceExecTimeOutInMillis)
                .withCircuitBreakerRequestVolumeThreshold(this.serviceRequestVolumeThreshold)
                .withCircuitBreakerErrorThresholdPercentage(this.serviceErrorThresholdPercentage)
                .withCircuitBreakerSleepWindowInMilliseconds(this.serviceSleepWindowInMillis)
                .withMetricsRollingStatisticalWindowInMilliseconds(this.serviceRollingStatsTimeInMillis)
                .withExecutionIsolationSemaphoreMaxConcurrentRequests(this.serviceMaxConcurrentRequests)
                .withFallbackIsolationSemaphoreMaxConcurrentRequests(this.serviceMaxFallbackConcurrentRequests)
                .withExecutionIsolationStrategy(HystrixCommandProperties.ExecutionIsolationStrategy.SEMAPHORE);
    }

    private static TreeMap<String,Boolean> hystrixMap = new TreeMap<String,Boolean>();

    public static void storeHystrixCommand(String hystrixCommandKey, boolean flag) {
        hystrixMap.put(hystrixCommandKey, flag);
    }

    public static void storeHystrixCommands(String[] hystrixCommandKeys, boolean flag) {
        for (String hystrixCommandKey: hystrixCommandKeys) {
            hystrixMap.put(hystrixCommandKey, flag);
        }
    }
    public static void forceOpenCircuit(String serviceName) {
        HystrixConfig.storeHystrixCommand(serviceName, true);
        String commandKeyProperty = "hystrix.command."+serviceName+".circuitBreaker.forceOpen";
        ConfigurationManager.getConfigInstance().setProperty(commandKeyProperty, true);
    }
    public static void closeCircuit(String serviceName) {
        HystrixConfig.storeHystrixCommand(serviceName, false);
        String commandKeyProperty = "hystrix.command."+serviceName+".circuitBreaker.forceOpen";
        ConfigurationManager.getConfigInstance().setProperty(commandKeyProperty, false);
    }
    public static TreeMap<String,Boolean> getCommandData() {
        return hystrixMap;
    }

    public static List<Circuit> getCircuits() {
        List<Circuit> circuitList = new ArrayList<>();
        hystrixMap.forEach((serviceName, isCircuitOpen) -> {
            circuitList.add(
                Circuit.builder()
                .name(serviceName)
                .state(isCircuitOpen ? "OPEN" : "CLOSED")
                .circuitOpen(isCircuitOpen)
                .build()
            );
        });
        return circuitList;
    }
    public static Circuit getCircuit(String circuitName) {
        Boolean isOpen = hystrixMap.get(circuitName);
        String state = (isOpen == null) ? "UNDEFINED" : (isOpen ? "FORCED_OPEN" : "CLOSED");
        return Circuit.builder()
                .name(circuitName)
                .state(state)
                .circuitOpen(!"CLOSED".equalsIgnoreCase(state))
                .build();
    }
}
