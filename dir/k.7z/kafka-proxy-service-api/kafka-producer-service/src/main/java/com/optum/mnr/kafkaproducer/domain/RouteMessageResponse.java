package com.optum.mnr.kafkaproducer.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RouteMessageResponse {
	
	private String message;
    private String error;
    private int status;
}
