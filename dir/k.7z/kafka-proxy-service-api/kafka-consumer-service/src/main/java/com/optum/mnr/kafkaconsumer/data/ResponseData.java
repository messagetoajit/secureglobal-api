package com.optum.mnr.kafkaconsumer.data;

import java.io.Serializable;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ResponseData  implements Serializable {
	private static final long serialVersionUID = 1L;
	private String error;
	private int status;
	private Object data;
	private String message;

}
