package com.optum.mnr.kafkaconsumer.data;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PublishMessageRequest {

	private String message;
    private String producerCn;
    private String topic;
    private String retry;

}