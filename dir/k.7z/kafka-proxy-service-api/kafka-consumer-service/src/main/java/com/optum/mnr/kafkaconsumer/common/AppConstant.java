package com.optum.mnr.kafkaconsumer.common;

public interface AppConstant {

    String CONFIG_SECURITY_PROTOCOL     		    = "security.protocol";
    String CONFIG_SSL_TRUSTSTORE_LOCATION     		= "ssl.truststore.location";
    String CONFIG_SSL_KEYSTORE_LOCATION     		= "ssl.keystore.location";
    String CONFIG_SSL_TRUSTSTORE_PASSWORD     		= "ssl.truststore.password";
    String CONFIG_SSL_KEYSTORE_PASSWORD     		= "ssl.keystore.password";
    String SSL                                      = "SSL";

    String CONSUMER_BASE_PACKAGE                    = "com.optum.mnr.kafkaconsumer";
    String MCE_LISTENER_ID							= "mnr.pre.mce-profile";
}
