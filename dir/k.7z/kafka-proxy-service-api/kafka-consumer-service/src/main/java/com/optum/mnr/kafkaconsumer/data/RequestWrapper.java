package com.optum.mnr.kafkaconsumer.data;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RequestWrapper {
	private ConsumerRecord<String,String> consumerRecord;
	private ConsumerRecordRequest consumerRecordRequest;
	private String status = "failure";
	private String endpoint;
	private String producerCn;

}

