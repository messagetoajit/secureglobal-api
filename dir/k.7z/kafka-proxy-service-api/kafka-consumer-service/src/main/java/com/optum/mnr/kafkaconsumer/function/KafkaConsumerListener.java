package com.optum.mnr.kafkaconsumer.function;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.kafka.config.KafkaListenerEndpointRegistry;
import org.springframework.stereotype.Component;

import com.optum.mnr.kafkaconsumer.KafkaConsumerProperties;

@Component
public class KafkaConsumerListener implements ApplicationRunner {
	private final KafkaConsumerProperties kafkaConsumerProperties;
	private final KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry;
    public KafkaConsumerListener(KafkaConsumerProperties kafkaConsumerProperties,
                   KafkaListenerEndpointRegistry kafkaListenerEndpointRegistry) {
			this.kafkaConsumerProperties = kafkaConsumerProperties;
            this.kafkaListenerEndpointRegistry = kafkaListenerEndpointRegistry;
     }
	

	@Override
    public void run(ApplicationArguments args) {
		if(kafkaConsumerProperties.getConsumers() != null) {
			kafkaConsumerProperties.getConsumers()
				.forEach((key, value) -> {
		            if(this.kafkaListenerEndpointRegistry.getListenerContainer(value.getName()) != null) {
	                    this.kafkaListenerEndpointRegistry.getListenerContainer(value.getName()).start();
		            }
				});
		}
	}
}
