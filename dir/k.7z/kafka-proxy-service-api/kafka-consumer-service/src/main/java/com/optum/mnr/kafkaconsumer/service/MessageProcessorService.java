package com.optum.mnr.kafkaconsumer.service;

import java.time.Duration;
import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import com.optum.mnr.kafkaconsumer.data.RequestWrapper;
import com.optum.mnr.kafkaconsumer.data.ResponseData;

import reactor.core.publisher.Mono;
@Service
public class MessageProcessorService implements Function<RequestWrapper, Mono<RequestWrapper>>{
	private Logger logger = LoggerFactory.getLogger(MessageProcessorService.class);
	@Value("${mnr.kafka.webclient.timeout}")
	private Long timeout;
	private final WebClient webClient;
	public MessageProcessorService(WebClient webClient) {
		this.webClient = webClient;
    }
	@Override
	public  Mono<RequestWrapper> apply(RequestWrapper requestWrapper) {
		return webClient.post()
		.uri(requestWrapper.getEndpoint())
		.bodyValue(requestWrapper.getConsumerRecordRequest())
		.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
		.accept(MediaType.APPLICATION_JSON)
		.retrieve()
		.bodyToMono(ResponseData.class)
		//.timeout(Duration.ofMillis(timeout))
		.map(data -> {
			if(data.getStatus() == 201)
				requestWrapper.setStatus("success");
			return requestWrapper;
			})
		.doOnSuccess(onSuccess -> logger.debug("Success respose : {}", onSuccess))
		.onErrorResume(throwable -> {
			logger.error("Exception in sending {} -  {}\n", requestWrapper.getEndpoint(), throwable.getMessage());
		    return Mono.just(requestWrapper);
		});
	}
}
