package com.optum.mnr.kafkaconsumer.function;

import com.optum.mnr.kafkaconsumer.domain.RouteMessageResponse;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;

@Service
public class RouteToConsumeMessageProcessorFn implements Function<Map<String,String>, Mono<RouteMessageResponse>> {
	
    private Logger logger = LoggerFactory.getLogger(RouteToConsumeMessageProcessorFn.class);
    
    private final KafkaConsumerConfigService kafkaConsumerConfigService;
    public RouteToConsumeMessageProcessorFn(KafkaConsumerConfigService kafkaConsumerConfigService) {
        this.kafkaConsumerConfigService = kafkaConsumerConfigService;
    }

    /**
     * Method to consume messages from a kafka topic
     * @return Response status of receiving message from a kafka topic
     */
	@Override
	public Mono<RouteMessageResponse> apply(Map<String,String> requestMap) {
		logger.info("Processing consuming message starts {}", requestMap);

		RouteMessageResponse routeMessageResponse = new RouteMessageResponse();
		String topic_to_consume = null;
		String consumerCn = null;

		if(requestMap != null && requestMap.size() > 0) {
			topic_to_consume = requestMap.get("topic");
			consumerCn = requestMap.get("consumerCn");
		}

		try {
			KafkaConsumer<String, String> consumer = kafkaConsumerConfigService.createKafkaConsumer(consumerCn);

			if(consumer != null) {
				consumer.subscribe(Collections.singletonList(topic_to_consume));

				final int giveUp = 10;
				int noRecordsCount = 0;
				List<String> consumerMessages = new ArrayList<String>();

				while (true) {
					final ConsumerRecords<String, String> consumerRecords = consumer.poll(Duration.ofSeconds(5));

					if (consumerRecords.count()==0) {
						noRecordsCount++;
						if (noRecordsCount > giveUp)
							break;
						else
							continue;
					}

					consumerRecords.forEach(record -> {
					   logger.debug("Consumer Record:({}, {}}, {}}, {}})\n", record.key(), record.value(), record.partition(), record.offset());
					   consumerMessages.add(record.value());
					});

					consumer.commitAsync();
				}

				routeMessageResponse.setMessages(consumerMessages);
				routeMessageResponse.setStatus(HttpStatus.OK.value());
				//consumer.close();

				logger.info("consumer call - end");

				return Mono.just(routeMessageResponse);
			}
			routeMessageResponse.setStatus(HttpStatus.FAILED_DEPENDENCY.value());
		    routeMessageResponse.setError("Consumer CN has not been setup. Add the certificate to /portal/conf/kafka-proxy-service-api/certs");

		    logger.info("KafkaConsumer is null due to CN has not been setup properly.");

		    return Mono.just(routeMessageResponse);
        
		} catch (Exception e) {
			routeMessageResponse.setStatus(HttpStatus.FAILED_DEPENDENCY.value());
            routeMessageResponse.setError("Error in receiving message from kafka"+e.getMessage());

            return Mono.just(routeMessageResponse);
		}
	}
	
	
}
