package com.optum.mnr.kafkaconsumer.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;

@Getter
@Configuration
public class MCEProperties {
	@Value("${mnr.kafka.are-mce.topic}")
	private String topic;
	@Value("${mnr.kafka.are-mce.consumerCn}")
	private String consumerCn;
	@Value("${mnr.kafka.are-mce.producerCn}")
	private String producerCn;
	@Value("${mnr.kafka.are-mce.endpoint}")
	private String endpoint;
	

}
