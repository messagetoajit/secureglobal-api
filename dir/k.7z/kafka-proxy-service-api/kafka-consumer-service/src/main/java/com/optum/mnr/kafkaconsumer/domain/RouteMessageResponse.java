package com.optum.mnr.kafkaconsumer.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RouteMessageResponse {
	
	private List<String> messages;
    private String error;
    private int status;

}
