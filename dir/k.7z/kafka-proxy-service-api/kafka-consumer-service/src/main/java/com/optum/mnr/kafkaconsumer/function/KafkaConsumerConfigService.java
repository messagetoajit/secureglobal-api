package com.optum.mnr.kafkaconsumer.function;

import com.optum.mnr.kafkaconsumer.common.AppConstant;
import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Service
public class KafkaConsumerConfigService {
	private Logger log = LoggerFactory.getLogger(KafkaConsumerConfigService.class);

    @Value("${kafka.consumer.cert.file.path}")
    private String consumerCertFilePath;

    private final KafkaProperties kafkaProperties;
    public KafkaConsumerConfigService(KafkaProperties kafkaProperties) {
        this.kafkaProperties = kafkaProperties;
    }

    public KafkaConsumer<String, String> createKafkaConsumer(String consumerCn) {
    	log.info("BootstrapServer --->"+kafkaProperties.getBootstrapServers());
        
        Map<String, Object> consumerConfig = new HashMap<>();

        consumerConfig.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,         kafkaProperties.getBootstrapServers());
        consumerConfig.put(ConsumerConfig.GROUP_ID_CONFIG,                  consumerCn);
        consumerConfig.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,    StringDeserializer.class);
        consumerConfig.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,  StringDeserializer.class);
        consumerConfig.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG,       "true");

        consumerConfig.put(AppConstant.CONFIG_SECURITY_PROTOCOL, 			AppConstant.SSL);
        consumerConfig.put(AppConstant.CONFIG_SSL_TRUSTSTORE_LOCATION, 	consumerCertFilePath+"/"+consumerCn+"/kaas-truststore.jks");
		consumerConfig.put(AppConstant.CONFIG_SSL_KEYSTORE_LOCATION, 		consumerCertFilePath+"/"+consumerCn+"/"+consumerCn+".keystore.jks");
		consumerConfig.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 		kafkaProperties.getConsumer().getMaxPollRecords());
		
		try {
			consumerConfig.put(AppConstant.CONFIG_SSL_TRUSTSTORE_PASSWORD, 	FileUtils.readFileToString(new File(consumerCertFilePath+"/"+consumerCn+"/truststore_pass"), StandardCharsets.UTF_8));
			consumerConfig.put(AppConstant.CONFIG_SSL_KEYSTORE_PASSWORD, 	FileUtils.readFileToString(new File(consumerCertFilePath+"/"+consumerCn+"/"+consumerCn+"_keystore_pass"), 	StandardCharsets.UTF_8));
		} catch (IOException e) {
			throw new IllegalArgumentException("Error while reading Keystore pass files ::"+e.getMessage());
		}

        return new KafkaConsumer<>(consumerConfig);
    }

}
