package com.optum.mnr.kafkaconsumer.listeners;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.optum.mnr.kafkaconsumer.common.AppConstant;
import com.optum.mnr.kafkaconsumer.common.MCEProperties;
import com.optum.mnr.kafkaconsumer.data.ConsumerRecordRequest;
import com.optum.mnr.kafkaconsumer.data.RequestWrapper;
import com.optum.mnr.kafkaconsumer.service.MessageProcessorService;
import com.optum.mnr.kafkaconsumer.service.MessageResponseService;

import reactor.core.publisher.Mono;

@Component
public class MedicalCostEstimatorListener {
	private Logger logger = LoggerFactory.getLogger(MedicalCostEstimatorListener.class);
	private final MessageProcessorService messageProcessService;
	private final MessageResponseService messageResponseService;
	private final MCEProperties mceProperties;
	
	public MedicalCostEstimatorListener(MessageProcessorService messageProcessService,
    		MessageResponseService messageResponseService,
    		MCEProperties mceProperties) {
        this.messageProcessService = messageProcessService;
        this.messageResponseService = messageResponseService;
        this.mceProperties = mceProperties;
    }
	@KafkaListener(id= AppConstant.MCE_LISTENER_ID, topics = "${mnr.kafka.are-mce.topic}", 
			containerFactory = "medicalCostEstimatorKafkaListenerContainerFactory", autoStartup = "false")
	public void mceTopicListener(ConsumerRecord<String, String> record) {
		Mono.just(record)
			.map(consumerRecord -> {
				RequestWrapper requestWrapper = new RequestWrapper();
				ConsumerRecordRequest consumerRecordRequest = new ConsumerRecordRequest(consumerRecord.topic(),
						consumerRecord.partition(),
						consumerRecord.offset(),
						consumerRecord.timestamp(),
						consumerRecord.value());
				requestWrapper.setConsumerRecordRequest(consumerRecordRequest);
				requestWrapper.setConsumerRecord(consumerRecord);
				requestWrapper.setEndpoint(mceProperties.getEndpoint());
				requestWrapper.setProducerCn(mceProperties.getProducerCn());
				logger.debug("Consumer Record:({}, {}, {})\n",  consumerRecord.value(), consumerRecord.partition(), consumerRecord.offset());
				return requestWrapper;
			})
			.flatMap(messageProcessService)
			.flatMap(messageResponseService)
			.subscribe();
  }
}
