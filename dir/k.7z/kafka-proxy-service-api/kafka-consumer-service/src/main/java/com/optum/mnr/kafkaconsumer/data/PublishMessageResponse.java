package com.optum.mnr.kafkaconsumer.data;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PublishMessageResponse {
	
	private String message;
    private String error;
    private int status;
}
