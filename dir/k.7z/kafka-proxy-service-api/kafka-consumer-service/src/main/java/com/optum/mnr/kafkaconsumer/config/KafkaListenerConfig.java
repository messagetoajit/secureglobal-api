package com.optum.mnr.kafkaconsumer.config;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import com.optum.mnr.kafkaconsumer.common.AppConstant;
import com.optum.mnr.kafkaconsumer.common.MCEProperties;

@EnableKafka
@Configuration
public class KafkaListenerConfig {
	@Value("${kafka.consumer.cert.file.path}")
	private String consumerCertFilePath;
	private final KafkaProperties kafkaProperties;
	private final MCEProperties mceProperties;
	
    public KafkaListenerConfig(KafkaProperties kafkaProperties, MCEProperties mceProperties) {
        this.kafkaProperties = kafkaProperties;
        this.mceProperties = mceProperties;
    }
    public ConsumerFactory<String, String> consumerFactory(String consumerCn) {
        Map<String, Object> props = new HashMap<>();
        props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,  kafkaProperties.getBootstrapServers());
        props.put(ConsumerConfig.GROUP_ID_CONFIG, consumerCn);
        props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        props.put(AppConstant.CONFIG_SECURITY_PROTOCOL, 			AppConstant.SSL);
        props.put(AppConstant.CONFIG_SSL_TRUSTSTORE_LOCATION, 	consumerCertFilePath+"/"+consumerCn+"/kaas-truststore.jks");
        props.put(AppConstant.CONFIG_SSL_KEYSTORE_LOCATION, 		consumerCertFilePath+"/"+consumerCn+"/"+consumerCn+".keystore.jks");
        props.put(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, 		kafkaProperties.getConsumer().getMaxPollRecords());
		
		try {
			props.put(AppConstant.CONFIG_SSL_TRUSTSTORE_PASSWORD, 	FileUtils.readFileToString(new File(consumerCertFilePath+"/"+consumerCn+"/truststore_pass"), StandardCharsets.UTF_8));
			props.put(AppConstant.CONFIG_SSL_KEYSTORE_PASSWORD, 	FileUtils.readFileToString(new File(consumerCertFilePath+"/"+consumerCn+"/"+consumerCn+"_keystore_pass"), 	StandardCharsets.UTF_8));
		} catch (IOException e) {
			throw new IllegalArgumentException("Error while reading Keystore pass files ::"+e.getMessage());
		}
        return new DefaultKafkaConsumerFactory<>(props);
    }
    public ConcurrentKafkaListenerContainerFactory<String, String> kafkaListenerContainerFactory(String consumerCn) {
        ConcurrentKafkaListenerContainerFactory<String, String> factory = new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(consumerFactory(consumerCn));
        return factory;
    }
    
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, String> medicalCostEstimatorKafkaListenerContainerFactory() {
        return kafkaListenerContainerFactory(mceProperties.getConsumerCn());
    }
}
