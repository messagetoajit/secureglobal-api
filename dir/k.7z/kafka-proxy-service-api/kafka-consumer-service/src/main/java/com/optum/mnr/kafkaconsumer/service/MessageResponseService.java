package com.optum.mnr.kafkaconsumer.service;

import java.util.function.Function;

import org.apache.kafka.common.header.Header;
import org.apache.kafka.common.header.Headers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.optum.mnr.kafkaconsumer.data.PublishMessageRequest;
import com.optum.mnr.kafkaconsumer.data.PublishMessageResponse;
import com.optum.mnr.kafkaconsumer.data.RequestWrapper;
import reactor.core.publisher.Mono;

@Service
public class MessageResponseService  implements Function<RequestWrapper, Mono<PublishMessageResponse>>{
	private Logger logger = LoggerFactory.getLogger(MessageResponseService.class);
	private final FailureMessagePublishService failureMessagePublishService;
	@Value("${mnr.kafka.failure.max-retry}")
	private Integer maxRetry;
	public MessageResponseService(FailureMessagePublishService failureMessagePublishService) {
		this.failureMessagePublishService = failureMessagePublishService;
    }
	@Override
	public  Mono<PublishMessageResponse> apply(RequestWrapper res) {	
		if("failure".equals(res.getStatus())) {
			Headers headers = res.getConsumerRecord().headers();
			Integer retry = 0; 
			for(Header header : headers) {
				if(header.key().equals("retry")) {
					retry = Integer.parseInt(new String(header.value()));
				}
			}
			if(retry < maxRetry) {
				retry += 1;
				PublishMessageRequest request = new PublishMessageRequest(res.getConsumerRecord().value(),
						res.getProducerCn(),
						res.getConsumerRecord().topic(),
						retry.toString());
				logger.info("Failure Offset record:({}, {}, {})\n", res.getConsumerRecord().topic(), res.getConsumerRecord().partition(), res.getConsumerRecord().offset());
				return failureMessagePublishService.apply(request);
			}
		}
		return Mono.empty();
	}
}

