package com.optum.mnr.kafkaconsumer;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

import com.optum.mnr.kafkaconsumer.common.AppConstant;

@ConfigurationProperties(prefix = "mnr.kafka")
@ComponentScan(AppConstant.CONSUMER_BASE_PACKAGE)
public class KafkaConsumerProperties {
	
	private  Map<String, ConsumerProperty> consumers;
	private String proxyEndpoint;

	public  Map<String, ConsumerProperty> getConsumers() {
		return consumers;
	}

	public void setConsumers(Map<String, ConsumerProperty> consumers) {
		this.consumers = consumers;
	}

	public String getProxyEndpoint() {
		return proxyEndpoint;
	}

	public void setProxyEndpoint(String proxyEndpoint) {
		this.proxyEndpoint = proxyEndpoint;
	}



	
}
