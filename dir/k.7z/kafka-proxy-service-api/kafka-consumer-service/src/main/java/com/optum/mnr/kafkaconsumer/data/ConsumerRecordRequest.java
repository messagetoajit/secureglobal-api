package com.optum.mnr.kafkaconsumer.data;

import java.util.Optional;

import org.apache.kafka.common.header.Headers;
import org.apache.kafka.common.record.TimestampType;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ConsumerRecordRequest {
	private  String topic;
    private  Integer partition;
    private  Long offset;
    private  Long timestamp;
    private  String message;
    
}
