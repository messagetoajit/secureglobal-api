package com.optum.mnr.kafkaconsumer.service;

import java.util.function.Function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

import com.optum.mnr.kafkaconsumer.KafkaConsumerProperties;
import com.optum.mnr.kafkaconsumer.data.PublishMessageRequest;
import com.optum.mnr.kafkaconsumer.data.PublishMessageResponse;
import com.optum.mnr.kafkaconsumer.data.RequestWrapper;
import com.optum.mnr.kafkaconsumer.data.ResponseData;

import reactor.core.publisher.Mono;
@Service
public class FailureMessagePublishService implements Function<PublishMessageRequest, Mono<PublishMessageResponse>>{
	private Logger logger = LoggerFactory.getLogger(FailureMessagePublishService.class);
	private final WebClient webClient;
	private final KafkaConsumerProperties kafkaConsumerProperties;
	public FailureMessagePublishService(WebClient webClient, KafkaConsumerProperties kafkaConsumerProperties) {
		this.webClient = webClient;
		this.kafkaConsumerProperties = kafkaConsumerProperties;
    }
	@Override
	public  Mono<PublishMessageResponse> apply(PublishMessageRequest model) {
		return webClient.post()
		.uri(kafkaConsumerProperties.getProxyEndpoint())
		.bodyValue(model)
		.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
		.accept(MediaType.APPLICATION_JSON)
		.retrieve()
		.onStatus(HttpStatus::isError, this::handleError)
		.bodyToMono(PublishMessageResponse.class)
		.doOnSuccess(onSuccess -> logger.debug("Success respose : {}", onSuccess))
		.onErrorResume(throwable -> {
			logger.error("Exception in sending {} -  {}\n", kafkaConsumerProperties.getProxyEndpoint(), throwable.getMessage());
		    return Mono.empty();
		});
	}
    
	
	private Mono<Throwable> handleError(ClientResponse clientResponse) {
		logger.error("Error in sending failure message data : {}" , clientResponse.rawStatusCode());
		return Mono.error(new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE, "Error in sending failure message  data. Error code: " + clientResponse.rawStatusCode()));
	}
}
